import 'package:chess/chess.dart' as chess_lib;
import 'chess_move_validator.dart';
import 'engine_api.dart';
import 'fen_utils.dart';
import 'personal_game_analysis.dart';

class EngineMoveExplanation {
  final String whatFailed;
  final String opponentPunishment;
  final String whyItWorks;
  final String consequence;
  final String betterChoice;
  final String lessonTitle;
  final String lessonText;
  final String reflectionQuestion;

  const EngineMoveExplanation({
    required this.whatFailed,
    required this.opponentPunishment,
    required this.whyItWorks,
    required this.consequence,
    required this.betterChoice,
    required this.lessonTitle,
    required this.lessonText,
    required this.reflectionQuestion,
  });
}

EngineMoveExplanation buildEngineMoveExplanation(
  EngineMoveResult move,
  PersonalGameMove context,
) {
  final isSame = isSameMove(
    context.fenBefore,
    move.bestMoveUci,
    context.san,
    fenAfter: context.fenAfter,
  );

  final isMistakeQuality = move.quality == EngineMoveQuality.inaccuracy ||
      move.quality == EngineMoveQuality.mistake ||
      move.quality == EngineMoveQuality.blunder;

  final best = humanizeUciMove(context.fenBefore, move.bestMoveUci);
  final replyUci = move.opponentBestReplyUci?.trim() ?? '';
  final punishmentLine = move.opponentPunishmentLineUci.isNotEmpty
      ? move.opponentPunishmentLineUci
      : replyUci.isNotEmpty
          ? [replyUci]
          : const <String>[];
  final punishmentText = _humanizeLine(context.fenAfter, punishmentLine);
  final reply = punishmentText.isEmpty ? null : punishmentText.first;

  // UNCONFIRMED EVALUATION / CONFLICTING ANALYSIS DATA (isSame is true BUT quality is blunder/mistake/inaccuracy)
  if (move.quality == EngineMoveQuality.unknown ||
      move.structuredEvalBefore.kind == EvalKind.unknown ||
      move.structuredEvalAfter.kind == EvalKind.unknown ||
      (isSame && isMistakeQuality)) {
    final punishmentTextConflicting = reply == null
        ? 'Stockfish did not return a concrete opponent reply for this position.'
        : 'The service returned $reply after ${context.san}, but this response remains unconfirmed.';

    return EngineMoveExplanation(
      whatFailed: 'After ${context.moveLabel} (${context.san}), Stockfish evaluation was unconfirmed due to conflicting or incomplete classification data.',
      opponentPunishment: punishmentTextConflicting,
      whyItWorks: 'The engine search yielded an unconfirmed or conflicting evaluation.',
      consequence: 'Stockfish evaluation was unconfirmed for this position.',
      betterChoice: 'Stockfish evaluation was unconfirmed for this position.',
      lessonTitle: 'Unconfirmed Position Analysis',
      lessonText: 'Positions with unconfirmed evaluation should be checked at higher search depth.',
      reflectionQuestion: 'Before making a decision, verify whether the position requires deeper calculation.',
    );
  }

  final playerIsWhite = context.isWhiteMove;
  final rawEval = move.evalAfterCp;
  final playerEval = rawEval == null ? null : (playerIsWhite ? rawEval : -rawEval);
  final playerIsLosing = playerEval != null && playerEval < -100;

  // 1. EXACT BEST MOVE CONFIRMED (Physical match + non-mistake quality)
  if (isSame) {
    final whatFailed =
        'By playing ${context.moveLabel} (${context.san}), you chose Stockfish\'s top recommended move in this position.';
    final whyItWorks =
        'Playing ${context.san} maintains your position according to Stockfish\'s principal line.';
    final opponentPunishment = reply == null
        ? 'Stockfish did not return a concrete opponent reply for this position.'
        : 'After ${context.san}, the opponent\'s best response is $reply.';
    final consequence =
        'Stockfish estimates the resulting position at ${move.structuredEvalAfter.formatDisplay(forWhite: playerIsWhite)} from your perspective. This is an engine search result, not a guarantee of the game outcome.';
    final betterChoice = playerIsLosing
        ? 'Stockfish confirmed ${context.san} as the best move in this position, minimizing disadvantage.'
        : 'Stockfish confirmed ${context.san} as the best move in this position.';
    const lessonTitle = 'Optimal Play & Control';
    const lessonText =
        'Active, well-calculated moves preserve control and restrict opponent counterplay. Keep identifying top recommendations in key moments.';
    final reflectionQuestion =
        'Notice how ${context.san} preserved control. What key squares or ideas did this move secure?';

    return EngineMoveExplanation(
      whatFailed: whatFailed,
      opponentPunishment: opponentPunishment,
      whyItWorks: whyItWorks,
      consequence: consequence,
      betterChoice: betterChoice,
      lessonTitle: lessonTitle,
      lessonText: lessonText,
      reflectionQuestion: reflectionQuestion,
    );
  }

  // 2. STRONG / EXCELLENT / GOOD ALTERNATIVE MOVE (DISTINCT FROM TOP RECOMMENDATION)
  if (!isMistakeQuality &&
      (move.quality == EngineMoveQuality.best ||
          move.quality == EngineMoveQuality.excellent ||
          move.quality == EngineMoveQuality.good)) {
    final whatFailed =
        'By playing ${context.moveLabel} (${context.san}), you chose a strong alternative that preserves a solid position.';
    final whyItWorks =
        'Playing ${context.san} maintains a strong position, though Stockfish slightly preferred $best.';
    final opponentPunishment = reply == null
        ? 'Stockfish did not return a concrete opponent reply for this position.'
        : 'After ${context.san}, the opponent\'s best response is $reply.';
    final consequence =
        'Stockfish verifies that this alternative maintains your position well.';
    final betterChoice =
        'By playing ${context.san}, you kept a strong position. Stockfish slightly preferred $best.';
    const lessonTitle = 'Alternative Candidate Moves';
    const lessonText =
        'Positions often have more than one good move. Compare your candidate move against the top recommendation to see small tactical nuances.';
    final reflectionQuestion =
        'What subtle difference between ${context.san} and $best made Stockfish prefer $best?';

    return EngineMoveExplanation(
      whatFailed: whatFailed,
      opponentPunishment: opponentPunishment,
      whyItWorks: whyItWorks,
      consequence: consequence,
      betterChoice: betterChoice,
      lessonTitle: lessonTitle,
      lessonText: lessonText,
      reflectionQuestion: reflectionQuestion,
    );
  }

  // 3. EXPLANATION FOR ACTUAL MISTAKES / BLUNDERS / INACCURACIES
  final tactical = _buildTacticalInsight(move, context);

  final fallbackFailure = switch (move.quality) {
    EngineMoveQuality.blunder =>
      'By playing ${context.moveLabel} (${context.san}), this move caused a major evaluation swing and gave your opponent a concrete tactical opportunity.',
    EngineMoveQuality.mistake =>
      'By playing ${context.moveLabel} (${context.san}), this move gave your opponent a concrete way to improve their position and made your game significantly harder.',
    EngineMoveQuality.inaccuracy =>
      'By playing ${context.moveLabel} (${context.san}), this move was sub-optimal and allowed a stronger continuation that could have been prevented.',
    _ => 'By playing ${context.moveLabel} (${context.san}), this was not the engine\'s preferred continuation.',
  };

  final whatFailed = tactical.whatFailed ?? fallbackFailure;

  final opponentPunishment = reply == null
      ? 'Stockfish did not return a concrete opponent reply for this position.'
      : punishmentText.length <= 1
          ? 'After ${context.san}, the strongest reply is $reply.'
          : 'After ${context.san}, the strongest reply is $reply. Concrete line: ${punishmentText.join(' → ')}.';

  final whyItWorks = tactical.whyItWorks ??
      (punishmentText.length > 1
          ? 'One continuation from the engine search is ${punishmentText.join(' → ')}. Compare the resulting position; this line alone does not establish that the replies are forced.'
          : 'After imagining your move, the missing step was to search for the opponent\'s strongest forcing response before committing.');

  var consequence = _consequenceText(move, playerIsWhite);
  if (tactical.consequenceDetail != null) {
    consequence = '$consequence ${tactical.consequenceDetail}';
  }

  var betterChoice = best.isEmpty
      ? 'Stockfish found a stronger move here.'
      : 'Instead of ${context.san}, Stockfish preferred $best.';

  if (move.bestLineUci.length > 1) {
    final bestLine = _humanizeLine(context.fenBefore, move.bestLineUci);
    if (bestLine.length > 1) {
      betterChoice = '$betterChoice One engine continuation is ${bestLine.join(' → ')}.';
    }
  }

  final lesson = tactical.lesson ?? _lessonFor(move, context);
  final reflectionQuestion = _generateReflectionQuestion(context, move);

  return EngineMoveExplanation(
    whatFailed: whatFailed,
    opponentPunishment: opponentPunishment,
    whyItWorks: whyItWorks,
    consequence: consequence,
    betterChoice: betterChoice,
    lessonTitle: lesson.title,
    lessonText: lesson.text,
    reflectionQuestion: reflectionQuestion,
  );
}

bool isSameMove(
  String fenBefore,
  String bestMoveUci,
  String playedSan, {
  String? fenAfter,
}) {
  if (bestMoveUci.trim().isEmpty || playedSan.trim().isEmpty) return false;

  const validator = ChessMoveValidator();
  final valResult = validator.validate(
    fenBefore: fenBefore,
    playedInput: playedSan,
    targetInput: bestMoveUci,
  );

  return valResult.isExactMatch;
}

String _generateReflectionQuestion(
  PersonalGameMove context,
  EngineMoveResult move,
) {
  final san = context.san;
  if (san.startsWith('K') || san.startsWith('k')) {
    return 'Before playing $san, did you check which key squares or pawns your king was defending on its previous square, and whether moving away allowed an enemy piece or passed pawn to advance?';
  }
  if (context.isCapture) {
    return 'Before making the capture $san, did you calculate the opponent\'s forcing recapture or counter-attack on the next move?';
  }
  if (context.givesCheck) {
    return 'Before giving check with $san, did you verify whether the check actually improved your position or if it just allowed the opponent\'s king/piece to reach a better square?';
  }
  return 'Before committing $san, did you ask what threat your move abandoned, and what forcing response your opponent could play next?';
}

class _TacticalInsight {
  final String? whatFailed;
  final String? whyItWorks;
  final String? consequenceDetail;
  final _Lesson? lesson;

  const _TacticalInsight({
    this.whatFailed,
    this.whyItWorks,
    this.consequenceDetail,
    this.lesson,
  });
}

enum _CaptureSequenceType {
  opponentRecaptureOnPlayerSquare, // Player captured on S1, opponent immediately recaptured on S1
  playerRecaptureOnOpponentSquare, // Opponent captured on S2, player immediately recaptured on S2 in PV line
  unrelatedCounterCapture,         // Player captured on S1, opponent captured an UNRELATED piece on S3 != S1
  uncompensatedCapture,            // Opponent captured on S2, no recapture on S2
}

bool _isGenuineRecaptureSequence(
  String fenAfter,
  String replyUci,
  List<String> punishmentLine,
) {
  if (punishmentLine.length < 2) return false;
  final replyTo = replyUci.substring(2, 4);
  final recaptureUci = punishmentLine[1];
  if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(recaptureUci)) return false;

  final recaptureTo = recaptureUci.substring(2, 4);
  if (recaptureTo != replyTo) return false;

  try {
    final chessBoard = chess_lib.Chess.fromFEN(fenAfter);
    final replyFrom = replyUci.substring(0, 2);
    final replyMap = <String, String>{'from': replyFrom, 'to': replyTo};
    if (replyUci.length == 5) replyMap['promotion'] = replyUci[4];

    if (!chessBoard.move(replyMap)) return false;

    final recaptureFrom = recaptureUci.substring(0, 2);
    final recaptMap = <String, String>{'from': recaptureFrom, 'to': recaptureTo};
    if (recaptureUci.length == 5) recaptMap['promotion'] = recaptureUci[4];

    return chessBoard.move(recaptMap);
  } catch (_) {
    return false;
  }
}

_CaptureSequenceType _determineCaptureSequenceType({
  required PersonalGameMove context,
  required String replyUci,
  required List<String> punishmentLine,
  required String? captured,
  required Map<String, String> boardBefore,
  required Map<String, String> boardAfter,
  required Map<String, String> boardAfterReply,
}) {
  if (captured == null) return _CaptureSequenceType.uncompensatedCapture;

  final replyTo = replyUci.substring(2, 4);

  if (context.isCapture) {
    final playerToMatch = RegExp(r'([a-h][1-8])').firstMatch(context.san);
    final playerTo = playerToMatch?.group(1);

    if (playerTo != null && replyTo == playerTo) {
      // Situation 1: Player captured on S1, opponent immediately recaptured on S1!
      return _CaptureSequenceType.opponentRecaptureOnPlayerSquare;
    } else if (playerTo != null && replyTo != playerTo) {
      // Situation 4: Player captured on S1, opponent captured an UNRELATED piece on S3 != S1!
      return _CaptureSequenceType.unrelatedCounterCapture;
    }
  }

  // Situation 2: Opponent captured on S2, check if player's subsequent move in punishmentLine LEGALLY recaptures on S2
  if (_isGenuineRecaptureSequence(context.fenAfter, replyUci, punishmentLine)) {
    return _CaptureSequenceType.playerRecaptureOnOpponentSquare;
  }

  // Situation 3: Uncompensated capture without legal recapture
  return _CaptureSequenceType.uncompensatedCapture;
}

_TacticalInsight _buildTacticalInsight(
  EngineMoveResult move,
  PersonalGameMove context,
) {
  final replyUci = move.opponentBestReplyUci?.trim() ?? '';

  try {
    final boardBefore = parseFenBoard(context.fenBefore);
    final boardAfter = parseFenBoard(context.fenAfter);

    if (RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(replyUci)) {
      final position = chess_lib.Chess.fromFEN(context.fenAfter);
      final legal = position.move({
        'from': replyUci.substring(0, 2),
        'to': replyUci.substring(2, 4),
        if (replyUci.length == 5) 'promotion': replyUci[4],
      });
      if (legal && position.in_checkmate) {
        return _TacticalInsight(
          whatFailed: 'After ${context.moveLabel} (${context.san}), your opponent can deliver checkmate immediately.',
          whyItWorks: '${humanizeUciMove(context.fenAfter, replyUci)} delivers checkmate: the king is in check and there is no legal response.',
          consequenceDetail: 'The game ends after this reply; there is no next move for the defending side.',
          lesson: const _Lesson(
            'King Safety',
            'Before committing to a move, check whether the opponent has an immediate mating reply.',
          ),
        );
      }
    }

    // King move analysis: check if king was on a central/blockade square (d4, e4, d5, e5, c4, f4, c5, f5) and moved away
    if (context.san.startsWith('K') || context.san.startsWith('k')) {
      final userIsWhite = context.isWhiteMove;
      final kingPrev = _kingSquare(boardBefore, userIsWhite);
      final kingCurr = _kingSquare(boardAfter, userIsWhite);
      if (kingPrev != null && kingCurr != null) {
        const centralSquares = {'d4', 'e4', 'd5', 'e5', 'c4', 'f4', 'c5', 'f5'};
        final wasCentral = centralSquares.contains(kingPrev);
        final isCentral = centralSquares.contains(kingCurr);

        if (wasCentral && !isCentral) {
          return _TacticalInsight(
            whatFailed: 'By playing ${context.moveLabel} (${context.san}), your king moved from $kingPrev to $kingCurr, stepping away from central control squares.',
            whyItWorks: 'Moving the king from $kingPrev to $kingCurr reduced your active control over key central squares.',
            consequenceDetail: 'Stepping away from central control alters king placement and central square control.',
            lesson: const _Lesson(
              'King Activity & Blockade',
              'In pawn endgames and active king positions, king activity is paramount. Never retreat your king away from key control squares without verifying whether the opponent\'s passed pawn or king can advance freely.',
            ),
          );
        } else {
          return _TacticalInsight(
            whatFailed: 'By playing ${context.moveLabel} (${context.san}), your king moved from $kingPrev to $kingCurr.',
            whyItWorks: 'Stockfish indicates that moving the king from $kingPrev to $kingCurr was less active than the top recommendation.',
            consequenceDetail: 'The move altered king placement, allowing Stockfish\'s preferred continuation.',
            lesson: const _Lesson(
              'King Safety & Placement',
              'Evaluate king placement carefully based on the active piece activity and pawn structure on the board.',
            ),
          );
        }
      }
    }

    if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(replyUci)) {
      return const _TacticalInsight();
    }

    final replyFrom = replyUci.substring(0, 2);
    final replyTo = replyUci.substring(2, 4);
    final replyPiece = boardAfter[replyFrom];
    if (replyPiece == null) return const _TacticalInsight();

    final userIsWhite = context.isWhiteMove;
    final opponentIsWhite = !userIsWhite;
    final captured = _capturedPieceForMove(boardAfter, replyUci);
    final capturedSquare = captured == null ? null : _capturedSquareForMove(boardAfter, replyUci);
    final boardAfterReply = applyUciMoveToBoard(boardAfter, replyUci);
    final replyDescription = _humanizeUciOnBoard(boardAfter, replyUci);

    final userKing = _kingSquare(boardAfterReply, userIsWhite);
    final givesCheck = userKing != null &&
        _isSquareAttacked(boardAfterReply, userKing, byWhite: opponentIsWhite);

    final attackedTargets = _targetsAttackedByPiece(
      boardAfterReply,
      replyTo,
      targetWhite: userIsWhite,
    );
    final nonKingTargets = attackedTargets
        .where((target) => _pieceNameFromSymbol(target.piece) != 'king')
        .toList(growable: false)
      ..sort((a, b) => _pieceValue(b.piece).compareTo(_pieceValue(a.piece)));
    _BoardTarget? queenTarget;
    for (final target in nonKingTargets) {
      if (_pieceNameFromSymbol(target.piece) == 'queen') {
        queenTarget = target;
        break;
      }
    }
    final meaningfulForkTargets = nonKingTargets
        .where((target) => _pieceValue(target.piece) >= 3)
        .toList(growable: false);
    final newlyLoose = _findNewlyLoosePiece(context);

    if (captured != null) {
      final capturedName = _pieceNameFromSymbol(captured);
      final attackerName = _pieceNameFromSymbol(replyPiece);
      final capturedValue = _pieceValue(captured);
      final attackerValue = _pieceValue(replyPiece);
      final valueText = attackerValue < capturedValue
          ? ' The $attackerName is worth less than the $capturedName, so the exchange is especially favorable for your opponent.'
          : '';

      final seqType = _determineCaptureSequenceType(
        context: context,
        replyUci: replyUci,
        punishmentLine: move.opponentPunishmentLineUci,
        captured: captured,
        boardBefore: boardBefore,
        boardAfter: boardAfter,
        boardAfterReply: boardAfterReply,
      );

      final String failureText;
      final String detailText;

      switch (seqType) {
        case _CaptureSequenceType.opponentRecaptureOnPlayerSquare:
        case _CaptureSequenceType.playerRecaptureOnOpponentSquare:
          failureText =
              'By playing ${context.moveLabel} (${context.san}), your move allowed a piece exchange starting with the capture of your $capturedName${capturedSquare == null ? '' : ' on $capturedSquare'}.';
          detailText =
              'The exchange begins with the capture of your $capturedName.';
          break;
        case _CaptureSequenceType.unrelatedCounterCapture:
          failureText =
              'By playing ${context.moveLabel} (${context.san}), after your capture, your move allowed an immediate counter-capture of your $capturedName${capturedSquare == null ? '' : ' on $capturedSquare'}.';
          detailText =
              'While you captured a piece, your opponent responded with an unrelated counter-capture on $capturedSquare.';
          break;
        case _CaptureSequenceType.uncompensatedCapture:
          failureText =
              'By playing ${context.moveLabel} (${context.san}), your move allowed an immediate capture of your $capturedName${capturedSquare == null ? '' : ' on $capturedSquare'}.';
          detailText =
              'The punishment starts with the loss of your $capturedName, so this is a concrete material consequence rather than an abstract engine preference.';
          break;
      }

      return _TacticalInsight(
        whatFailed: failureText,
        whyItWorks: '$replyDescription converts the opportunity immediately.$valueText',
        consequenceDetail: detailText,
        lesson: const _Lesson(
          'Loose Piece Detection',
          'Before committing, scan every piece the opponent can capture immediately. If one of your pieces becomes loose or under-defended after your move, fix that before pursuing your plan.',
        ),
      );
    }

    if (givesCheck && meaningfulForkTargets.isNotEmpty) {
      final target = meaningfulForkTargets.first;
      final targetName = _pieceNameFromSymbol(target.piece);
      return _TacticalInsight(
        whatFailed: 'By playing ${context.moveLabel} (${context.san}), your move allowed a forcing check that also attacks your $targetName on ${target.square}.',
        whyItWorks: '$replyDescription gives check, so you must answer the king threat first. At the same time, the ${_pieceNameFromSymbol(replyPiece)} is attacking your $targetName on ${target.square}. That is why the reply gains time and creates a second threat.',
        consequenceDetail: 'Because the check must be answered first, your opponent can keep the second target under pressure on the next move.',
        lesson: const _Lesson(
          'Opponent Response',
          'Checks come first. Before making your move, imagine the opponent\'s checks and ask whether any of them also attack another piece or create a second threat.',
        ),
      );
    }

    if (givesCheck) {
      return _TacticalInsight(
        whatFailed: 'By playing ${context.moveLabel} (${context.san}), your move allowed a forcing check, so your opponent can take the initiative immediately.',
        whyItWorks: '$replyDescription is check. You must respond to the king threat before you can continue your own plan, which lets your opponent dictate the next move.',
        consequenceDetail: 'The practical cost is loss of initiative: your next move is constrained by the check instead of improving your own position.',
        lesson: const _Lesson(
          'Opponent Response',
          'After imagining your candidate move, always check the opponent\'s checks first. A forcing check can override everything you intended to do next.',
        ),
      );
    }

    if (meaningfulForkTargets.length >= 2) {
      final first = meaningfulForkTargets[0];
      final second = meaningfulForkTargets[1];
      final attackerName = _pieceNameFromSymbol(replyPiece);
      return _TacticalInsight(
        whatFailed: 'By playing ${context.moveLabel} (${context.san}), your move allowed a double attack on two pieces simultaneously.',
        whyItWorks: '$replyDescription places the $attackerName so it attacks your ${_pieceNameFromSymbol(first.piece)} on ${first.square} and your ${_pieceNameFromSymbol(second.piece)} on ${second.square}.',
        consequenceDetail: 'The double attack creates two simultaneous threats.',
        lesson: const _Lesson(
          'Opponent Response',
          'Before moving, scan the squares where an enemy knight, queen, rook, or bishop could create two threats at once. Double attacks are often visible one move before they happen.',
        ),
      );
    }

    if (queenTarget != null) {
      return _TacticalInsight(
        whatFailed: 'By playing ${context.moveLabel} (${context.san}), your move allowed the opponent to attack your queen with tempo.',
        whyItWorks: '$replyDescription attacks your queen on ${queenTarget.square}. Because the queen is so valuable, you normally have to move it, giving your opponent a free tempo to improve the position.',
        consequenceDetail: 'The immediate consequence is loss of time: you are forced to react while your opponent develops another threat or improves a piece.',
        lesson: const _Lesson(
          'Move Safety',
          'After imagining your move, check whether the opponent can attack your queen while improving another piece. Queen attacks often gain a free tempo.',
        ),
      );
    }

    if (newlyLoose != null) {
      final name = _pieceNameFromSymbol(newlyLoose.piece);
      return _TacticalInsight(
        whatFailed: 'After ${context.moveLabel} (${context.san}), your $name on ${newlyLoose.square} became loose: it is attacked and has no defender.',
        whyItWorks: '$replyDescription exploits the changed board while your $name on ${newlyLoose.square} remains vulnerable. The tactical problem began when your move changed the protection of that piece.',
        consequenceDetail: 'Even if the loose piece is not captured immediately, you now have to spend time defending or moving it.',
        lesson: const _Lesson(
          'Loose Piece Detection',
          'After imagining your move, rescan every piece you own. Ask which pieces lost a defender, became attacked, or were left hanging by the move you are considering.',
        ),
      );
    }

    final line = _humanizeLine(
      context.fenAfter,
      move.opponentPunishmentLineUci.isNotEmpty
          ? move.opponentPunishmentLineUci
          : [replyUci],
    );
    if (line.length > 1) {
      return _TacticalInsight(
        whatFailed:
            'Stockfish evaluated ${context.moveLabel} (${context.san}) below its preferred move in this search.',
        whyItWorks:
            'One continuation from the engine search is ${line.join(' → ')}. This variation does not establish that each reply is forced; compare legal alternatives before drawing a tactical conclusion.',
        consequenceDetail:
            'The variation illustrates a possible continuation, not a proven conversion of the advantage.',
        lesson: const _Lesson(
          'Board Change Awareness',
          'Do not evaluate only your move. Visualize the opponent\'s reply and a continuation after it, then compare other legal responses.',
        ),
      );
    }
  } on FormatException {
    return const _TacticalInsight();
  }

  return const _TacticalInsight();
}

class _BoardTarget {
  final String square;
  final String piece;

  const _BoardTarget(this.square, this.piece);
}

_BoardTarget? _findNewlyLoosePiece(PersonalGameMove context) {
  try {
    final before = parseFenBoard(context.fenBefore);
    final after = parseFenBoard(context.fenAfter);
    final userIsWhite = context.isWhiteMove;
    final candidates = <_BoardTarget>[];

    for (final entry in after.entries) {
      final piece = entry.value;
      if (_isWhitePiece(piece) != userIsWhite || _pieceNameFromSymbol(piece) == 'king') {
        continue;
      }
      final attacked = _isSquareAttacked(after, entry.key, byWhite: !userIsWhite);
      final defended = _isSquareAttacked(after, entry.key, byWhite: userIsWhite);
      if (!attacked || defended) continue;

      final samePieceBefore = before[entry.key] == piece;
      final wasLooseBefore = samePieceBefore &&
          _isSquareAttacked(before, entry.key, byWhite: !userIsWhite) &&
          !_isSquareAttacked(before, entry.key, byWhite: userIsWhite);
      if (!wasLooseBefore) candidates.add(_BoardTarget(entry.key, piece));
    }

    if (candidates.isEmpty) return null;
    candidates.sort((a, b) => _pieceValue(b.piece).compareTo(_pieceValue(a.piece)));
    return candidates.first;
  } on FormatException {
    return null;
  }
}

List<_BoardTarget> _targetsAttackedByPiece(
  Map<String, String> board,
  String from, {
  required bool targetWhite,
}) {
  final result = <_BoardTarget>[];
  for (final square in _attackedSquaresFrom(board, from)) {
    final piece = board[square];
    if (piece != null && _isWhitePiece(piece) == targetWhite) {
      result.add(_BoardTarget(square, piece));
    }
  }
  return result;
}

String? _kingSquare(Map<String, String> board, bool white) {
  final king = white ? '♔' : '♚';
  for (final entry in board.entries) {
    if (entry.value == king) return entry.key;
  }
  return null;
}

bool _isSquareAttacked(
  Map<String, String> board,
  String square, {
  required bool byWhite,
}) {
  for (final entry in board.entries) {
    if (_isWhitePiece(entry.value) != byWhite) continue;
    if (_attackedSquaresFrom(board, entry.key).contains(square)) return true;
  }
  return false;
}

List<String> _attackedSquaresFrom(Map<String, String> board, String from) {
  final piece = board[from];
  if (piece == null) return const [];
  final file = from.codeUnitAt(0) - 'a'.codeUnitAt(0);
  final rank = int.parse(from.substring(1));
  final result = <String>[];

  void add(int f, int r) {
    if (f < 0 || f > 7 || r < 1 || r > 8) return;
    result.add('${String.fromCharCode('a'.codeUnitAt(0) + f)}$r');
  }

  void ray(int df, int dr) {
    var f = file + df;
    var r = rank + dr;
    while (f >= 0 && f <= 7 && r >= 1 && r <= 8) {
      final square = '${String.fromCharCode('a'.codeUnitAt(0) + f)}$r';
      result.add(square);
      if (board.containsKey(square)) break;
      f += df;
      r += dr;
    }
  }

  switch (piece) {
    case '♙':
      add(file - 1, rank + 1);
      add(file + 1, rank + 1);
      break;
    case '♟':
      add(file - 1, rank - 1);
      add(file + 1, rank - 1);
      break;
    case '♘':
    case '♞':
      for (final delta in const [
        [-2, -1], [-2, 1], [-1, -2], [-1, 2],
        [1, -2], [1, 2], [2, -1], [2, 1],
      ]) {
        add(file + delta[0], rank + delta[1]);
      }
      break;
    case '♗':
    case '♝':
      ray(1, 1);
      ray(1, -1);
      ray(-1, 1);
      ray(-1, -1);
      break;
    case '♖':
    case '♜':
      ray(1, 0);
      ray(-1, 0);
      ray(0, 1);
      ray(0, -1);
      break;
    case '♕':
    case '♛':
      ray(1, 1);
      ray(1, -1);
      ray(-1, 1);
      ray(-1, -1);
      ray(1, 0);
      ray(-1, 0);
      ray(0, 1);
      ray(0, -1);
      break;
    case '♔':
    case '♚':
      for (var df = -1; df <= 1; df++) {
        for (var dr = -1; dr <= 1; dr++) {
          if (df != 0 || dr != 0) add(file + df, rank + dr);
        }
      }
      break;
  }

  return result;
}

String? _capturedPieceForMove(Map<String, String> board, String uci) {
  final to = uci.substring(2, 4);
  final direct = board[to];
  if (direct != null) return direct;

  final from = uci.substring(0, 2);
  final piece = board[from];
  if ((piece == '♙' || piece == '♟') && from[0] != to[0]) {
    return board['${to[0]}${from[1]}'];
  }
  return null;
}

String? _capturedSquareForMove(Map<String, String> board, String uci) {
  final to = uci.substring(2, 4);
  if (board[to] != null) return to;
  final from = uci.substring(0, 2);
  final piece = board[from];
  if ((piece == '♙' || piece == '♟') && from[0] != to[0]) {
    return '${to[0]}${from[1]}';
  }
  return null;
}

List<String> _humanizeLine(String fen, List<String> moves) {
  if (moves.isEmpty) return const [];
  try {
    var board = parseFenBoard(fen);
    final result = <String>[];
    for (final move in moves) {
      if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(move)) break;
      result.add(_humanizeUciOnBoard(board, move));
      board = applyUciMoveToBoard(board, move);
    }
    return result;
  } on FormatException {
    return moves;
  }
}

String humanizeUciMove(String fen, String uci) {
  try {
    return _humanizeUciOnBoard(parseFenBoard(fen), uci);
  } on FormatException {
    return uci.trim();
  }
}

String _humanizeUciOnBoard(Map<String, String> board, String uci) {
  final clean = uci.trim();
  if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(clean)) return clean;

  final from = clean.substring(0, 2);
  final to = clean.substring(2, 4);
  final piece = board[from];
  if (piece == null) return clean;

  if ((piece == '♔' || piece == '♚') && from[0] == 'e' && to[0] == 'g') {
    return 'castle kingside';
  }
  if ((piece == '♔' || piece == '♚') && from[0] == 'e' && to[0] == 'c') {
    return 'castle queenside';
  }

  final name = _pieceNameFromSymbol(piece);
  final captured = _capturedPieceForMove(board, clean);
  final promotion = clean.length == 5 ? ' and promote to ${_promotionName(clean[4])}' : '';

  if (name == 'pawn') {
    return captured != null
        ? 'capture on $to with the pawn from $from$promotion'
        : 'move the pawn from $from to $to$promotion';
  }
  return captured != null
      ? 'capture on $to with the $name from $from$promotion'
      : 'move the $name from $from to $to$promotion';
}

_Lesson _lessonFor(EngineMoveResult move, PersonalGameMove context) {
  if (context.givesCheck || context.isCapture) {
    return const _Lesson(
      'Opponent Response',
      'Checks and captures feel forcing, but they still need a final verification. Ask what the opponent\'s strongest reply is after your move.',
    );
  }
  if (move.lossCp >= 180 || move.structuredEvalBefore.kind == EvalKind.mate || move.structuredEvalAfter.kind == EvalKind.mate) {
    return const _Lesson(
      'Move Safety',
      'Before committing, compare your candidate move against the opponent\'s checks, captures, and direct threats. Do not stop after finding a move that looks good.',
    );
  }
  return const _Lesson(
    'Board Change Awareness',
    'After imagining your move, rescan the board for newly opened lines, weakened squares, and pieces that became undefended.',
  );
}

class _Lesson {
  final String title;
  final String text;

  const _Lesson(this.title, this.text);
}

String _impactText(EngineMoveResult move) {
  final bKind = move.structuredEvalBefore.kind;
  final aKind = move.structuredEvalAfter.kind;

  if (bKind == EvalKind.mate || aKind == EvalKind.mate) {
    if (bKind == EvalKind.mate && aKind == EvalKind.mate) {
      final bM = move.structuredEvalBefore.mateInMoves ?? 0;
      final aM = move.structuredEvalAfter.mateInMoves ?? 0;
      if (bM != aM) {
        return 'The move altered the mate sequence (forced mate in $bM moves vs mate in $aM moves).';
      }
      return 'The position leads to a forced checkmate.';
    }
    if (aKind == EvalKind.mate) {
      final winner = move.structuredEvalAfter.winnerColor;
      return 'The move allows a forced checkmate sequence for $winner.';
    }
    return 'The move changes a forced mate line into an endgame evaluation.';
  }

  if (move.lossCp >= 1000) return 'The mistake resulted in a decisive evaluation swing (over 10 pawns).';
  if (move.lossCp == 0) return 'Stockfish evaluates this move with zero centipawn loss.';
  final pawns = move.lossCp / 100.0;
  return 'The engine swing is roughly ${pawns.toStringAsFixed(1)} pawn${pawns >= 1.5 ? 's' : ''}.';
}

String _consequenceText(EngineMoveResult move, bool playerIsWhite) {
  final afterReply = move.evalAfterReplyCp;
  final afterRaw = afterReply ?? move.evalAfterCp;
  if (afterRaw == null) return _impactText(move);

  // Convert White-absolute evaluation to actual player's perspective
  final playerEval = playerIsWhite ? afterRaw : -afterRaw;

  if (move.lossCp >= 1000) {
    return 'The error caused a decisive evaluation swing (over 10 pawns). Stockfish shows how the advantage is converted into a winning position.';
  }

  final swing = move.lossCp / 100.0;
  final advantagePawns = (playerEval.abs() / 100.0).clamp(0.0, 10.0);
  final swingText = 'The mistake gave away about ${swing.toStringAsFixed(1)} pawn${swing >= 1.5 ? 's' : ''} of evaluation.';

  if (playerEval <= -50) {
    return '$swingText After the strongest reply, the opponent is about ${advantagePawns.toStringAsFixed(1)} pawn${advantagePawns >= 1.5 ? 's' : ''} better.';
  }
  if (playerEval >= 50) {
    return '$swingText You still remain about ${advantagePawns.toStringAsFixed(1)} pawn${advantagePawns >= 1.5 ? 's' : ''} better, but the error reduced your advantage.';
  }
  return '$swingText After the strongest reply, the position is approximately equal.';
}

bool _isWhitePiece(String piece) => '♔♕♖♗♘♙'.contains(piece);

int _pieceValue(String piece) {
  switch (_pieceNameFromSymbol(piece)) {
    case 'queen': return 9;
    case 'rook': return 5;
    case 'bishop':
    case 'knight': return 3;
    case 'pawn': return 1;
    case 'king': return 100;
    default: return 0;
  }
}

String _pieceNameFromSymbol(String? piece) {
  switch (piece) {
    case '♘':
    case '♞': return 'knight';
    case '♗':
    case '♝': return 'bishop';
    case '♖':
    case '♜': return 'rook';
    case '♕':
    case '♛': return 'queen';
    case '♔':
    case '♚': return 'king';
    case '♙':
    case '♟': return 'pawn';
    default: return 'piece';
  }
}

String _promotionName(String piece) {
  switch (piece.toLowerCase()) {
    case 'q': return 'a queen';
    case 'r': return 'a rook';
    case 'b': return 'a bishop';
    case 'n': return 'a knight';
    default: return piece;
  }
}
