import 'dart:convert';
import 'dart:io';

import 'local_stockfish_transport.dart';
import 'personal_game_analysis.dart';

enum EngineMoveQuality {
  best,
  excellent,
  good,
  inaccuracy,
  mistake,
  blunder,
  unknown,
}

enum EvalKind { centipawns, mate, terminalDraw, unknown }

class StructuredEvaluation {
  final EvalKind kind;
  final int? centipawns;   // White-absolute centipawns if kind == centipawns
  final int? mateInMoves;  // Mate distance in moves if kind == mate
  final String winnerColor; // 'white', 'black', or 'none'

  const StructuredEvaluation.centipawns(int cp)
      : kind = EvalKind.centipawns,
        centipawns = cp,
        mateInMoves = null,
        winnerColor = cp > 0 ? 'white' : (cp < 0 ? 'black' : 'none');

  StructuredEvaluation.mate({
    required int moves,
    required String winner,
  })  : kind = EvalKind.mate,
        centipawns = null,
        mateInMoves = moves.abs(),
        winnerColor = winner;

  const StructuredEvaluation.draw()
      : kind = EvalKind.terminalDraw,
        centipawns = 0,
        mateInMoves = null,
        winnerColor = 'none';

  const StructuredEvaluation.unknown()
      : kind = EvalKind.unknown,
        centipawns = null,
        mateInMoves = null,
        winnerColor = 'none';

  factory StructuredEvaluation.fromRawCp(int? cp) {
    if (cp == null) return const StructuredEvaluation.unknown();
    if (cp.abs() >= 90000) {
      final winner = cp > 0 ? 'white' : 'black';
      final distancePenalty = 100000 - cp.abs();
      final moves = (distancePenalty / 10).round().clamp(1, 99);
      return StructuredEvaluation.mate(moves: moves, winner: winner);
    }
    return StructuredEvaluation.centipawns(cp);
  }

  factory StructuredEvaluation.fromJson({
    required String? kindStr,
    required int? rawCp,
    required int? mateMoves,
    required String? winnerColor,
  }) {
    final kindLower = kindStr?.toLowerCase();
    if (kindLower == 'mate' && mateMoves != null) {
      return StructuredEvaluation.mate(
        moves: mateMoves,
        winner: winnerColor?.toLowerCase() ?? 'none',
      );
    }
    if (kindLower == 'draw') {
      return const StructuredEvaluation.draw();
    }
    if (kindLower == 'unknown') {
      return const StructuredEvaluation.unknown();
    }
    if (rawCp != null) {
      return StructuredEvaluation.fromRawCp(rawCp);
    }
    return const StructuredEvaluation.unknown();
  }

  /// Formats the evaluation cleanly from player's perspective or White
  String formatDisplay({bool forWhite = true}) {
    switch (kind) {
      case EvalKind.centipawns:
        final val = forWhite ? centipawns! : -centipawns!;
        final pawns = (val / 100.0).toStringAsFixed(1);
        return val >= 0 ? '+$pawns' : pawns;
      case EvalKind.mate:
        final isWin = (winnerColor == 'white' && forWhite) || (winnerColor == 'black' && !forWhite);
        final sign = isWin ? '+' : '-';
        return '${sign}M$mateInMoves';
      case EvalKind.terminalDraw:
        return '0.0 (Draw)';
      case EvalKind.unknown:
        return 'N/A';
    }
  }
}

String engineMoveQualityLabel(EngineMoveQuality quality) {
  switch (quality) {
    case EngineMoveQuality.best:
      return 'Best';
    case EngineMoveQuality.excellent:
      return 'Excellent';
    case EngineMoveQuality.good:
      return 'Good';
    case EngineMoveQuality.inaccuracy:
      return 'Inaccuracy';
    case EngineMoveQuality.mistake:
      return 'Mistake';
    case EngineMoveQuality.blunder:
      return 'Blunder';
    case EngineMoveQuality.unknown:
      return 'Unclassified';
  }
}

EngineMoveQuality _qualityFromJson(Object? value) {
  switch (value?.toString().toLowerCase()) {
    case 'best':
      return EngineMoveQuality.best;
    case 'excellent':
      return EngineMoveQuality.excellent;
    case 'good':
      return EngineMoveQuality.good;
    case 'inaccuracy':
      return EngineMoveQuality.inaccuracy;
    case 'mistake':
      return EngineMoveQuality.mistake;
    case 'blunder':
      return EngineMoveQuality.blunder;
    default:
      return EngineMoveQuality.unknown;
  }
}

class EngineMoveResult {
  final int plyIndex;
  final String san;
  final String bestMoveUci;
  final String? bestMoveSan;
  final int? evalBeforeCp;
  final int? evalAfterCp;
  final int lossCp;
  final EngineMoveQuality quality;
  final String? opponentBestReplyUci;
  final int? evalAfterReplyCp;
  final List<String> opponentPunishmentLineUci;
  final List<String> bestLineUci;
  final StructuredEvaluation? explicitStructuredEvalBefore;
  final StructuredEvaluation? explicitStructuredEvalAfter;

  const EngineMoveResult({
    required this.plyIndex,
    required this.san,
    required this.bestMoveUci,
    required this.bestMoveSan,
    required this.evalBeforeCp,
    required this.evalAfterCp,
    required this.lossCp,
    required this.quality,
    required this.opponentBestReplyUci,
    this.evalAfterReplyCp,
    this.opponentPunishmentLineUci = const [],
    this.bestLineUci = const [],
    StructuredEvaluation? structuredEvalBefore,
    StructuredEvaluation? structuredEvalAfter,
  })  : explicitStructuredEvalBefore = structuredEvalBefore,
        explicitStructuredEvalAfter = structuredEvalAfter;

  StructuredEvaluation get structuredEvalBefore =>
      explicitStructuredEvalBefore ?? StructuredEvaluation.fromRawCp(evalBeforeCp);

  StructuredEvaluation get structuredEvalAfter =>
      explicitStructuredEvalAfter ?? StructuredEvaluation.fromRawCp(evalAfterCp);

  factory EngineMoveResult.fromJson(Map<String, dynamic> json) {
    final rawPlyIndex = json['plyIndex'];
    if (rawPlyIndex is! num ||
        !rawPlyIndex.isFinite ||
        rawPlyIndex < 0 ||
        rawPlyIndex != rawPlyIndex.toInt()) {
      throw const EngineApiException('Invalid or missing plyIndex in engine response.');
    }
    final plyIndex = rawPlyIndex.toInt();

    final san = json['san']?.toString().trim() ?? '';
    if (san.isEmpty) {
      throw const EngineApiException('Invalid or missing san in engine response.');
    }

    final evalBeforeCp = (json['evalBeforeCp'] as num?)?.toInt();
    final evalAfterCp = (json['evalAfterCp'] as num?)?.toInt();

    final sEvalBefore = StructuredEvaluation.fromJson(
      kindStr: json['evalBeforeKind']?.toString(),
      rawCp: evalBeforeCp,
      mateMoves: (json['evalBeforeValue'] as num?)?.toInt(),
      winnerColor: json['evalBeforeWinner']?.toString(),
    );

    final sEvalAfter = StructuredEvaluation.fromJson(
      kindStr: json['evalAfterKind']?.toString(),
      rawCp: evalAfterCp,
      mateMoves: (json['evalAfterValue'] as num?)?.toInt(),
      winnerColor: json['evalAfterWinner']?.toString(),
    );

    return EngineMoveResult(
      plyIndex: plyIndex,
      san: san,
      bestMoveUci: json['bestMoveUci']?.toString() ?? '',
      bestMoveSan: json['bestMoveSan']?.toString(),
      evalBeforeCp: evalBeforeCp,
      evalAfterCp: evalAfterCp,
      lossCp: (json['lossCp'] as num?)?.toInt() ?? 0,
      quality: _qualityFromJson(json['quality']),
      opponentBestReplyUci: json['opponentBestReplyUci']?.toString(),
      evalAfterReplyCp: (json['evalAfterReplyCp'] as num?)?.toInt(),
      opponentPunishmentLineUci: _stringList(json['opponentPunishmentLineUci']),
      bestLineUci: _stringList(json['bestLineUci']),
      structuredEvalBefore: sEvalBefore,
      structuredEvalAfter: sEvalAfter,
    );
  }
}

List<String> _stringList(Object? value) {
  if (value is! List) return const [];
  return List.unmodifiable(
    value.map((item) => item?.toString() ?? '').where((item) => item.isNotEmpty),
  );
}

class EngineGameResult {
  final List<EngineMoveResult> moves;

  const EngineGameResult({required this.moves});

  factory EngineGameResult.fromJson(Map<String, dynamic> json) {
    final rawMoves = json['moves'];
    if (rawMoves is! List) {
      throw const EngineApiException('Engine response did not contain a moves list.');
    }

    final parsedMoves = <EngineMoveResult>[];
    final seenPlyIndices = <int>{};

    for (final item in rawMoves) {
      if (item is! Map) {
        throw const EngineApiException('Engine response move item is not a JSON object.');
      }
      final moveRes = EngineMoveResult.fromJson(Map<String, dynamic>.from(item));
      if (!seenPlyIndices.add(moveRes.plyIndex)) {
        throw EngineApiException('Duplicate plyIndex ${moveRes.plyIndex} in engine response.');
      }
      parsedMoves.add(moveRes);
    }

    return EngineGameResult(moves: List.unmodifiable(parsedMoves));
  }

  int get blunders => moves
      .where((move) => move.quality == EngineMoveQuality.blunder)
      .length;
  int get mistakes => moves
      .where((move) => move.quality == EngineMoveQuality.mistake)
      .length;
  int get inaccuracies => moves
      .where((move) => move.quality == EngineMoveQuality.inaccuracy)
      .length;

  EngineMoveResult? get worstMove {
    if (moves.isEmpty) return null;

    final blundersList = moves
        .where((move) => move.quality == EngineMoveQuality.blunder)
        .toList();
    if (blundersList.isNotEmpty) {
      blundersList.sort((a, b) => b.lossCp.compareTo(a.lossCp));
      return blundersList.first;
    }

    final mistakesList = moves
        .where((move) => move.quality == EngineMoveQuality.mistake)
        .toList();
    if (mistakesList.isNotEmpty) {
      mistakesList.sort((a, b) => b.lossCp.compareTo(a.lossCp));
      return mistakesList.first;
    }

    final inaccuraciesList = moves
        .where((move) => move.quality == EngineMoveQuality.inaccuracy)
        .toList();
    if (inaccuraciesList.isNotEmpty) {
      inaccuraciesList.sort((a, b) => b.lossCp.compareTo(a.lossCp));
      return inaccuraciesList.first;
    }

    return null;
  }
}

class EngineApiException implements Exception {
  final String message;
  final int? statusCode;

  const EngineApiException(this.message, {this.statusCode});

  @override
  String toString() =>
      statusCode != null ? 'EngineApiException ($statusCode): $message' : 'EngineApiException: $message';
}

abstract class EngineTransport {
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body,
  );
}

class IoEngineTransport implements EngineTransport {
  final Uri baseUri;
  final HttpClient _client;
  final Duration defaultTimeout;

  IoEngineTransport({
    required String baseUrl,
    HttpClient? httpClient,
    Duration? timeout,
  })  : baseUri = Uri.parse(baseUrl),
        _client = httpClient ?? HttpClient(),
        defaultTimeout = timeout ?? const Duration(seconds: 180);

  Duration get timeout => defaultTimeout;

  @override
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body, {
    Duration? timeout,
  }) async {
    final effectiveTimeout = timeout ?? defaultTimeout;
    final uri = baseUri.resolve(path);
    final request = await _client.postUrl(uri).timeout(effectiveTimeout);
    request.headers.contentType = ContentType.json;
    request.write(jsonEncode(body));

    final response = await request.close().timeout(effectiveTimeout);
    final payload = await utf8.decoder.bind(response).join().timeout(effectiveTimeout);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw EngineApiException(
        payload.isEmpty ? 'Engine service returned ${response.statusCode}.' : payload,
        statusCode: response.statusCode,
      );
    }

    final decoded = jsonDecode(payload);
    if (decoded is! Map) {
      throw const EngineApiException('Engine service returned invalid JSON.');
    }
    return Map<String, dynamic>.from(decoded);
  }

  void close() => _client.close(force: true);
}

class EngineApiClient {
  final EngineTransport transport;

  const EngineApiClient({required this.transport});

  factory EngineApiClient.forBaseUrl(String baseUrl) {
    if (baseUrl.trim().isEmpty || (Platform.isAndroid && baseUrl.contains('10.0.2.2'))) {
      return EngineApiClient.local();
    }
    return EngineApiClient(
      transport: IoEngineTransport(baseUrl: baseUrl),
    );
  }

  factory EngineApiClient.local() {
    return EngineApiClient(
      transport: LocalStockfishTransport(),
    );
  }

  void dispose() {
    if (transport is LocalStockfishTransport) {
      (transport as LocalStockfishTransport).dispose();
    }
  }

  Future<EngineGameResult> analyzeGame(PersonalGameAnalysis analysis) async {
    if (!analysis.isValid) {
      throw const EngineApiException(
        'ChessSense cannot send a game with an invalid reconstructed move.',
      );
    }

    final response = await transport.postJson(
      '/v1/analyze-game',
      _requestForAnalysis(analysis),
    );
    final result = EngineGameResult.fromJson(response);

    final validPlyIndices = {for (final m in analysis.moves) m.plyIndex};
    for (final actual in result.moves) {
      if (!validPlyIndices.contains(actual.plyIndex)) {
        throw EngineApiException(
          'Engine response contains unexpected plyIndex ${actual.plyIndex}.',
        );
      }
    }

    return result;
  }



  Map<String, dynamic> _requestForAnalysis(PersonalGameAnalysis analysis) {
    final game = analysis.game;
    return {
      'schemaVersion': 1,
      'game': {
        'white': game.white,
        'black': game.black,
        'result': game.result,
        'event': game.event,
        'date': game.date,
      },
      'moves': analysis.moves
          .map(
            (move) => {
              'plyIndex': move.plyIndex,
              'moveNumber': move.moveNumber,
              'isWhiteMove': move.isWhiteMove,
              'san': move.san,
              'fenBefore': move.fenBefore,
              'fenAfter': move.fenAfter,
            },
          )
          .toList(growable: false),
    };
  }
}
