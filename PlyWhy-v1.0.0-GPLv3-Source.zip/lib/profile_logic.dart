import 'models.dart';

const Map<Skill, double> skillWeights = {
  Skill.threatAwareness: 0.25,
  Skill.opponentResponse: 0.25,
  Skill.moveSafety: 0.20,
  Skill.loosePieceDetection: 0.15,
  Skill.boardChangeAwareness: 0.15,
};

int calculateOverallScore(Map<Skill, int> scores) {
  double total = 0;
  for (final skill in Skill.values) {
    total += (scores[skill] ?? 0) * (skillWeights[skill] ?? 0);
  }
  return total.round();
}

int calculateChessSenseRating(Map<Skill, int> scores) {
  return 600 + calculateOverallScore(scores) * 14;
}

Skill calculateWeakestSkill(Map<Skill, int> scores) {
  return Skill.values.reduce(
    (a, b) => (scores[a] ?? 0) <= (scores[b] ?? 0) ? a : b,
  );
}

List<Skill> rankSkillsWeakestFirst(Map<Skill, int> scores) {
  return [...Skill.values]
    ..sort((a, b) {
      final scoreCompare = (scores[a] ?? 0).compareTo(scores[b] ?? 0);
      if (scoreCompare != 0) return scoreCompare;
      return a.index.compareTo(b.index);
    });
}

Map<Skill, int> updateSkillScores({
  required Map<Skill, int> previousScores,
  required TrainingResult result,
  double sessionWeight = 0.20,
}) {
  final updated = Map<Skill, int>.from(previousScores);
  final priorWeight = 1 - sessionWeight;

  for (final skill in Skill.values) {
    final totalForSkill = result.totalBySkill[skill] ?? 0;
    if (totalForSkill == 0) continue;

    final correctForSkill = result.correctBySkill[skill] ?? 0;
    final sessionScore = ((correctForSkill / totalForSkill) * 100).round();
    final oldScore = previousScores[skill] ?? 0;
    final newScore =
        ((oldScore * priorWeight) + (sessionScore * sessionWeight)).round();
    updated[skill] = newScore.clamp(0, 100).toInt();
  }

  return updated;
}

int calculateNextStreak({
  required int currentStreak,
  required String? lastTrainingDate,
  required String today,
}) {
  if (lastTrainingDate == null) return 1;
  if (lastTrainingDate == today) return currentStreak == 0 ? 1 : currentStreak;

  final lastDate = DateTime.tryParse(lastTrainingDate);
  final currentDate = DateTime.tryParse(today);
  if (lastDate == null || currentDate == null) return 1;

  final difference = currentDate.difference(lastDate).inDays;
  return difference == 1 ? currentStreak + 1 : 1;
}
