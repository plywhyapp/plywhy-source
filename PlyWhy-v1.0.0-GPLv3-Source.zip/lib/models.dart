import 'dart:convert';

enum Skill {
  threatAwareness,
  opponentResponse,
  loosePieceDetection,
  moveSafety,
  boardChangeAwareness,
}

String skillName(Skill skill) {
  switch (skill) {
    case Skill.threatAwareness:
      return 'Threat Awareness';
    case Skill.opponentResponse:
      return 'Opponent Response';
    case Skill.loosePieceDetection:
      return 'Loose Piece Detection';
    case Skill.moveSafety:
      return 'Move Safety';
    case Skill.boardChangeAwareness:
      return 'Board Change Awareness';
  }
}

enum ValidationStatus {
  unvalidated,
  manualReviewed,
  rulesValidated,
  engineValidated,
}

enum SessionKind {
  assessment,
  training,
  blunderShield,
  opponentVision,
  blunderSurvival,
}

String sessionKindName(SessionKind kind) {
  switch (kind) {
    case SessionKind.assessment:
      return 'Assessment';
    case SessionKind.training:
      return 'Daily Sense';
    case SessionKind.blunderShield:
      return 'BlunderShield';
    case SessionKind.opponentVision:
      return 'Opponent Vision';
    case SessionKind.blunderSurvival:
      return 'Blunder Survival';
  }
}

enum ConfidenceLevel {
  guessing,
  somewhatSure,
  verySure,
}

String confidenceName(ConfidenceLevel value) {
  switch (value) {
    case ConfidenceLevel.guessing:
      return 'Guessing';
    case ConfidenceLevel.somewhatSure:
      return 'Somewhat sure';
    case ConfidenceLevel.verySure:
      return 'Very sure';
  }
}

class Exercise {
  final String id;
  final Skill skill;
  final String subtitle;
  final String fen;
  final String question;
  final List<String> answers;
  final int correctIndex;
  final String explanation;
  final int difficulty;
  final ValidationStatus validationStatus;

  const Exercise({
    required this.id,
    required this.skill,
    required this.subtitle,
    required this.fen,
    required this.question,
    required this.answers,
    required this.correctIndex,
    required this.explanation,
    this.difficulty = 1,
    this.validationStatus = ValidationStatus.manualReviewed,
  });
}

class MoveChoice {
  final String uci;
  final String label;

  const MoveChoice({
    required this.uci,
    required this.label,
  });
}

class InteractiveMoveScenario {
  final String id;
  final Skill skill;
  final String title;
  final String subtitle;
  final String fen;
  final List<String> setupMovesUci;
  final String? setupMoveLabel;
  final List<MoveChoice> candidates;
  final String correctMoveUci;
  final String correctMoveLabel;
  final String explanation;
  final String dangerPattern;
  final ValidationStatus validationStatus;

  const InteractiveMoveScenario({
    required this.id,
    required this.skill,
    required this.title,
    required this.subtitle,
    required this.fen,
    this.setupMovesUci = const [],
    this.setupMoveLabel,
    this.candidates = const [],
    required this.correctMoveUci,
    required this.correctMoveLabel,
    required this.explanation,
    required this.dangerPattern,
    this.validationStatus = ValidationStatus.rulesValidated,
  });
}

class SurvivalScenario {
  final String id;
  final Skill skill;
  final String fen;
  final String proposedMoveUci;
  final String proposedMoveLabel;
  final bool isSafe;
  final String explanation;
  final String dangerPattern;

  const SurvivalScenario({
    required this.id,
    required this.skill,
    required this.fen,
    required this.proposedMoveUci,
    required this.proposedMoveLabel,
    required this.isSafe,
    required this.explanation,
    required this.dangerPattern,
  });
}

class AssessmentResult {
  final int correct;
  final int total;
  final Map<Skill, int> skillScores;

  const AssessmentResult({
    required this.correct,
    required this.total,
    required this.skillScores,
  });
}

class TrainingResult {
  final int correct;
  final int total;
  final Map<Skill, int> correctBySkill;
  final Map<Skill, int> totalBySkill;
  final List<String> exerciseIds;
  final SessionKind kind;
  final Map<Skill, int> mistakesBySkill;
  final int highConfidenceAttempts;
  final int highConfidenceMistakes;
  final int xpEarned;
  final int survivalScore;
  final Map<String, int> patternMistakes;

  const TrainingResult({
    required this.correct,
    required this.total,
    required this.correctBySkill,
    required this.totalBySkill,
    this.exerciseIds = const [],
    this.kind = SessionKind.training,
    this.mistakesBySkill = const {},
    this.highConfidenceAttempts = 0,
    this.highConfidenceMistakes = 0,
    this.xpEarned = 0,
    this.survivalScore = 0,
    this.patternMistakes = const {},
  });

  int get accuracy => total == 0 ? 0 : ((correct / total) * 100).round();
}

class SessionRecord {
  final String id;
  final SessionKind kind;
  final String timestampIso;
  final int correct;
  final int total;
  final int ratingBefore;
  final int ratingAfter;
  final Map<Skill, int> skillScoresAfter;

  const SessionRecord({
    required this.id,
    required this.kind,
    required this.timestampIso,
    required this.correct,
    required this.total,
    required this.ratingBefore,
    required this.ratingAfter,
    required this.skillScoresAfter,
  });

  int get accuracy => total == 0 ? 0 : ((correct / total) * 100).round();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'kind': kind.name,
      'timestampIso': timestampIso,
      'correct': correct,
      'total': total,
      'ratingBefore': ratingBefore,
      'ratingAfter': ratingAfter,
      'skillScoresAfter': {
        for (final entry in skillScoresAfter.entries) entry.key.name: entry.value,
      },
    };
  }

  String toJson() => jsonEncode(toMap());

  factory SessionRecord.fromMap(Map<String, dynamic> map) {
    final rawScores = Map<String, dynamic>.from(
      (map['skillScoresAfter'] as Map?) ?? const <String, dynamic>{},
    );

    return SessionRecord(
      id: map['id'] as String? ?? '',
      kind: SessionKind.values.firstWhere(
        (value) => value.name == map['kind'],
        orElse: () => SessionKind.training,
      ),
      timestampIso: map['timestampIso'] as String? ?? '',
      correct: (map['correct'] as num?)?.toInt() ?? 0,
      total: (map['total'] as num?)?.toInt() ?? 0,
      ratingBefore: (map['ratingBefore'] as num?)?.toInt() ?? 600,
      ratingAfter: (map['ratingAfter'] as num?)?.toInt() ?? 600,
      skillScoresAfter: {
        for (final skill in Skill.values)
          skill: (rawScores[skill.name] as num?)?.toInt() ?? 0,
      },
    );
  }

  factory SessionRecord.fromJson(String source) {
    return SessionRecord.fromMap(
      Map<String, dynamic>.from(jsonDecode(source) as Map),
    );
  }
}

class AppProgress {
  final bool assessmentCompleted;
  final Map<Skill, int> skillScores;
  final int sessionsCompleted;
  final int streak;
  final int? lastTrainingAccuracy;
  final String? lastTrainingDate;
  final List<SessionRecord> history;
  final List<String> recentExerciseIds;
  final int xp;
  final Map<Skill, int> mistakeCounts;
  final int highConfidenceAttempts;
  final int highConfidenceMistakes;
  final int survivalBest;
  final Map<String, int> blunderPatternCounts;

  const AppProgress({
    required this.assessmentCompleted,
    required this.skillScores,
    required this.sessionsCompleted,
    required this.streak,
    required this.lastTrainingAccuracy,
    required this.lastTrainingDate,
    required this.history,
    required this.recentExerciseIds,
    this.xp = 0,
    this.mistakeCounts = const {},
    this.highConfidenceAttempts = 0,
    this.highConfidenceMistakes = 0,
    this.survivalBest = 0,
    this.blunderPatternCounts = const {},
  });

  factory AppProgress.empty() {
    return AppProgress(
      assessmentCompleted: false,
      skillScores: {for (final skill in Skill.values) skill: 0},
      sessionsCompleted: 0,
      streak: 0,
      lastTrainingAccuracy: null,
      lastTrainingDate: null,
      history: const [],
      recentExerciseIds: const [],
      xp: 0,
      mistakeCounts: {for (final skill in Skill.values) skill: 0},
      highConfidenceAttempts: 0,
      highConfidenceMistakes: 0,
      survivalBest: 0,
      blunderPatternCounts: const {},
    );
  }

  AppProgress copyWith({
    bool? assessmentCompleted,
    Map<Skill, int>? skillScores,
    int? sessionsCompleted,
    int? streak,
    int? lastTrainingAccuracy,
    bool clearLastTrainingAccuracy = false,
    String? lastTrainingDate,
    bool clearLastTrainingDate = false,
    List<SessionRecord>? history,
    List<String>? recentExerciseIds,
    int? xp,
    Map<Skill, int>? mistakeCounts,
    int? highConfidenceAttempts,
    int? highConfidenceMistakes,
    int? survivalBest,
    Map<String, int>? blunderPatternCounts,
  }) {
    return AppProgress(
      assessmentCompleted: assessmentCompleted ?? this.assessmentCompleted,
      skillScores: skillScores ?? this.skillScores,
      sessionsCompleted: sessionsCompleted ?? this.sessionsCompleted,
      streak: streak ?? this.streak,
      lastTrainingAccuracy: clearLastTrainingAccuracy
          ? null
          : (lastTrainingAccuracy ?? this.lastTrainingAccuracy),
      lastTrainingDate:
          clearLastTrainingDate ? null : (lastTrainingDate ?? this.lastTrainingDate),
      history: history ?? this.history,
      recentExerciseIds: recentExerciseIds ?? this.recentExerciseIds,
      xp: xp ?? this.xp,
      mistakeCounts: mistakeCounts ?? this.mistakeCounts,
      highConfidenceAttempts:
          highConfidenceAttempts ?? this.highConfidenceAttempts,
      highConfidenceMistakes:
          highConfidenceMistakes ?? this.highConfidenceMistakes,
      survivalBest: survivalBest ?? this.survivalBest,
      blunderPatternCounts: blunderPatternCounts ?? this.blunderPatternCounts,
    );
  }
}
