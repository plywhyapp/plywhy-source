import 'package:flutter/material.dart';

import 'models.dart';
import 'profile_logic.dart';
import 'progress_store.dart';
import 'progression_logic.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const ChessSenseApp());
}

class ChessSenseApp extends StatefulWidget {
  const ChessSenseApp({super.key});

  @override
  State<ChessSenseApp> createState() => _ChessSenseAppState();
}

class _ChessSenseAppState extends State<ChessSenseApp> {
  final ProgressStore _store = ProgressStore();

  AppProgress _progress = AppProgress.empty();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final loaded = await _store.load();
    if (!mounted) return;
    setState(() {
      _progress = loaded;
      _loading = false;
    });
  }

  String _todayKey() {
    final now = DateTime.now();
    final month = now.month.toString().padLeft(2, '0');
    final day = now.day.toString().padLeft(2, '0');
    return '${now.year}-$month-$day';
  }

  String _recordId(SessionKind kind) {
    return '${kind.name}-${DateTime.now().microsecondsSinceEpoch}';
  }

  List<SessionRecord> _prependHistory(SessionRecord record) {
    return [record, ..._progress.history].take(60).toList();
  }

  Future<void> _saveAssessment(AssessmentResult result) async {
    final ratingBefore = calculateChessSenseRating(_progress.skillScores);
    final ratingAfter = calculateChessSenseRating(result.skillScores);

    final record = SessionRecord(
      id: _recordId(SessionKind.assessment),
      kind: SessionKind.assessment,
      timestampIso: DateTime.now().toIso8601String(),
      correct: result.correct,
      total: result.total,
      ratingBefore: ratingBefore,
      ratingAfter: ratingAfter,
      skillScoresAfter: Map<Skill, int>.from(result.skillScores),
    );

    final updated = _progress.copyWith(
      assessmentCompleted: true,
      skillScores: Map<Skill, int>.from(result.skillScores),
      history: _prependHistory(record),
    );

    setState(() => _progress = updated);
    await _store.save(updated);
  }

  Future<void> _saveTraining(TrainingResult result) async {
    final oldScores = _progress.skillScores;
    final ratingBefore = calculateChessSenseRating(oldScores);
    final sessionWeight = result.kind == SessionKind.training ? 0.20 : 0.12;
    final updatedScores = updateSkillScores(
      previousScores: oldScores,
      result: result,
      sessionWeight: sessionWeight,
    );
    final ratingAfter = calculateChessSenseRating(updatedScores);
    final today = _todayKey();

    final record = SessionRecord(
      id: _recordId(result.kind),
      kind: result.kind,
      timestampIso: DateTime.now().toIso8601String(),
      correct: result.correct,
      total: result.total,
      ratingBefore: ratingBefore,
      ratingAfter: ratingAfter,
      skillScoresAfter: Map<Skill, int>.from(updatedScores),
    );

    final recentIds = <String>[
      ...result.exerciseIds,
      ..._progress.recentExerciseIds,
    ];

    final dedupedRecent = <String>[];
    final seen = <String>{};
    for (final id in recentIds) {
      if (seen.add(id)) dedupedRecent.add(id);
      if (dedupedRecent.length >= 24) break;
    }

    final mistakes = <Skill, int>{
      for (final skill in Skill.values) skill: _progress.mistakeCounts[skill] ?? 0,
    };

    for (final skill in Skill.values) {
      final explicit = result.mistakesBySkill[skill];
      final derived = (result.totalBySkill[skill] ?? 0) -
          (result.correctBySkill[skill] ?? 0);
      final increment = explicit ?? (derived < 0 ? 0 : derived);
      mistakes[skill] = (mistakes[skill] ?? 0) + increment;
    }

    final patternCounts = Map<String, int>.from(_progress.blunderPatternCounts);
    for (final entry in result.patternMistakes.entries) {
      patternCounts[entry.key] = (patternCounts[entry.key] ?? 0) + entry.value;
    }

    final updated = _progress.copyWith(
      skillScores: updatedScores,
      sessionsCompleted: _progress.sessionsCompleted + 1,
      streak: calculateNextStreak(
        currentStreak: _progress.streak,
        lastTrainingDate: _progress.lastTrainingDate,
        today: today,
      ),
      lastTrainingAccuracy: result.accuracy,
      lastTrainingDate: today,
      history: _prependHistory(record),
      recentExerciseIds: dedupedRecent,
      xp: _progress.xp + defaultXpForResult(result),
      mistakeCounts: mistakes,
      highConfidenceAttempts:
          _progress.highConfidenceAttempts + result.highConfidenceAttempts,
      highConfidenceMistakes:
          _progress.highConfidenceMistakes + result.highConfidenceMistakes,
      survivalBest: result.survivalScore > _progress.survivalBest
          ? result.survivalScore
          : _progress.survivalBest,
      blunderPatternCounts: patternCounts,
    );

    setState(() => _progress = updated);
    await _store.save(updated);
  }

  Future<void> _resetProgress() async {
    await _store.clear();
    if (!mounted) return;
    setState(() => _progress = AppProgress.empty());
  }

  Future<void> _runQuickQaSession() async {
    if (!_progress.assessmentCompleted) {
      final seeded = AssessmentResult(
        correct: 14,
        total: 20,
        skillScores: {
          Skill.threatAwareness: 75,
          Skill.opponentResponse: 50,
          Skill.loosePieceDetection: 75,
          Skill.moveSafety: 75,
          Skill.boardChangeAwareness: 50,
        },
      );
      await _saveAssessment(seeded);
    }

    final result = TrainingResult(
      correct: 8,
      total: 10,
      correctBySkill: {
        Skill.threatAwareness: 2,
        Skill.opponentResponse: 2,
        Skill.loosePieceDetection: 1,
        Skill.moveSafety: 2,
        Skill.boardChangeAwareness: 1,
      },
      totalBySkill: {
        Skill.threatAwareness: 2,
        Skill.opponentResponse: 2,
        Skill.loosePieceDetection: 2,
        Skill.moveSafety: 2,
        Skill.boardChangeAwareness: 2,
      },
      exerciseIds: const [
        'TA05',
        'TA06',
        'OR05',
        'OR06',
        'LP05',
        'LP06',
        'MS05',
        'MS06',
        'BC05',
        'BC06',
      ],
    );

    await _saveTraining(result);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PlyWhy?',
      theme: _chessSenseTheme(),
      home: _loading
          ? const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            )
          : HomeScreen(
              progress: _progress,
              onAssessmentComplete: _saveAssessment,
              onTrainingComplete: _saveTraining,
              onResetProgress: _resetProgress,
              onRunQuickQa: _runQuickQaSession,
            ),
    );
  }
}


/// A consistent dark, high-contrast visual language for all ChessSense modes.
ThemeData _chessSenseTheme() {
  const background = Color(0xFF0B1519);
  const panel = Color(0xFF16272C);
  const mint = Color(0xFF8AD9C1);
  final colors = ColorScheme.fromSeed(
    seedColor: mint,
    brightness: Brightness.dark,
  ).copyWith(
    primary: mint,
    onPrimary: const Color(0xFF072920),
    secondary: const Color(0xFFEFC888),
    surface: background,
    onSurface: const Color(0xFFF3F6F3),
    onSurfaceVariant: const Color(0xFFB4C7C2),
    surfaceContainerLow: panel,
    surfaceContainer: const Color(0xFF192C31),
    surfaceContainerHigh: const Color(0xFF23383B),
    outline: const Color(0xFF496366),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: colors,
    scaffoldBackgroundColor: background,
    appBarTheme: const AppBarTheme(
      backgroundColor: background,
      foregroundColor: Color(0xFFF3F6F3),
      elevation: 0,
      centerTitle: true,
    ),
    cardTheme: CardThemeData(
      color: panel,
      margin: const EdgeInsets.symmetric(vertical: 4),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: const BorderSide(color: Color(0xFF2E4849), width: 1),
        borderRadius: BorderRadius.circular(18),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(0, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        textStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: mint,
      linearTrackColor: Color(0xFF293D40),
    ),
  );
}
