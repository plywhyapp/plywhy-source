import 'package:chess/chess.dart' as chess_lib;

import 'pgn_parser.dart';

enum PgnMistakeSeverity {
  dubious,
  mistake,
  blunder,
}

String pgnMistakeLabel(PgnMistakeSeverity severity) {
  switch (severity) {
    case PgnMistakeSeverity.dubious:
      return 'Dubious move';
    case PgnMistakeSeverity.mistake:
      return 'Mistake';
    case PgnMistakeSeverity.blunder:
      return 'Blunder';
  }
}

class PersonalGameMove {
  final int plyIndex;
  final int moveNumber;
  final bool isWhiteMove;
  final String san;
  final String? annotation;
  final String fenBefore;
  final String fenAfter;

  const PersonalGameMove({
    required this.plyIndex,
    required this.moveNumber,
    required this.isWhiteMove,
    required this.san,
    required this.annotation,
    required this.fenBefore,
    required this.fenAfter,
  });

  bool get isCapture => san.contains('x');
  bool get givesCheck => san.contains('+') || san.contains('#');
  bool get isCastle => san.startsWith('O-O') || san.startsWith('0-0');
  bool get isPromotion => san.contains('=');

  PgnMistakeSeverity? get mistakeSeverity {
    switch (annotation) {
      case '??':
        return PgnMistakeSeverity.blunder;
      case '?':
        return PgnMistakeSeverity.mistake;
      case '?!':
        return PgnMistakeSeverity.dubious;
      default:
        return null;
    }
  }

  String get moveLabel => isWhiteMove ? '$moveNumber. $san' : '$moveNumber... $san';
}

class PersonalGameAnalysis {
  final ParsedPgnGame game;
  final List<PersonalGameMove> moves;
  final int? invalidPlyIndex;
  final String? invalidSan;

  const PersonalGameAnalysis({
    required this.game,
    required this.moves,
    this.invalidPlyIndex,
    this.invalidSan,
  });

  bool get isValid => invalidPlyIndex == null;

  List<PersonalGameMove> get annotatedReviewMoves => moves
      .where((move) => move.mistakeSeverity != null)
      .toList(growable: false);
}

class PersonalGameAnalyzer {
  const PersonalGameAnalyzer();

  Future<PersonalGameAnalysis> analyzeAsync(
    ParsedPgnGame game, {
    int yieldEveryPlies = 12,
  }) async {
    final startFen = game.headers['FEN']?.trim();
    final chess = startFen != null && startFen.isNotEmpty
        ? chess_lib.Chess.fromFEN(startFen)
        : chess_lib.Chess();

    final moves = <PersonalGameMove>[];

    for (var ply = 0; ply < game.sanMoves.length; ply++) {
      if (ply > 0 && yieldEveryPlies > 0 && ply % yieldEveryPlies == 0) {
        // Yield to Flutter so large imports cannot starve Android's UI thread
        // long enough to trigger an "app isn't responding" dialog.
        await Future<void>.delayed(Duration.zero);
      }

      final san = game.sanMoves[ply];
      final fenBefore = chess.fen;
      final made = chess.move(san);

      if (!made) {
        return PersonalGameAnalysis(
          game: game,
          moves: List.unmodifiable(moves),
          invalidPlyIndex: ply,
          invalidSan: san,
        );
      }

      final fields = fenBefore.trim().split(RegExp(r'\s+'));
      final currentFullmove = fields.length >= 6 ? (int.tryParse(fields[5]) ?? ((ply ~/ 2) + 1)) : ((ply ~/ 2) + 1);
      final isWhiteTurn = fields.length >= 2 ? fields[1] == 'w' : ply.isEven;

      moves.add(
        PersonalGameMove(
          plyIndex: ply,
          moveNumber: currentFullmove,
          isWhiteMove: isWhiteTurn,
          san: san,
          annotation: game.annotations[ply],
          fenBefore: fenBefore,
          fenAfter: chess.fen,
        ),
      );
    }

    return PersonalGameAnalysis(
      game: game,
      moves: List.unmodifiable(moves),
    );
  }

  PersonalGameAnalysis analyze(ParsedPgnGame game) {
    final startFen = game.headers['FEN']?.trim();
    final chess = startFen != null && startFen.isNotEmpty
        ? chess_lib.Chess.fromFEN(startFen)
        : chess_lib.Chess();

    final moves = <PersonalGameMove>[];

    for (var ply = 0; ply < game.sanMoves.length; ply++) {
      final san = game.sanMoves[ply];
      final fenBefore = chess.fen;
      final made = chess.move(san);

      if (!made) {
        return PersonalGameAnalysis(
          game: game,
          moves: List.unmodifiable(moves),
          invalidPlyIndex: ply,
          invalidSan: san,
        );
      }

      final fields = fenBefore.trim().split(RegExp(r'\s+'));
      final currentFullmove = fields.length >= 6 ? (int.tryParse(fields[5]) ?? ((ply ~/ 2) + 1)) : ((ply ~/ 2) + 1);
      final isWhiteTurn = fields.length >= 2 ? fields[1] == 'w' : ply.isEven;

      moves.add(
        PersonalGameMove(
          plyIndex: ply,
          moveNumber: currentFullmove,
          isWhiteMove: isWhiteTurn,
          san: san,
          annotation: game.annotations[ply],
          fenBefore: fenBefore,
          fenAfter: chess.fen,
        ),
      );
    }

    return PersonalGameAnalysis(
      game: game,
      moves: List.unmodifiable(moves),
    );
  }
}
