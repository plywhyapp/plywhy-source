import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:chess/chess.dart' as chess_lib;
import 'package:flutter/foundation.dart';
import 'package:stockfish/stockfish.dart';

import 'chess_move_validator.dart';
import 'engine_api.dart';
import 'engine_config.dart';

enum EvalType { cp, mate, draw, unknown }

class EngineEvalScore {
  final EvalType type;
  final int? cp;
  final int? mateMoves;
  final bool isDraw;

  const EngineEvalScore.cp(this.cp)
      : type = EvalType.cp,
        mateMoves = null,
        isDraw = false;

  const EngineEvalScore.mate(this.mateMoves)
      : type = EvalType.mate,
        cp = null,
        isDraw = false;

  const EngineEvalScore.draw()
      : type = EvalType.draw,
        cp = 0,
        mateMoves = null,
        isDraw = true;

  const EngineEvalScore.unknown()
      : type = EvalType.unknown,
        cp = null,
        mateMoves = null,
        isDraw = false;

  int? toWhiteAbsoluteCp(bool isWhiteTurn) {
    switch (type) {
      case EvalType.cp:
        if (cp == null) return null;
        return isWhiteTurn ? cp : -cp!;
      case EvalType.mate:
      case EvalType.draw:
      case EvalType.unknown:
        return null;
    }
  }

  String get winnerColor {
    switch (type) {
      case EvalType.mate:
        if (mateMoves == null) return 'none';
        return mateMoves! > 0 ? 'active' : 'opponent';
      case EvalType.cp:
        if (cp == null || cp == 0) return 'none';
        return cp! > 0 ? 'active' : 'opponent';
      case EvalType.draw:
      case EvalType.unknown:
        return 'none';
    }
  }
}

String _winnerColorAbsolute(EngineEvalScore score, bool isWhiteTurn) {
  if (score.type == EvalType.draw || score.type == EvalType.unknown) return 'none';
  if (score.type == EvalType.mate) {
    if (score.mateMoves == null) return 'none';
    final activeWins = score.mateMoves! > 0;
    return (activeWins && isWhiteTurn) || (!activeWins && !isWhiteTurn) ? 'white' : 'black';
  }
  if (score.type == EvalType.cp) {
    if (score.cp == null || score.cp == 0) return 'none';
    final activeIsBetter = score.cp! > 0;
    return (activeIsBetter && isWhiteTurn) || (!activeIsBetter && !isWhiteTurn) ? 'white' : 'black';
  }
  return 'none';
}

class MoveClassification {
  final String quality;
  final int lossCp;

  const MoveClassification({required this.quality, required this.lossCp});
}

MoveClassification classifyMoveQuality({
  required String fenBefore,
  required String? uciPlayed,
  required String playedSan,
  required EngineEvalScore beforeEval,
  required EngineEvalScore afterEval,
  required String bestMoveUci,
}) {
  if (uciPlayed != null && uciPlayed.isNotEmpty && bestMoveUci.isNotEmpty) {
    final val = const ChessMoveValidator().validate(
      fenBefore: fenBefore,
      playedInput: playedSan.isNotEmpty ? playedSan : uciPlayed,
      targetInput: bestMoveUci,
    );
    if (val.isExactMatch) {
      return const MoveClassification(quality: 'best', lossCp: 0);
    }
  }

  if (beforeEval.type == EvalType.unknown || afterEval.type == EvalType.unknown) {
    return const MoveClassification(quality: 'unknown', lossCp: 0);
  }

  final bType = beforeEval.type;
  final aType = afterEval.type;

  if (bType == EvalType.mate || aType == EvalType.mate) {
    if (bType == EvalType.mate && aType == EvalType.mate) {
      final bM = beforeEval.mateMoves!;
      final aM = -afterEval.mateMoves!;

      if (bM > 0) {
        if (aM > 0) {
          if (aM <= bM) {
            return const MoveClassification(quality: 'best', lossCp: 0);
          } else {
            return const MoveClassification(quality: 'inaccuracy', lossCp: 0);
          }
        } else {
          return const MoveClassification(quality: 'blunder', lossCp: 0);
        }
      } else {
        if (aM < 0) {
          if (aM.abs() > bM.abs()) {
            return const MoveClassification(quality: 'good', lossCp: 0);
          } else {
            return const MoveClassification(quality: 'mistake', lossCp: 0);
          }
        } else if (aM > 0) {
          return const MoveClassification(quality: 'best', lossCp: 0);
        }
      }
    }

    if (bType == EvalType.cp && aType == EvalType.mate) {
      final aM = -afterEval.mateMoves!;
      if (aM > 0) {
        return const MoveClassification(quality: 'best', lossCp: 0);
      } else {
        return const MoveClassification(quality: 'blunder', lossCp: 0);
      }
    }

    if (bType == EvalType.mate && aType == EvalType.cp) {
      final bM = beforeEval.mateMoves!;
      if (bM > 0) {
        return const MoveClassification(quality: 'blunder', lossCp: 0);
      } else {
        return const MoveClassification(quality: 'best', lossCp: 0);
      }
    }

    if (bType == EvalType.mate && aType == EvalType.draw) {
      final bM = beforeEval.mateMoves!;
      if (bM > 0) {
        return const MoveClassification(quality: 'blunder', lossCp: 0);
      } else {
        return const MoveClassification(quality: 'best', lossCp: 0);
      }
    }

    if (bType == EvalType.draw && aType == EvalType.mate) {
      final aM = -afterEval.mateMoves!;
      if (aM < 0) {
        return const MoveClassification(quality: 'blunder', lossCp: 0);
      } else {
        return const MoveClassification(quality: 'best', lossCp: 0);
      }
    }
  }

  final isWhiteTurn = fenBefore.contains(' w ');
  final evalBeforeCp = beforeEval.toWhiteAbsoluteCp(isWhiteTurn);
  final evalAfterCp = afterEval.toWhiteAbsoluteCp(!isWhiteTurn);

  if (evalBeforeCp != null && evalAfterCp != null) {
    final playerLoss = isWhiteTurn
        ? (evalBeforeCp - evalAfterCp)
        : (evalAfterCp - evalBeforeCp);
    final lossCp = math.max(0, playerLoss);
    return MoveClassification(quality: _qualityForLoss(lossCp), lossCp: lossCp);
  }

  return const MoveClassification(quality: 'unknown', lossCp: 0);
}

String _qualityForLoss(int lossCp) {
  if (lossCp <= 15) return 'best';
  if (lossCp <= 45) return 'excellent';
  if (lossCp <= 90) return 'good';
  if (lossCp <= 180) return 'inaccuracy';
  if (lossCp <= 350) return 'mistake';
  return 'blunder';
}

String? _inferUciMove(String fenBefore, String fenAfter, String san) {
  try {
    final game = chess_lib.Chess.fromFEN(fenBefore);
    for (final move in game.moves({'verbose': true})) {
      final from = move['from']?.toString() ?? '';
      final to = move['to']?.toString() ?? '';
      final promotion = move['promotion']?.toString() ?? '';
      final uci = '$from$to$promotion';

      final clone = chess_lib.Chess.fromFEN(fenBefore);
      final moveMap = <String, String>{'from': from, 'to': to};
      if (promotion.isNotEmpty) moveMap['promotion'] = promotion;

      if (clone.move(moveMap) && clone.generate_fen() == fenAfter) {
        return uci;
      }
    }
  } catch (_) {}

  if (san.isNotEmpty) {
    try {
      final clone = chess_lib.Chess.fromFEN(fenBefore);
      if (clone.move(san) && clone.generate_fen() == fenAfter) {
        final history = clone.history.last;
        final from = history.move.fromAlgebraic;
        final to = history.move.toAlgebraic;
        final prom = history.move.promotion?.name.toLowerCase() ?? '';
        return '$from$to$prom';
      }
    } catch (_) {}
  }
  return null;
}

class _EnginePosition {
  final String bestMoveUci;
  final EngineEvalScore evalScore;
  final List<String> pvUci;
  final int? achievedDepth;

  const _EnginePosition({
    required this.bestMoveUci,
    required this.evalScore,
    required this.pvUci,
    this.achievedDepth,
  });
}

_EnginePosition? _terminalPositionAfterMoves(String fen, List<String> moves) {
  final board = chess_lib.Chess.fromFEN(fen);
  for (final uci in moves) {
    if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(uci)) {
      throw FormatException('Invalid UCI continuation: $uci');
    }
    final data = <String, String>{
      'from': uci.substring(0, 2),
      'to': uci.substring(2, 4),
    };
    if (uci.length == 5) data['promotion'] = uci[4];
    if (!board.move(data)) {
      throw FormatException('Illegal UCI continuation: $uci in $fen');
    }
  }

  if (board.in_checkmate) {
    return const _EnginePosition(
      bestMoveUci: '',
      evalScore: EngineEvalScore.mate(-1),
      pvUci: [],
    );
  }
  if (board.in_stalemate || board.in_draw) {
    return const _EnginePosition(
      bestMoveUci: '',
      evalScore: EngineEvalScore.draw(),
      pvUci: [],
    );
  }
  return null;
}

class _EnginePositionBuilder {
  String bestMoveUci = '';
  EngineEvalScore evalScore = const EngineEvalScore.unknown();
  List<String> pvUci = const [];
  int? achievedDepth;
  bool isComplete = false;

  void processLine(String line) {
    if (line.startsWith('info ')) {
      _parseInfoLine(line);
    } else if (line.startsWith('bestmove ')) {
      final parts = line.split(RegExp(r'\s+'));
      if (parts.length >= 2 && parts[1] != '(none)') {
        bestMoveUci = parts[1];
      }
      isComplete = true;
    }
  }

  void _parseInfoLine(String line) {
    final tokens = line.split(RegExp(r'\s+'));
    int? depth;
    EngineEvalScore? score;
    final pv = <String>[];

    for (int i = 0; i < tokens.length; i++) {
      final t = tokens[i];
      if (t == 'depth' && i + 1 < tokens.length) {
        depth = int.tryParse(tokens[i + 1]);
      } else if (t == 'score' && i + 2 < tokens.length) {
        final kind = tokens[i + 1];
        final val = int.tryParse(tokens[i + 2]);
        if (kind == 'cp' && val != null) {
          score = EngineEvalScore.cp(val);
        } else if (kind == 'mate' && val != null) {
          score = EngineEvalScore.mate(val);
        }
      } else if (t == 'pv') {
        for (int j = i + 1; j < tokens.length; j++) {
          final moveToken = tokens[j];
          if (RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(moveToken)) {
            pv.add(moveToken);
          } else {
            break;
          }
        }
        break;
      }
    }

    if (depth != null) achievedDepth = depth;
    if (score != null) evalScore = score;
    if (pv.isNotEmpty) pvUci = pv;
  }

  _EnginePosition build() {
    return _EnginePosition(
      bestMoveUci: bestMoveUci,
      evalScore: evalScore,
      pvUci: pvUci,
      achievedDepth: achievedDepth,
    );
  }
}

class LocalStockfishTransport implements EngineTransport {
  static LocalStockfishTransport? _instance;

  Stockfish? _engine;
  StreamSubscription<String>? _stdoutSub;
  Completer<void>? _uciOkCompleter;
  Completer<void>? _readyCompleter;
  EngineTransport? _fallbackIoTransport;
  final Duration? _initTimeoutOverride;
  final bool _forceNative;

  Completer<_EnginePosition>? _currentSearchCompleter;
  _EnginePositionBuilder? _currentPositionBuilder;

  LocalStockfishTransport._()
      : _initTimeoutOverride = null,
        _forceNative = false;

  @visibleForTesting
  LocalStockfishTransport.withEngine(
    Stockfish engine, {
    Duration? initTimeout,
    this._forceNative = false,
  })  : _engine = engine,
        _uciOkCompleter = Completer<void>(),
        _readyCompleter = Completer<void>(),
        _initTimeoutOverride = initTimeout;

  factory LocalStockfishTransport() {
    _instance ??= LocalStockfishTransport._();
    return _instance!;
  }

  Future<void> _ensureInitialized() async {
    if (_engine != null && _engine!.state.value != StockfishState.disposed && _engine!.state.value != StockfishState.error && _uciOkCompleter == null && _readyCompleter == null && _fallbackIoTransport == null) {
      return;
    }

    _engine ??= Stockfish();
    _uciOkCompleter ??= Completer<void>();
    _readyCompleter ??= Completer<void>();

    _stdoutSub?.cancel();
    _stdoutSub = _engine!.stdout.listen(_onStdoutLine);

    if (_engine!.state.value != StockfishState.ready) {
      final stateCompleter = Completer<void>();
      void listener() {
        if (_engine?.state.value == StockfishState.ready || _engine?.state.value == StockfishState.error) {
          _engine?.state.removeListener(listener);
          if (!stateCompleter.isCompleted) stateCompleter.complete();
        }
      }
      _engine!.state.addListener(listener);
      if (_engine!.state.value == StockfishState.ready || _engine!.state.value == StockfishState.error) {
        if (!stateCompleter.isCompleted) stateCompleter.complete();
      }
      await stateCompleter.future.timeout(const Duration(seconds: 10), onTimeout: () {
        if (!stateCompleter.isCompleted) stateCompleter.complete();
      });
    }

    if (_engine!.state.value == StockfishState.error || _engine!.state.value != StockfishState.ready) {
      if (Platform.isAndroid || _forceNative) {
        throw const EngineApiException('Native Stockfish engine failed to initialize on this Android device.');
      }
      final fallbackUrl = (EngineConfig.baseUrl.isNotEmpty && !EngineConfig.baseUrl.contains('10.0.2.2'))
          ? EngineConfig.baseUrl
          : 'http://127.0.0.1:8787';
      _fallbackIoTransport = IoEngineTransport(baseUrl: fallbackUrl);
      return;
    }

    final timeoutDuration = _initTimeoutOverride ?? const Duration(seconds: 30);

    try {
      if (!(_uciOkCompleter?.isCompleted ?? false)) {
        final uciFuture = _uciOkCompleter!.future;
        _engine!.stdin = 'uci';
        await uciFuture.timeout(
          timeoutDuration,
          onTimeout: () {
            throw const EngineApiException('Stockfish native engine initialization timed out waiting for uciok.');
          },
        );
      }

      if (!(_readyCompleter?.isCompleted ?? false)) {
        final readyFuture = _readyCompleter!.future;
        _engine!.stdin = 'isready';
        await readyFuture.timeout(
          timeoutDuration,
          onTimeout: () {
            throw const EngineApiException('Stockfish native engine initialization timed out waiting for readyok.');
          },
        );
      }
    } catch (e) {
      _engine = null;
      _uciOkCompleter = null;
      _readyCompleter = null;
      if (e is EngineApiException) rethrow;
      if (Platform.isAndroid || _forceNative) {
        throw EngineApiException('Failed to send UCI init to native Stockfish: $e');
      }
      _fallbackIoTransport = IoEngineTransport(baseUrl: 'http://127.0.0.1:8787');
      return;
    }
  }

  void _onStdoutLine(String line) {
    final trimmed = line.trim();
    if (trimmed.endsWith('uciok')) {
      if (_uciOkCompleter != null && !_uciOkCompleter!.isCompleted) {
        _uciOkCompleter!.complete();
        _uciOkCompleter = null;
      }
    }
    if (trimmed.endsWith('readyok')) {
      if (_readyCompleter != null && !_readyCompleter!.isCompleted) {
        _readyCompleter!.complete();
        _readyCompleter = null;
      }
    }

    if (_currentPositionBuilder != null) {
      _currentPositionBuilder!.processLine(trimmed);
      if (_currentPositionBuilder!.isComplete) {
        final pos = _currentPositionBuilder!.build();
        final completer = _currentSearchCompleter;
        _currentSearchCompleter = null;
        _currentPositionBuilder = null;
        if (completer != null && !completer.isCompleted) {
          completer.complete(pos);
        }
      }
    }
  }

  @override
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body, {
    Duration? timeout,
  }) async {
    await _ensureInitialized();

    if (_fallbackIoTransport != null) {
      return _fallbackIoTransport!.postJson(path, body);
    }

    if (body['schemaVersion'] != 1) {
      throw const EngineApiException('Unsupported schemaVersion.');
    }

    final rawMoves = body['moves'];
    if (rawMoves is! List || rawMoves.isEmpty) {
      throw const EngineApiException('Request must contain a non-empty moves list.');
    }

    final moves = rawMoves
        .whereType<Map>()
        .map((m) => Map<String, dynamic>.from(m))
        .toList(growable: false);

    final cache = <String, _EnginePosition>{};

    Future<_EnginePosition> evaluate(String fen) async {
      final existing = cache[fen];
      if (existing != null) return existing;
      final result = await _searchStockfish(fen, const []);
      cache[fen] = result;
      return result;
    }

    final responseMoves = <Map<String, dynamic>>[];
    for (final move in moves) {
      final fenBefore = move['fenBefore']?.toString() ?? '';
      final fenAfter = move['fenAfter']?.toString() ?? '';
      final playedSan = move['san']?.toString() ?? '';

      if (fenBefore.isEmpty || fenAfter.isEmpty) {
        throw const EngineApiException('Every move requires fenBefore and fenAfter.');
      }

      final isWhiteBefore = fenBefore.contains(' w ');
      final before = await evaluate(fenBefore);
      final after = await evaluate(fenAfter);

      final uciPlayed = _inferUciMove(fenBefore, fenAfter, playedSan);

      final classification = classifyMoveQuality(
        fenBefore: fenBefore,
        uciPlayed: uciPlayed,
        playedSan: playedSan,
        beforeEval: before.evalScore,
        afterEval: after.evalScore,
        bestMoveUci: before.bestMoveUci,
      );

      int? evalAfterReplyCp;
      if (classification.quality == 'blunder' || classification.quality == 'mistake' || classification.lossCp > 90) {
        if (after.bestMoveUci.isNotEmpty) {
          final afterReply = await _searchStockfish(
            fenAfter,
            [after.bestMoveUci],
          );
          evalAfterReplyCp = afterReply.evalScore.toWhiteAbsoluteCp(isWhiteBefore);
        }
      }

      responseMoves.add({
        'plyIndex': (move['plyIndex'] as num?)?.toInt() ?? responseMoves.length,
        'san': playedSan,
        'bestMoveUci': before.bestMoveUci,
        'bestMoveSan': null,
        'achievedDepthBefore': before.achievedDepth,
        'achievedDepthAfter': after.achievedDepth,
        'evalBeforeKind': before.evalScore.type.name,
        'evalBeforeValue': before.evalScore.type == EvalType.mate
            ? before.evalScore.mateMoves
            : before.evalScore.cp,
        'evalBeforeWinner': _winnerColorAbsolute(before.evalScore, isWhiteBefore),
        'evalBeforeCp': before.evalScore.toWhiteAbsoluteCp(isWhiteBefore),
        'evalAfterKind': after.evalScore.type.name,
        'evalAfterValue': after.evalScore.type == EvalType.mate
            ? after.evalScore.mateMoves
            : after.evalScore.cp,
        'evalAfterWinner': _winnerColorAbsolute(after.evalScore, !isWhiteBefore),
        'evalAfterCp': after.evalScore.toWhiteAbsoluteCp(!isWhiteBefore),
        'lossCp': classification.lossCp,
        'quality': classification.quality,
        'opponentBestReplyUci': after.bestMoveUci.isEmpty
            ? null
            : after.bestMoveUci,
        'evalAfterReplyCp': evalAfterReplyCp,
        'opponentPunishmentLineUci': after.pvUci.take(4).toList(growable: false),
        'bestLineUci': before.pvUci.take(4).toList(growable: false),
      });
    }

    return {
      'moves': responseMoves,
      'engine': {
        'name': 'Stockfish-Local-Native',
        'moveTimeMs': 350,
        'positionsEvaluated': cache.length,
      },
    };
  }

  Completer<void>? _searchLock;

  Future<_EnginePosition> _searchStockfish(String fen, List<String> continuationMoves) async {
    final terminal = _terminalPositionAfterMoves(fen, continuationMoves);
    if (terminal != null) return terminal;

    while (_searchLock != null) {
      await _searchLock!.future;
    }

    final lock = Completer<void>();
    _searchLock = lock;

    try {
      _readyCompleter = Completer<void>();
      final readyFuture = _readyCompleter!.future;
      _engine!.stdin = 'isready';
      await readyFuture.timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          throw const EngineApiException('Stockfish isready timed out waiting for readyok.');
        },
      );

      _currentSearchCompleter = Completer<_EnginePosition>();
      _currentPositionBuilder = _EnginePositionBuilder();
      final searchFuture = _currentSearchCompleter!.future;

      var posCmd = 'position fen $fen';
      if (continuationMoves.isNotEmpty) {
        posCmd += ' moves ${continuationMoves.join(" ")}';
      }
      _engine!.stdin = posCmd;
      _engine!.stdin = 'go depth 10';

      return await searchFuture.timeout(
        const Duration(seconds: 15),
        onTimeout: () {
          try {
            _engine?.stdin = 'stop';
          } catch (_) {}
          _currentSearchCompleter = null;
          _currentPositionBuilder = null;
          throw const EngineApiException('Stockfish search timed out.');
        },
      );
    } finally {
      _currentSearchCompleter = null;
      _currentPositionBuilder = null;
      _searchLock = null;
      if (!lock.isCompleted) lock.complete();
    }
  }

  void dispose() {
    if (_engine != null && _engine!.state.value != StockfishState.disposed) {
      try {
        _engine!.stdin = 'quit';
        _engine!.dispose();
      } catch (_) {}
    }
    _stdoutSub?.cancel();
    _stdoutSub = null;
    _engine = null;
    _instance = null;
  }
}
