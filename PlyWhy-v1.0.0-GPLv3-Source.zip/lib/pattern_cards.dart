import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'chess_move_validator.dart';
import 'engine_api.dart';
import 'engine_explanation.dart';
import 'personal_game_analysis.dart';

enum PatternGrade { again, hard, good }

class PatternCard {
  final int schemaVersion;
  final String id;
  final String sourceGame;
  final String moveLabel;
  final String fenBefore;
  final String wrongMove;
  final String correctMoveUci;
  final String? opponentReplyUci;
  final String lessonTitle;
  final String whatFailed;
  final String punishment;
  final String whyItWorks;
  final String consequence;
  final String betterChoice;
  final String lessonText;
  final String reflectionQuestion;
  final bool flipped;
  final int repetitions;
  final int intervalDays;
  final int dueAtMs;
  final bool isArchived;
  final String? archiveReason;
  final String? archivedAtIso;
  final int transferAttempts;
  final int transferSuccesses;

  const PatternCard({
    this.schemaVersion = 2,
    required this.id,
    required this.sourceGame,
    required this.moveLabel,
    required this.fenBefore,
    required this.wrongMove,
    required this.correctMoveUci,
    required this.opponentReplyUci,
    required this.lessonTitle,
    required this.whatFailed,
    required this.punishment,
    required this.whyItWorks,
    required this.consequence,
    required this.betterChoice,
    required this.lessonText,
    this.reflectionQuestion =
        'Before committing this move, did you check which key squares or pieces were left undefended?',
    required this.flipped,
    this.repetitions = 0,
    this.intervalDays = 0,
    this.dueAtMs = 0,
    this.isArchived = false,
    this.archiveReason,
    this.archivedAtIso,
    this.transferAttempts = 0,
    this.transferSuccesses = 0,
  });

  bool isDueAt(DateTime at) => !isArchived && dueAtMs <= at.millisecondsSinceEpoch;

  PatternCard graded(PatternGrade grade, DateTime now) {
    final nextDays = switch (grade) {
      PatternGrade.again => 0,
      PatternGrade.hard => 1,
      PatternGrade.good => intervalDays < 3 ? 3 : (intervalDays * 2).clamp(3, 90).toInt(),
    };
    final nextDue = grade == PatternGrade.again
        ? now.add(const Duration(minutes: 10))
        : now.add(Duration(days: nextDays));
    return copySchedule(
      repetitions: grade == PatternGrade.again ? 0 : repetitions + 1,
      intervalDays: nextDays,
      dueAtMs: nextDue.millisecondsSinceEpoch,
    );
  }

  PatternCard withTransferResults(int successes, int attempts) {
    return PatternCard(
      schemaVersion: schemaVersion,
      id: id,
      sourceGame: sourceGame,
      moveLabel: moveLabel,
      fenBefore: fenBefore,
      wrongMove: wrongMove,
      correctMoveUci: correctMoveUci,
      opponentReplyUci: opponentReplyUci,
      lessonTitle: lessonTitle,
      whatFailed: whatFailed,
      punishment: punishment,
      whyItWorks: whyItWorks,
      consequence: consequence,
      betterChoice: betterChoice,
      lessonText: lessonText,
      reflectionQuestion: reflectionQuestion,
      flipped: flipped,
      repetitions: repetitions,
      intervalDays: intervalDays,
      dueAtMs: dueAtMs,
      isArchived: isArchived,
      archiveReason: archiveReason,
      archivedAtIso: archivedAtIso,
      transferAttempts: transferAttempts + attempts,
      transferSuccesses: transferSuccesses + successes,
    );
  }

  PatternCard copySchedule({
    required int repetitions,
    required int intervalDays,
    required int dueAtMs,
    bool? isArchived,
    String? archiveReason,
    String? archivedAtIso,
  }) => PatternCard(
    schemaVersion: 2, // Explicitly upgrade to v2 schema
    id: id,
    sourceGame: sourceGame,
    moveLabel: moveLabel,
    fenBefore: fenBefore,
    wrongMove: wrongMove,
    correctMoveUci: correctMoveUci,
    opponentReplyUci: opponentReplyUci,
    lessonTitle: lessonTitle,
    whatFailed: whatFailed,
    punishment: punishment,
    whyItWorks: whyItWorks,
    consequence: consequence,
    betterChoice: betterChoice,
    lessonText: lessonText,
    reflectionQuestion: reflectionQuestion,
    flipped: flipped,
    repetitions: repetitions,
    intervalDays: intervalDays,
    dueAtMs: dueAtMs,
    isArchived: isArchived ?? this.isArchived,
    archiveReason: archiveReason ?? this.archiveReason,
    archivedAtIso: archivedAtIso ?? this.archivedAtIso,
    transferAttempts: transferAttempts,
    transferSuccesses: transferSuccesses,
  );

  PatternCard archived({required String reason, DateTime? at}) {
    final nowIso = (at ?? DateTime.now().toUtc()).toIso8601String();
    return PatternCard(
      schemaVersion: 2,
      id: id,
      sourceGame: sourceGame,
      moveLabel: moveLabel,
      fenBefore: fenBefore,
      wrongMove: wrongMove,
      correctMoveUci: correctMoveUci,
      opponentReplyUci: opponentReplyUci,
      lessonTitle: lessonTitle,
      whatFailed: whatFailed,
      punishment: punishment,
      whyItWorks: whyItWorks,
      consequence: consequence,
      betterChoice: betterChoice,
      lessonText: lessonText,
      reflectionQuestion: reflectionQuestion,
      flipped: flipped,
      repetitions: repetitions,
      intervalDays: intervalDays,
      dueAtMs: dueAtMs,
      isArchived: true,
      archiveReason: reason,
      archivedAtIso: nowIso,
      transferAttempts: transferAttempts,
      transferSuccesses: transferSuccesses,
    );
  }

  PatternCard unarchived() {
    return PatternCard(
      schemaVersion: 2,
      id: id,
      sourceGame: sourceGame,
      moveLabel: moveLabel,
      fenBefore: fenBefore,
      wrongMove: wrongMove,
      correctMoveUci: correctMoveUci,
      opponentReplyUci: opponentReplyUci,
      lessonTitle: lessonTitle,
      whatFailed: whatFailed,
      punishment: punishment,
      whyItWorks: whyItWorks,
      consequence: consequence,
      betterChoice: betterChoice,
      lessonText: lessonText,
      reflectionQuestion: reflectionQuestion,
      flipped: flipped,
      repetitions: repetitions,
      intervalDays: intervalDays,
      dueAtMs: dueAtMs,
      isArchived: false,
      archiveReason: null,
      archivedAtIso: null,
      transferAttempts: transferAttempts,
      transferSuccesses: transferSuccesses,
    );
  }

  Map<String, dynamic> toJson() => {
    'schemaVersion': schemaVersion,
    'id': id,
    'sourceGame': sourceGame,
    'moveLabel': moveLabel,
    'fenBefore': fenBefore,
    'wrongMove': wrongMove,
    'correctMoveUci': correctMoveUci,
    'opponentReplyUci': opponentReplyUci,
    'lessonTitle': lessonTitle,
    'whatFailed': whatFailed,
    'punishment': punishment,
    'whyItWorks': whyItWorks,
    'consequence': consequence,
    'betterChoice': betterChoice,
    'lessonText': lessonText,
    'reflectionQuestion': reflectionQuestion,
    'flipped': flipped,
    'repetitions': repetitions,
    'intervalDays': intervalDays,
    'dueAtMs': dueAtMs,
    'isArchived': isArchived,
    'archiveReason': archiveReason,
    'archivedAtIso': archivedAtIso,
    'transferAttempts': transferAttempts,
    'transferSuccesses': transferSuccesses,
  };

  factory PatternCard.fromJson(Map<String, dynamic> json) => PatternCard(
    schemaVersion: (json['schemaVersion'] as num?)?.toInt() ?? 1,
    id: json['id'] as String,
    sourceGame: json['sourceGame'] as String,
    moveLabel: json['moveLabel'] as String,
    fenBefore: json['fenBefore'] as String,
    wrongMove: json['wrongMove'] as String,
    correctMoveUci: json['correctMoveUci'] as String,
    opponentReplyUci: json['opponentReplyUci'] as String?,
    lessonTitle: json['lessonTitle'] as String,
    whatFailed: json['whatFailed'] as String,
    punishment: json['punishment'] as String,
    whyItWorks: json['whyItWorks'] as String,
    consequence: json['consequence'] as String,
    betterChoice: json['betterChoice'] as String,
    lessonText: json['lessonText'] as String,
    reflectionQuestion: json['reflectionQuestion']?.toString() ??
        'Before committing this move, did you check which key squares or pieces were left undefended?',
    flipped: json['flipped'] as bool? ?? false,
    repetitions: (json['repetitions'] as num?)?.toInt() ?? 0,
    intervalDays: (json['intervalDays'] as num?)?.toInt() ?? 0,
    dueAtMs: (json['dueAtMs'] as num?)?.toInt() ?? 0,
    isArchived: json['isArchived'] as bool? ?? false,
    archiveReason: json['archiveReason'] as String?,
    archivedAtIso: json['archivedAtIso'] as String?,
    transferAttempts: (json['transferAttempts'] as num?)?.toInt() ?? 0,
    transferSuccesses: (json['transferSuccesses'] as num?)?.toInt() ?? 0,
  );
}

class PatternCardBuilder {
  const PatternCardBuilder();

  List<PatternCard> fromGame({
    required PersonalGameAnalysis analysis,
    required EngineGameResult result,
    bool? playerIsWhite,
  }) {
    final contexts = {
      for (final move in analysis.moves) move.plyIndex: move,
    };
    final cards = <PatternCard>[];
    const validator = ChessMoveValidator();

    for (final move in result.moves) {
      final context = contexts[move.plyIndex];
      if (playerIsWhite != null) {
        final moveIsWhite = context != null ? context.isWhiteMove : move.plyIndex.isEven;
        if (moveIsWhite != playerIsWhite) continue;
      }
      final isQualityMistake = move.quality == EngineMoveQuality.inaccuracy ||
          move.quality == EngineMoveQuality.mistake ||
          move.quality == EngineMoveQuality.blunder;

      final isUnknown = move.structuredEvalBefore.kind == EvalKind.unknown ||
          move.structuredEvalAfter.kind == EvalKind.unknown;

      if (!isQualityMistake || isUnknown) continue;

      // Distinguish centipawn loss vs mate evaluation loss:
      final isMateLoss = move.structuredEvalBefore.kind == EvalKind.mate ||
          move.structuredEvalAfter.kind == EvalKind.mate;

      final isMistake = isMateLoss || move.lossCp > 15;

      if (!isMistake) continue;

      if (context == null) continue;

      // Do NOT create correction cards if the move is actually exact match via validator
      final valResult = validator.validate(
        fenBefore: context.fenBefore,
        playedInput: context.san,
        targetInput: move.bestMoveUci,
      );
      if (!valResult.isDifferentMoves) continue;

      final explanation = buildEngineMoveExplanation(move, context);
      
      if (explanation.whatFailed.contains('top recommended move') ||
          explanation.betterChoice.contains('Stockfish confirmed')) {
        continue;
      }

      final game = analysis.game;
      final identity = '${game.white}|${game.black}|${game.date}|'
          '${context.plyIndex}|${context.fenBefore}';
      final stableId = base64Url.encode(utf8.encode(identity));
      cards.add(PatternCard(
        schemaVersion: 2,
        id: stableId,
        sourceGame: '${game.white} vs ${game.black} · ${game.date}',
        moveLabel: context.moveLabel,
        fenBefore: context.fenBefore,
        wrongMove: context.san,
        correctMoveUci: move.bestMoveUci,
        opponentReplyUci: move.opponentBestReplyUci,
        lessonTitle: explanation.lessonTitle,
        whatFailed: explanation.whatFailed,
        punishment: explanation.opponentPunishment,
        whyItWorks: explanation.whyItWorks,
        consequence: explanation.consequence,
        betterChoice: explanation.betterChoice,
        lessonText: explanation.lessonText,
        reflectionQuestion: explanation.reflectionQuestion,
        flipped: !context.isWhiteMove,
      ));
    }
    return List.unmodifiable(cards);
  }
}

class PatternCardStore {
  static const key = 'chesssense_pattern_cards_v1';
  static const tmpKey = 'chesssense_pattern_cards_v1_tmp';
  static const backupKeyPrefix = 'chesssense_pattern_cards_backup_';

  /// Loads all stored cards (v1 -> v2 migrated, with non-destructive soft-archiving and backup recovery).
  Future<List<PatternCard>> loadAll({bool includeArchived = true}) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);

    List<PatternCard> loaded;
    if (raw == null || raw.isEmpty) {
      // Check if backup keys exist before assuming empty store
      final backupKeys = prefs.getKeys().where((k) => k.startsWith(backupKeyPrefix)).toList();
      if (backupKeys.isNotEmpty) {
        final recovered = await _recoverFromLatestBackup(prefs);
        if (recovered != null) {
          loaded = recovered;
        } else {
          // EXPLICIT PREVENTATIVE FIX: Main key is empty/null, but backup keys exist and all were corrupted!
          throw StateError(
            'Stored Pattern Cards payload in "$key" is empty/null, but backup keys exist and all were corrupted or unparseable.',
          );
        }
      } else {
        return const []; // Genuinely empty store (no main key AND no backup keys)
      }
    } else {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is! List) throw FormatException('Stored Pattern Cards data is not a JSON list.');
        loaded = decoded.map((item) =>
            PatternCard.fromJson(Map<String, dynamic>.from(item as Map))).toList();
      } catch (primaryError) {
        // Main storage payload corrupted or unparseable! Attempt recovery from latest valid backup.
        final recovered = await _recoverFromLatestBackup(prefs);
        if (recovered != null) {
          loaded = recovered;
        } else {
          throw StateError(
            'Corrupted Pattern Cards storage payload in "$key" and no valid backup payload could be recovered: $primaryError',
          );
        }
      }
    }

    const validator = ChessMoveValidator();
    var needsMigration = false;
    final migratedList = <PatternCard>[];

    for (final card in loaded) {
      var cardToUse = card;

      // Reliable evidence check using ChessMoveValidator:
      // Soft-archive any card where wrongMove is exact match with correctMoveUci
      if (!cardToUse.isArchived) {
        final val = validator.validate(
          fenBefore: cardToUse.fenBefore,
          playedInput: cardToUse.wrongMove,
          targetInput: cardToUse.correctMoveUci,
        );
        if (val.isExactMatch) {
          cardToUse = cardToUse.archived(
            reason: 'reclassified_as_best_v2',
          );
          needsMigration = true;
        }
      }

      // Upgrade schemaVersion explicitly to 2
      if (cardToUse.schemaVersion < 2) {
        cardToUse = PatternCard(
          schemaVersion: 2, // EXPLICITLY 2
          id: cardToUse.id,
          sourceGame: cardToUse.sourceGame,
          moveLabel: cardToUse.moveLabel,
          fenBefore: cardToUse.fenBefore,
          wrongMove: cardToUse.wrongMove,
          correctMoveUci: cardToUse.correctMoveUci,
          opponentReplyUci: cardToUse.opponentReplyUci,
          lessonTitle: cardToUse.lessonTitle,
          whatFailed: cardToUse.whatFailed,
          punishment: cardToUse.punishment,
          whyItWorks: cardToUse.whyItWorks,
          consequence: cardToUse.consequence,
          betterChoice: cardToUse.betterChoice,
          lessonText: cardToUse.lessonText,
          reflectionQuestion: cardToUse.reflectionQuestion,
          flipped: cardToUse.flipped,
          repetitions: cardToUse.repetitions,
          intervalDays: cardToUse.intervalDays,
          dueAtMs: cardToUse.dueAtMs,
          isArchived: cardToUse.isArchived,
          archiveReason: cardToUse.archiveReason,
          archivedAtIso: cardToUse.archivedAtIso,
        );
        needsMigration = true;
      }

      migratedList.add(cardToUse);
    }

    if (needsMigration) {
      await _write(migratedList);
    }

    if (includeArchived) {
      return List.unmodifiable(migratedList);
    }
    return List.unmodifiable(
      migratedList.where((card) => !card.isArchived),
    );
  }

  /// Attempts to recover stored cards from the newest valid timestamped backup.
  Future<List<PatternCard>?> _recoverFromLatestBackup(SharedPreferences prefs) async {
    final keys = prefs.getKeys().where((k) => k.startsWith(backupKeyPrefix)).toList();
    if (keys.isEmpty) return null;

    // Sort backup keys by timestamp descending
    keys.sort((a, b) => b.compareTo(a));

    for (final backupKey in keys) {
      final payload = prefs.getString(backupKey);
      if (payload == null || payload.isEmpty) continue;
      try {
        final decoded = jsonDecode(payload);
        if (decoded is List) {
          final recovered = decoded
              .map((item) => PatternCard.fromJson(Map<String, dynamic>.from(item as Map)))
              .toList();
          // Restore main key with valid backup payload
          await prefs.setString(key, payload);
          return recovered;
        }
      } catch (_) {
        // Try next older backup key
      }
    }
    return null;
  }

  /// Loads active (non-archived) cards for active training queues.
  Future<List<PatternCard>> loadActive() async {
    return loadAll(includeArchived: false);
  }

  /// Loads active (non-archived) cards for active training queues.
  Future<List<PatternCard>> load() async {
    return loadAll(includeArchived: false);
  }

  /// Restores/unarchives a soft-archived card by ID, preserving all study history.
  /// Refuses to re-activate cards where wrongMove is Stockfish's top recommended move.
  Future<void> restoreArchivedCard(String cardId) async {
    final all = await loadAll(includeArchived: true);
    final targetCard = all.firstWhere(
      (card) => card.id == cardId,
      orElse: () => throw StateError('Pattern Card with ID "$cardId" not found in store.'),
    );

    // Guard: Do NOT allow re-activating cards that teach a best move as an error
    const validator = ChessMoveValidator();
    final valResult = validator.validate(
      fenBefore: targetCard.fenBefore,
      playedInput: targetCard.wrongMove,
      targetInput: targetCard.correctMoveUci,
    );
    if (valResult.isExactMatch) {
      throw StateError(
        'Cannot restore Pattern Card "$cardId": "${targetCard.wrongMove}" is confirmed as Stockfish\'s top recommended move in this position.',
      );
    }

    final updated = [
      for (final card in all)
        card.id == cardId ? card.unarchived() : card,
    ];
    await _write(updated);
  }

  /// Updating cards preserves review schedules AND archive state of cards already studied.
  Future<List<PatternCard>> upsertAll(List<PatternCard> incoming) async {
    final existing = await loadAll(includeArchived: true);
    final byId = <String, PatternCard>{for (final card in existing) card.id: card};
    for (final card in incoming) {
      final previous = byId[card.id];
      byId[card.id] = previous == null
          ? card
          : card.copySchedule(
              repetitions: previous.repetitions,
              intervalDays: previous.intervalDays,
              dueAtMs: previous.dueAtMs,
              isArchived: previous.isArchived,
              archiveReason: previous.archiveReason,
              archivedAtIso: previous.archivedAtIso,
            );
    }
    final updated = List<PatternCard>.unmodifiable(byId.values);
    await _write(updated);
    return load();
  }

  Future<void> saveGrade(PatternCard graded) async {
    final existing = await loadAll(includeArchived: true);
    final updated = [
      for (final card in existing) card.id == graded.id ? graded : card,
    ];
    await _write(updated);
  }

  /// Atomic write protection: writes to temporary key first, verifies payload, then overwrites main key.
  Future<void> _write(List<PatternCard> cards) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonPayload = jsonEncode([for (final card in cards) card.toJson()]);

    // 1. Create timestamped backup of current data
    final currentRaw = prefs.getString(key);
    if (currentRaw != null && currentRaw.isNotEmpty) {
      final backupKey = '$backupKeyPrefix${DateTime.now().millisecondsSinceEpoch}';
      await prefs.setString(backupKey, currentRaw);
    }

    // 2. Write to temporary key
    final savedTmp = await prefs.setString(tmpKey, jsonPayload);
    if (!savedTmp) throw StateError('Unable to write temporary Pattern Cards payload.');

    // 3. Verify temporary payload integrity
    final verifiedTmp = prefs.getString(tmpKey);
    if (verifiedTmp == null || verifiedTmp != jsonPayload) {
      throw StateError('Temporary Pattern Cards payload verification failed.');
    }

    // 4. Overwrite main key
    final savedMain = await prefs.setString(key, jsonPayload);
    if (!savedMain) throw StateError('Unable to save Pattern Cards on this device.');

    // 5. Clean temporary key
    await prefs.remove(tmpKey);
  }
}
