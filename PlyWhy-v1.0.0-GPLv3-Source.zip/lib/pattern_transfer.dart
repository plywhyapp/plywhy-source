import 'dart:math';

import 'content_repository.dart';

const Map<String, List<String>> _patternThemeMap = {
  'King Safety': ['mate', 'mateIn1', 'mateIn2', 'mateIn3', 'smotheredMate', 'backRankMate', 'hookMate', 'arabianMate', 'anastasiaMate'],
  'King Activity & Blockade': ['endgame', 'kingEndgame', 'pawnEndgame'],
  'King Safety & Placement': ['exposedKing', 'kingsideAttack', 'queensideAttack', 'castling'],
  'Loose Piece Detection': ['hangingPiece', 'fork', 'discoveredAttack'],
  'Opponent Response': ['skewer', 'pin', 'deflection', 'attraction', 'interference'],
  'Move Safety': ['crushing', 'advantage'],
  'Board Change Awareness': ['discoveredAttack', 'discoveredCheck', 'clearance', 'intermezzo'],
};

List<ContentPuzzle> selectPatternTransferPuzzles(
  List<ContentPuzzle> puzzles, {
  required String lessonTitle,
  int count = 2,
  Random? random,
}) {
  if (count <= 0 || puzzles.isEmpty) return const [];
  final rng = random ?? Random();

  final validThemes = _patternThemeMap[lessonTitle] ?? [];
  final themeSet = validThemes.toSet();

  if (themeSet.isEmpty) return const [];

  bool eligible(ContentPuzzle puzzle) {
    final moves = puzzle.moveList;
    if (moves.length < 2) return false;
    if (moves[1].length != 4) return false; // Avoid promotions
    if (puzzle.ratingDeviation > 120) return false; // Reliable rating
    if (puzzle.popularity < 75) return false; // Well liked

    // Match at least one theme
    if (themeSet.isNotEmpty) {
      if (!puzzle.themes.any(themeSet.contains)) return false;
    }
    return true;
  }

  final candidates = puzzles.where(eligible).toList()..shuffle(rng);
  return candidates.take(count).toList(growable: false);
}
