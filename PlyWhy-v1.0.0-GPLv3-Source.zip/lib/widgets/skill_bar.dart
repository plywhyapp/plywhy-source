import 'package:flutter/material.dart';

import '../models.dart';

class SkillBar extends StatelessWidget {
  final Skill skill;
  final int score;

  const SkillBar({super.key, required this.skill, required this.score});

  @override
  Widget build(BuildContext context) {
    final normalized = score.clamp(0, 100);
    final color = normalized < 40
        ? const Color(0xFFF09B89)
        : normalized < 70
            ? const Color(0xFFF0C77D)
            : const Color(0xFF7AD5B5);
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  skillName(skill),
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                '$normalized',
                style: TextStyle(
                  color: color,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                ' /100',
                style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 9),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: normalized / 100,
              minHeight: 8,
              backgroundColor: scheme.onSurface.withValues(alpha: 0.09),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }
}
