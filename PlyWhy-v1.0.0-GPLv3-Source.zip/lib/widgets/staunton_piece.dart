import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

enum StauntonPieceKind { king, queen, rook, bishop, knight, pawn }

@immutable
class StauntonPieceSpec {
  final StauntonPieceKind kind;
  final bool isWhite;
  final String assetPath;

  const StauntonPieceSpec(this.kind, this.isWhite, this.assetPath);
}

StauntonPieceSpec? stauntonSpecForSymbol(String? symbol) {
  switch (symbol) {
    case '♔':
      return const StauntonPieceSpec(
        StauntonPieceKind.king,
        true,
        'assets/pieces/chessnut/wK.svg',
      );
    case '♕':
      return const StauntonPieceSpec(
        StauntonPieceKind.queen,
        true,
        'assets/pieces/chessnut/wQ.svg',
      );
    case '♖':
      return const StauntonPieceSpec(
        StauntonPieceKind.rook,
        true,
        'assets/pieces/chessnut/wR.svg',
      );
    case '♗':
      return const StauntonPieceSpec(
        StauntonPieceKind.bishop,
        true,
        'assets/pieces/chessnut/wB.svg',
      );
    case '♘':
      return const StauntonPieceSpec(
        StauntonPieceKind.knight,
        true,
        'assets/pieces/chessnut/wN.svg',
      );
    case '♙':
      return const StauntonPieceSpec(
        StauntonPieceKind.pawn,
        true,
        'assets/pieces/chessnut/wP.svg',
      );
    case '♚':
      return const StauntonPieceSpec(
        StauntonPieceKind.king,
        false,
        'assets/pieces/chessnut/bK.svg',
      );
    case '♛':
      return const StauntonPieceSpec(
        StauntonPieceKind.queen,
        false,
        'assets/pieces/chessnut/bQ.svg',
      );
    case '♜':
      return const StauntonPieceSpec(
        StauntonPieceKind.rook,
        false,
        'assets/pieces/chessnut/bR.svg',
      );
    case '♝':
      return const StauntonPieceSpec(
        StauntonPieceKind.bishop,
        false,
        'assets/pieces/chessnut/bB.svg',
      );
    case '♞':
      return const StauntonPieceSpec(
        StauntonPieceKind.knight,
        false,
        'assets/pieces/chessnut/bN.svg',
      );
    case '♟':
      return const StauntonPieceSpec(
        StauntonPieceKind.pawn,
        false,
        'assets/pieces/chessnut/bP.svg',
      );
  }
  return null;
}

class StauntonPiece extends StatelessWidget {
  final String symbol;

  const StauntonPiece({super.key, required this.symbol});

  @override
  Widget build(BuildContext context) {
    final spec = stauntonSpecForSymbol(symbol);
    if (spec == null) return const SizedBox.shrink();

    return SvgPicture.asset(
      spec.assetPath,
      fit: BoxFit.contain,
      alignment: Alignment.center,
      semanticsLabel:
          '${spec.isWhite ? 'White' : 'Black'} ${spec.kind.name}',
    );
  }
}
