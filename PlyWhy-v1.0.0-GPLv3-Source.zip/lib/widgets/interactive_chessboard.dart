import 'package:flutter/material.dart';

import 'staunton_piece.dart';

@immutable
class BoardArrow {
  final String from;
  final String to;
  final Color color;

  const BoardArrow({
    required this.from,
    required this.to,
    this.color = const Color(0xD92F7D32),
  });
}

class InteractiveChessBoard extends StatelessWidget {
  final Map<String, String> board;
  final ValueChanged<String>? onSquareTap;
  final String? selectedFrom;
  final String? selectedTo;
  final Set<String> destinationSquares;
  final Set<String> accentSquares;
  final List<BoardArrow> arrows;
  final bool flipped;

  const InteractiveChessBoard({
    super.key,
    required this.board,
    this.onSquareTap,
    this.selectedFrom,
    this.selectedTo,
    this.destinationSquares = const {},
    this.accentSquares = const {},
    this.arrows = const [],
    this.flipped = false,
  });

  static const _lightSquare = Color(0xFFEEEED2);
  static const _darkSquare = Color(0xFF769656);
  static const _fromHighlight = Color(0x99F6F669);
  static const _toHighlight = Color(0xB8F6F669);
  static const _accentHighlight = Color(0x8059B9FF);

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xFF151A1C),
            width: 2,
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x52000000),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            fit: StackFit.expand,
            children: [
              GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                padding: EdgeInsets.zero,
                itemCount: 64,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 8,
                ),
                itemBuilder: (context, index) {
                  final row = index ~/ 8;
                  final col = index % 8;
                  final fileIndex = flipped ? 7 - col : col;
                  final rank = flipped ? row + 1 : 8 - row;
                  final file =
                      String.fromCharCode('a'.codeUnitAt(0) + fileIndex);
                  final square = '$file$rank';
                  final isLight = (fileIndex + rank) % 2 == 0;
                  final isFrom = square == selectedFrom;
                  final isTo = square == selectedTo;
                  final isDestination = destinationSquares.contains(square);
                  final isAccent = accentSquares.contains(square);
                  final piece = board[square];

                  return Material(
                    color: isLight ? _lightSquare : _darkSquare,
                    child: InkWell(
                      key: ValueKey('square_$square'),
                      onTap: onSquareTap == null
                          ? null
                          : () => onSquareTap!(square),
                      splashColor: const Color(0x33000000),
                      highlightColor: const Color(0x22000000),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (isAccent)
                            const ColoredBox(color: _accentHighlight),
                          if (isFrom)
                            const ColoredBox(color: _fromHighlight),
                          if (isTo)
                            const ColoredBox(color: _toHighlight),
                          if (piece != null)
                            Center(
                              child: FractionallySizedBox(
                                widthFactor: 0.91,
                                heightFactor: 0.91,
                                child: StauntonPiece(symbol: piece),
                              ),
                            ),
                          if (isDestination)
                            Center(
                              child: piece == null
                                  ? Container(
                                      width: 13,
                                      height: 13,
                                      decoration: const BoxDecoration(
                                        color: Color(0x66000000),
                                        shape: BoxShape.circle,
                                      ),
                                    )
                                  : FractionallySizedBox(
                                      widthFactor: 0.84,
                                      heightFactor: 0.84,
                                      child: DecoratedBox(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: const Color(0x73000000),
                                            width: 5,
                                          ),
                                        ),
                                      ),
                                    ),
                            ),
                          if (col == 0)
                            Positioned(
                              left: 3,
                              top: 2,
                              child: _CoordinateLabel(
                                text: '$rank',
                                color: isLight ? _darkSquare : _lightSquare,
                              ),
                            ),
                          if (row == 7)
                            Positioned(
                              right: 3,
                              bottom: 1,
                              child: _CoordinateLabel(
                                text: file,
                                color: isLight ? _darkSquare : _lightSquare,
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              if (arrows.isNotEmpty)
                IgnorePointer(
                  child: CustomPaint(
                    painter: _BoardArrowPainter(
                      arrows: arrows,
                      flipped: flipped,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CoordinateLabel extends StatelessWidget {
  final String text;
  final Color color;

  const _CoordinateLabel({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        height: 1,
        fontSize: 10,
        fontWeight: FontWeight.w800,
        color: color,
        shadows: const [
          Shadow(
            color: Color(0x33000000),
            blurRadius: 1,
            offset: Offset(0, 0.5),
          ),
        ],
      ),
    );
  }
}

class _BoardArrowPainter extends CustomPainter {
  final List<BoardArrow> arrows;
  final bool flipped;

  const _BoardArrowPainter({required this.arrows, required this.flipped});

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 8;

    for (final arrow in arrows) {
      final start = _squareCenter(arrow.from, cell);
      final end = _squareCenter(arrow.to, cell);
      if (start == null || end == null) continue;

      final delta = end - start;
      final distance = delta.distance;
      if (distance == 0) continue;

      final unit = delta / distance;
      final perpendicular = Offset(-unit.dy, unit.dx);
      final headLength = cell * 0.30;
      final headHalfWidth = cell * 0.16;
      final lineEnd = end - (unit * (headLength * 0.58));

      final shaftPaint = Paint()
        ..color = arrow.color
        ..strokeWidth = cell * 0.105
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;

      canvas.drawLine(start, lineEnd, shaftPaint);

      final headBase = end - (unit * headLength);
      final head = Path()
        ..moveTo(end.dx, end.dy)
        ..lineTo(
          headBase.dx + perpendicular.dx * headHalfWidth,
          headBase.dy + perpendicular.dy * headHalfWidth,
        )
        ..lineTo(
          headBase.dx - perpendicular.dx * headHalfWidth,
          headBase.dy - perpendicular.dy * headHalfWidth,
        )
        ..close();

      canvas.drawPath(
        head,
        Paint()
          ..color = arrow.color
          ..style = PaintingStyle.fill,
      );
    }
  }

  Offset? _squareCenter(String square, double cell) {
    if (!RegExp(r'^[a-h][1-8]$').hasMatch(square)) return null;

    final fileIndex = square.codeUnitAt(0) - 'a'.codeUnitAt(0);
    final rank = int.parse(square[1]);
    final col = flipped ? 7 - fileIndex : fileIndex;
    final row = flipped ? rank - 1 : 8 - rank;

    return Offset((col + 0.5) * cell, (row + 0.5) * cell);
  }

  @override
  bool shouldRepaint(covariant _BoardArrowPainter oldDelegate) {
    return oldDelegate.flipped != flipped || oldDelegate.arrows != arrows;
  }
}
