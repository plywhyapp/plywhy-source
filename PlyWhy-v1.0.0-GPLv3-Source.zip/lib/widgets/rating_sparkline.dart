import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Compact, legible trend chart. Keeps the same public API as the old widget.
class RatingSparkline extends StatelessWidget {
  final List<int> values;

  const RatingSparkline({super.key, required this.values});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (values.length < 2) {
      return SizedBox(
        height: 132,
        child: Center(
          child: Text(
            'Complete more sessions to see your rating trend.',
            textAlign: TextAlign.center,
            style: TextStyle(color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }

    final change = values.last - values.first;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Text(
              '${values.last}',
              style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 10),
            Text(
              '${change > 0 ? '+' : ''}$change over ${values.length} records',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: change >= 0
                    ? const Color(0xFF79D7B4)
                    : const Color(0xFFF4AA9A),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 112,
          width: double.infinity,
          child: CustomPaint(
            painter: _RatingTrendPainter(
              values: values,
              lineColor: const Color(0xFF85D9BE),
              gridColor: scheme.onSurface.withValues(alpha: 0.12),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('EARLIER', style: _axisStyle(scheme)),
            Text('LATEST', style: _axisStyle(scheme)),
          ],
        ),
      ],
    );
  }

  static TextStyle _axisStyle(ColorScheme colors) => TextStyle(
        color: colors.onSurfaceVariant,
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.0,
      );
}

class _RatingTrendPainter extends CustomPainter {
  final List<int> values;
  final Color lineColor;
  final Color gridColor;

  const _RatingTrendPainter({
    required this.values,
    required this.lineColor,
    required this.gridColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0 || values.length < 2) return;

    final low = values.reduce(math.min).toDouble();
    final high = values.reduce(math.max).toDouble();
    final span = math.max(1.0, high - low);
    final left = 7.0;
    final right = math.max(left, size.width - 7);
    final top = 10.0;
    final bottom = math.max(top, size.height - 10);

    for (var i = 0; i < 3; i++) {
      final y = top + (bottom - top) * (i / 2);
      canvas.drawLine(
        Offset(left, y),
        Offset(right, y),
        Paint()
          ..color = gridColor
          ..strokeWidth = 1,
      );
    }

    final points = <Offset>[];
    for (var i = 0; i < values.length; i++) {
      final x = left + (right - left) * i / (values.length - 1);
      final y = bottom - (values[i] - low) / span * (bottom - top);
      points.add(Offset(x, y));
    }

    // Straight segments avoid inventing intermediate data points.
    final line = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) {
      line.lineTo(point.dx, point.dy);
    }

    final fill = Path.from(line)
      ..lineTo(points.last.dx, bottom)
      ..lineTo(points.first.dx, bottom)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            lineColor.withValues(alpha: 0.28),
            lineColor.withValues(alpha: 0.01),
          ],
        ).createShader(Rect.fromLTWH(0, top, size.width, bottom - top)),
    );
    canvas.drawPath(
      line,
      Paint()
        ..color = lineColor
        ..strokeWidth = 3
        ..strokeJoin = StrokeJoin.round
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke,
    );
    final last = points.last;
    canvas.drawCircle(last, 7, Paint()..color = lineColor.withValues(alpha: 0.2));
    canvas.drawCircle(last, 4.5, Paint()..color = lineColor);
    canvas.drawCircle(last, 2, Paint()..color = const Color(0xFF112721));
  }

  @override
  bool shouldRepaint(covariant _RatingTrendPainter oldDelegate) {
    if (oldDelegate.lineColor != lineColor || oldDelegate.gridColor != gridColor) {
      return true;
    }
    if (identical(oldDelegate.values, values)) return false;
    if (oldDelegate.values.length != values.length) return true;
    for (var i = 0; i < values.length; i++) {
      if (oldDelegate.values[i] != values[i]) return true;
    }
    return false;
  }
}
