import 'package:flutter/material.dart';

import '../fen_utils.dart';
import '../models.dart';
import 'interactive_chessboard.dart';

class ExercisePage extends StatelessWidget {
  final String title;
  final int currentNumber;
  final int totalNumber;
  final Exercise exercise;
  final int? selected;
  final void Function(int) onSelect;
  final VoidCallback onNext;
  final String finalButton;

  const ExercisePage({
    super.key,
    required this.title,
    required this.currentNumber,
    required this.totalNumber,
    required this.exercise,
    required this.selected,
    required this.onSelect,
    required this.onNext,
    required this.finalButton,
  });

  @override
  Widget build(BuildContext context) {
    final board = parseFenBoard(exercise.fen);

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        centerTitle: true,
      ),
      bottomNavigationBar: selected == null
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: SizedBox(
                  height: 52,
                  child: FilledButton(
                    onPressed: onNext,
                    child: Text(
                      finalButton,
                      style: const TextStyle(fontSize: 18),
                    ),
                  ),
                ),
              ),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Text('Question $currentNumber of $totalNumber'),
                  const Spacer(),
                  Flexible(
                    child: Text(
                      skillName(exercise.skill),
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              LinearProgressIndicator(
                value: currentNumber / totalNumber,
                borderRadius: BorderRadius.circular(999),
              ),
              const SizedBox(height: 18),
              Text(
                skillName(exercise.skill),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                exercise.subtitle,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              InteractiveChessBoard(board: board),
              const SizedBox(height: 18),
              Text(
                exercise.question,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 14),
              ...List.generate(exercise.answers.length, (index) {
                Color? color;
                if (selected != null) {
                  if (index == exercise.correctIndex) {
                    color = Colors.green.shade700;
                  } else if (index == selected) {
                    color = Colors.red.shade700;
                  }
                }

                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: selected == null ? () => onSelect(index) : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        disabledBackgroundColor: color,
                        padding: const EdgeInsets.all(14),
                      ),
                      child: Text(
                        '${String.fromCharCode(65 + index)}. ${exercise.answers[index]}',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                );
              }),
              if (selected != null) ...[
                const SizedBox(height: 10),
                Text(
                  selected == exercise.correctIndex ? '✓ Correct' : '✗ Incorrect',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: selected == exercise.correctIndex
                        ? Colors.greenAccent
                        : Colors.redAccent,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  exercise.explanation,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 70),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
