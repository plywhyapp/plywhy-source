import 'package:flutter/material.dart';

import '../engine_api.dart';
import '../engine_config.dart';
import '../engine_explanation.dart';
import '../fen_utils.dart';
import '../pattern_cards.dart';
import '../pattern_practice.dart';
import 'interactive_chessboard.dart';

class PatternPracticeCard extends StatefulWidget {
  final PatternCard card;
  final bool revealed;

  const PatternPracticeCard({
    super.key,
    required this.card,
    required this.revealed,
  });

  @override
  State<PatternPracticeCard> createState() => _PatternPracticeCardState();
}

class _PatternPracticeCardState extends State<PatternPracticeCard> {
  PatternPractice? _practice;
  PracticeAttempt? _attempt;
  EngineMoveResult? _evaluation;
  IoEngineTransport? _transport;
  String? _selected;
  String? _notice;
  String? _positionError;
  String? _replyFen;
  String? _replyUci;
  String? _shownReplyUci;
  bool _analyzing = false;
  bool _showSavedMove = false;
  bool _choosingPromotion = false;
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    try {
      _practice = PatternPractice(
        fenBefore: widget.card.fenBefore,
        savedMoveUci: widget.card.correctMoveUci,
        originalSan: widget.card.wrongMove,
      );
    } catch (_) {
      _positionError = 'This saved position cannot be played. Analyze the source game again to rebuild the card.';
    }
  }

  @override
  void dispose() {
    _generation++;
    _transport?.close();
    super.dispose();
  }

  void _reset() {
    _generation++;
    _transport?.close();
    _transport = null;
    setState(() {
      _attempt = null;
      _evaluation = null;
      _selected = null;
      _notice = null;
      _replyFen = null;
      _replyUci = null;
      _shownReplyUci = null;
      _analyzing = false;
      _showSavedMove = false;
    });
  }

  Future<void> _tap(String square) async {
    if (_attempt != null || _showSavedMove || _choosingPromotion) return;
    final practice = _practice!;
    if (square == _selected) {
      setState(() => _selected = null);
      return;
    }
    final candidates = practice.legalMoves
        .where((move) => move['from'] == _selected && move['to'] == square)
        .toList();
    if (candidates.isEmpty) {
      setState(() {
        if (practice.destinations(square).isNotEmpty) {
          _selected = square;
          _notice = null;
        } else {
          _notice = 'Select a piece with a legal move, then tap a highlighted square.';
        }
      });
      return;
    }
    var move = candidates.first;
    if (candidates.length > 1) {
      _choosingPromotion = true;
      final generation = _generation;
      final promotion = await showDialog<String>(
        context: context,
        builder: (context) => SimpleDialog(
          title: const Text('Promote to'),
          children: [
            for (final entry in const {
              'q': 'Queen',
              'r': 'Rook',
              'b': 'Bishop',
              'n': 'Knight',
            }.entries)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(context, entry.key),
                child: Text(entry.value),
              ),
          ],
        ),
      );
      _choosingPromotion = false;
      if (!mounted || generation != _generation || promotion == null) return;
      move = candidates.firstWhere(
        (candidate) => candidate['promotion'] == promotion,
      );
    }
    final attempt = practice.play(PatternPractice.uciOf(move));
    setState(() {
      _attempt = attempt;
      _selected = null;
      _notice = null;
      // This stored reply was calculated after the ORIGINAL mistake only.
      _replyUci = attempt.repeatsOriginalMove
          ? widget.card.opponentReplyUci
          : null;
    });
    if (EngineConfig.isConfigured) await _analyze(attempt);
  }

  Future<void> _analyze(PracticeAttempt attempt) async {
    final generation = ++_generation;
    _transport?.close();
    final transport = IoEngineTransport(
      baseUrl: EngineConfig.baseUrl,
      timeout: const Duration(seconds: 20),
    );
    _transport = transport;
    setState(() => _analyzing = true);
    try {
      final evaluation = await _practice!
          .analyze(attempt, EngineApiClient(transport: transport))
          .timeout(const Duration(seconds: 25));
      if (!mounted || generation != _generation) return;
      setState(() {
        _evaluation = evaluation;
        _replyUci = evaluation.opponentBestReplyUci;
        _notice = null;
      });
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() {
        _notice =
            'Engine evaluation is unavailable. The observations below are based on legal moves only. '
            'An alternative move has not been graded.';
      });
    } finally {
      transport.close();
      if (mounted && generation == _generation) {
        _transport = null;
        setState(() => _analyzing = false);
      }
    }
  }

  void _showRecommendation() {
    try {
      // Replaying the recommendation also goes through the legal move checker.
      _practice!.play(widget.card.correctMoveUci);
      setState(() {
        _showSavedMove = true;
        _selected = null;
        _replyFen = null;
        _shownReplyUci = null;
      });
    } on FormatException {
      setState(
        () => _notice = 'The saved recommendation is invalid for this position. Reanalyze the original game.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_positionError != null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(_positionError!),
        ),
      );
    }
    final card = widget.card;
    final attempt = _attempt;
    var fen = _replyFen ?? attempt?.fenAfter ?? card.fenBefore;
    String? lastUci = _shownReplyUci ?? attempt?.uci;
    if (_showSavedMove) {
      fen = _practice!.play(card.correctMoveUci).fenAfter;
      lastUci = card.correctMoveUci;
    }
    final replyFen = attempt == null
        ? null
        : PatternPractice.afterReply(attempt, _replyUci);
    final evaluation = _evaluation;
    final explanation =
        evaluation != null &&
            attempt != null &&
            {
              EngineMoveQuality.inaccuracy,
              EngineMoveQuality.mistake,
              EngineMoveQuality.blunder,
            }.contains(evaluation.quality)
        ? buildEngineMoveExplanation(evaluation, _practice!.contextFor(attempt))
        : null;
    final white = card.fenBefore.split(RegExp(r'\s+'))[1] == 'w';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Training side: ${white ? 'White' : 'Black'}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(card.sourceGame, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 10),
            Text(
              _showSavedMove
                  ? 'Saved recommended move'
                  : _replyFen != null
                  ? 'Position after the opponent’s reply'
                  : attempt != null
                  ? 'Your move: ${attempt.san}'
                  : 'Your turn — find a plan',
            ),
            Text(
              '${fen.split(RegExp(r'\s+'))[1] == 'w' ? 'White' : 'Black'} to move in the position shown',
            ),
            const SizedBox(height: 8),
            InteractiveChessBoard(
              key: const ValueKey('pattern-card-board'),
              board: parseFenBoard(fen),
              flipped: card.flipped,
              onSquareTap: attempt == null && !_showSavedMove ? _tap : null,
              selectedFrom: _selected ?? lastUci?.substring(0, 2),
              selectedTo: lastUci?.substring(2, 4),
              destinationSquares: _selected == null
                  ? const {}
                  : _practice!.destinations(_selected!),
              arrows: lastUci == null
                  ? const []
                  : [
                      BoardArrow(
                        from: lastUci.substring(0, 2),
                        to: lastUci.substring(2, 4),
                      ),
                    ],
            ),
            const SizedBox(height: 12),
            if (attempt == null && !_showSavedMove) ...[
              const Text(
                'Before moving',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text(
                '1. What is the opponent threatening?\n'
                '2. What will change if I move this piece?\n'
                '3. What check, capture or threat could they play next?',
              ),
              const SizedBox(height: 8),
              const Text(
                'Tap your piece, then a highlighted destination to try your idea.',
              ),
            ],
            if (_notice != null) ...[
              const SizedBox(height: 10),
              Text(_notice!),
            ],
            if (attempt != null) ...[
              const SizedBox(height: 12),
              if (_analyzing) const LinearProgressIndicator(),
              if (_analyzing) const Text('Analyzing your move…'),
              _PracticeDetail(
                'Your decision: ${attempt.san}',
                evaluation != null
                    ? 'Engine evaluation: ${engineMoveQualityLabel(evaluation.quality)}'
                    : attempt.matchesSavedMove
                    ? 'You found the saved engine recommendation. Explain what it solves before moving on.'
                    : attempt.repeatsOriginalMove
                    ? 'You repeated the move reviewed in your original game. Examine the saved reply and compare another idea.'
                    : 'You chose a different legal move. Its quality has not been verified by the engine.',
              ),
              _PracticeDetail(
                'What changed on the board',
                attempt.facts.join('\n\n'),
              ),
              if (explanation != null) ...[
                _PracticeDetail('What to notice', explanation.whatFailed),
                _PracticeDetail(
                  'Why the reply matters',
                  explanation.whyItWorks,
                ),
                _PracticeDetail('A better decision', explanation.betterChoice),
              ],
              if (evaluation != null &&
                  explanation == null &&
                  evaluation.quality != EngineMoveQuality.unknown)
                const _PracticeDetail(
                  'Explain your idea',
                  'What threat does your move address? Which squares or defenders changed? '
                      'Before calling the pattern learned, explain the opponent’s strongest response.',
                ),
              if (replyFen != null) ...[
                _PracticeDetail(
                  evaluation == null
                      ? 'Reply saved from the original game'
                      : 'Reply returned by the engine',
                  humanizeUciMove(attempt.fenAfter, _replyUci!),
                ),
                OutlinedButton(
                  key: const ValueKey('pattern-show-reply'),
                  onPressed: () => setState(() {
                    _showSavedMove = false;
                    _replyFen = replyFen;
                    _shownReplyUci = _replyUci;
                  }),
                  child: const Text('Show opponent reply'),
                ),
              ],
              if (!EngineConfig.isConfigured && evaluation == null)
                const Text(
                  'Live analysis is not connected. Saved recommendations and legal-move observations remain available.',
                ),
              if (EngineConfig.isConfigured &&
                  !_analyzing &&
                  evaluation == null)
                TextButton(
                  onPressed: () => _analyze(attempt),
                  child: const Text('Retry engine analysis'),
                ),
            ],
            if (attempt != null || _showSavedMove)
              OutlinedButton.icon(
                key: const ValueKey('pattern-try-again'),
                onPressed: _reset,
                icon: const Icon(Icons.replay),
                label: const Text('Try another idea'),
              ),
            if (widget.revealed) ...[
              const Divider(height: 24),
              const Text(
                'Review the original game',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(card.moveLabel),
              TextButton(
                onPressed: _showRecommendation,
                child: const Text('Show saved recommended move'),
              ),
              _PracticeDetail('Pattern', card.lessonTitle),
              _PracticeDetail('1. Concrete mistake', card.whatFailed),
              _PracticeDetail('2. Position change & opponent gain', card.whyItWorks),
              _PracticeDetail('3. Strongest reply', card.punishment),
              _PracticeDetail('3. Verifiable consequence', card.consequence),
              _PracticeDetail('4. Better choice comparison', card.betterChoice),
              _PracticeDetail('5. Chess principle', card.lessonText),
              _PracticeDetail('6. Reflection question', card.reflectionQuestion),
            ],
          ],
        ),
      ),
    );
  }
}

class _PracticeDetail extends StatelessWidget {
  final String title;
  final String text;
  const _PracticeDetail(this.title, this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(text),
      ],
    ),
  );
}
