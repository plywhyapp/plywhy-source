import 'dart:convert';
import 'dart:math';

import 'package:flutter/services.dart';

import 'mode_content.dart';
import 'models.dart';

class ContentPuzzle {
  final String id;
  final String fen;
  final String moves;
  final int rating;
  final int ratingDeviation;
  final int popularity;
  final int plays;
  final List<String> themes;

  const ContentPuzzle({
    required this.id,
    required this.fen,
    required this.moves,
    required this.rating,
    required this.ratingDeviation,
    required this.popularity,
    required this.plays,
    required this.themes,
  });

  factory ContentPuzzle.fromJson(Map<String, dynamic> json) {
    return ContentPuzzle(
      id: json['id'] as String,
      fen: json['fen'] as String,
      moves: json['moves'] as String,
      rating: (json['rating'] as num).toInt(),
      ratingDeviation: (json['rd'] as num).toInt(),
      popularity: (json['popularity'] as num).toInt(),
      plays: (json['plays'] as num).toInt(),
      themes: (json['themes'] as List<dynamic>).cast<String>(),
    );
  }

  List<String> get moveList =>
      moves.trim().split(RegExp(r'\s+')).where((move) => move.isNotEmpty).toList();
}

class ContentPack {
  final List<ContentPuzzle> puzzles;

  const ContentPack(this.puzzles);

  static ContentPack parse(String jsonText) {
    final decoded = jsonDecode(jsonText);
    if (decoded is! List<dynamic>) {
      throw const FormatException('Content pack root must be a JSON array.');
    }

    final puzzles = decoded
        .map((value) => ContentPuzzle.fromJson(value as Map<String, dynamic>))
        .toList(growable: false);
    return ContentPack(puzzles);
  }
}

class PuzzleContentRepository {
  static const assetPath = 'assets/content/lichess_puzzles_5000.json';
  static const expectedPackSize = 5000;

  static ContentPack? _cache;

  Future<ContentPack> loadPack() async {
    final cached = _cache;
    if (cached != null) return cached;

    final text = await rootBundle.loadString(assetPath);
    final pack = ContentPack.parse(text);
    if (pack.puzzles.length < expectedPackSize) {
      throw StateError(
        'ChessSense content pack is incomplete: '
        '${pack.puzzles.length}/$expectedPackSize positions.',
      );
    }

    _cache = pack;
    return pack;
  }

  Future<List<InteractiveMoveScenario>> buildOpponentVisionSession({
    required int skillScore,
    required List<String> recentExerciseIds,
    int count = 5,
    Random? random,
  }) async {
    try {
      final pack = await loadPack();
      final candidates = selectOpponentVisionPuzzles(
        pack.puzzles,
        skillScore: skillScore,
        recentExerciseIds: recentExerciseIds,
        count: count,
        random: random,
      );

      if (candidates.length >= count) {
        return candidates.map(opponentVisionScenarioFromPuzzle).toList();
      }
    } catch (_) {
      // Keep the app usable if the optional large content asset is unavailable.
      // The automated QA pipeline verifies the production pack before release.
    }

    final fallback = [...opponentVisionScenarios]..shuffle(random ?? Random());
    return fallback.take(min(count, fallback.length)).toList();
  }
}

int targetLichessPuzzleRating(int skillScore) {
  final normalized = skillScore.clamp(0, 100).toInt();
  return 850 + (normalized * 14);
}

List<ContentPuzzle> selectOpponentVisionPuzzles(
  List<ContentPuzzle> puzzles, {
  required int skillScore,
  required List<String> recentExerciseIds,
  int count = 5,
  Random? random,
}) {
  if (count <= 0 || puzzles.isEmpty) return const [];

  final rng = random ?? Random();
  final recent = recentExerciseIds.toSet();
  final target = targetLichessPuzzleRating(skillScore);

  bool eligible(ContentPuzzle puzzle) {
    final moves = puzzle.moveList;
    if (moves.length < 2) return false;
    if (moves[1].length != 4) return false; // promotions need an extra UI choice
    if (puzzle.themes.contains('mateIn1')) return false; // may have alternate mates
    if (puzzle.popularity < 60) return false;
    if (puzzle.ratingDeviation > 140) return false;
    return true;
  }

  final candidates = puzzles.where(eligible).toList()..shuffle(rng);
  candidates.sort((a, b) {
    final aRecent = recent.contains('LCH_${a.id}') ? 1 : 0;
    final bRecent = recent.contains('LCH_${b.id}') ? 1 : 0;
    final recentCompare = aRecent.compareTo(bRecent);
    if (recentCompare != 0) return recentCompare;

    final aDistance = (a.rating - target).abs();
    final bDistance = (b.rating - target).abs();
    final distanceCompare = aDistance.compareTo(bDistance);
    if (distanceCompare != 0) return distanceCompare;

    return b.popularity.compareTo(a.popularity);
  });

  return candidates.take(min(count, candidates.length)).toList();
}

InteractiveMoveScenario opponentVisionScenarioFromPuzzle(ContentPuzzle puzzle) {
  final moves = puzzle.moveList;
  if (moves.length < 2) {
    throw ArgumentError('Puzzle ${puzzle.id} has no playable response.');
  }

  final setup = moves[0];
  final response = moves[1];
  final primaryTheme = _primaryTheme(puzzle.themes);
  final prettyTheme = _prettyTheme(primaryTheme);

  return InteractiveMoveScenario(
    id: 'LCH_${puzzle.id}',
    skill: Skill.opponentResponse,
    title: prettyTheme == null ? 'Predict the reply' : 'Predict the reply · $prettyTheme',
    subtitle:
        'Lichess puzzle ${puzzle.rating} · find the strongest response after the last move.',
    fen: puzzle.fen,
    setupMovesUci: [setup],
    setupMoveLabel: _prettyUci(setup),
    correctMoveUci: response,
    correctMoveLabel: _prettyUci(response),
    explanation: _explanationForPuzzle(puzzle, response),
    dangerPattern: _dangerPatternForThemes(puzzle.themes),
    validationStatus: ValidationStatus.engineValidated,
  );
}

String _prettyUci(String uci) {
  if (uci.length < 4) return uci;
  final from = uci.substring(0, 2);
  final to = uci.substring(2, 4);
  final promotion = uci.length > 4 ? '=${uci.substring(4).toUpperCase()}' : '';
  return '$from → $to$promotion';
}

String? _primaryTheme(List<String> themes) {
  const preferred = [
    'hangingPiece',
    'fork',
    'pin',
    'skewer',
    'discoveredAttack',
    'doubleCheck',
    'backRankMate',
    'deflection',
    'attraction',
    'interference',
    'clearance',
    'sacrifice',
    'defensiveMove',
    'quietMove',
    'mate',
  ];

  for (final theme in preferred) {
    if (themes.contains(theme)) return theme;
  }
  return themes.isEmpty ? null : themes.first;
}

String? _prettyTheme(String? theme) {
  if (theme == null) return null;
  const names = {
    'hangingPiece': 'Loose piece',
    'fork': 'Fork',
    'pin': 'Pin',
    'skewer': 'Skewer',
    'discoveredAttack': 'Discovered attack',
    'doubleCheck': 'Double check',
    'backRankMate': 'Back rank',
    'deflection': 'Deflection',
    'attraction': 'Attraction',
    'interference': 'Interference',
    'clearance': 'Clearance',
    'sacrifice': 'Sacrifice',
    'defensiveMove': 'Defensive resource',
    'quietMove': 'Quiet move',
    'mate': 'Mate threat',
  };
  return names[theme] ?? theme;
}

String _dangerPatternForThemes(List<String> themes) {
  if (themes.contains('hangingPiece')) return 'Loose piece blindness';
  if (themes.contains('fork')) return 'Fork blindness';
  if (themes.contains('pin')) return 'Pin blindness';
  if (themes.contains('skewer')) return 'Skewer blindness';
  if (themes.contains('discoveredAttack')) return 'Discovered attack blindness';
  if (themes.contains('backRankMate')) return 'Back-rank blindness';
  if (themes.contains('defensiveMove')) return 'Defensive resource blindness';
  if (themes.contains('mate')) return 'Forcing-move blindness';
  return 'Opponent response blindness';
}

String _explanationForPuzzle(ContentPuzzle puzzle, String response) {
  final namedThemes = puzzle.themes
      .map(_prettyTheme)
      .whereType<String>()
      .where((theme) => theme.isNotEmpty)
      .take(3)
      .join(', ');
  final themeText = namedThemes.isEmpty ? '' : ' Theme: $namedThemes.';
  return 'The source solution begins with ${_prettyUci(response)} after the setup move.'
      '$themeText This position comes from the Lichess puzzle database.';
}
