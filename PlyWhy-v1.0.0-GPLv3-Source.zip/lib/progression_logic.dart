import 'models.dart';

const int xpPerLevel = 250;
const int weeklySessionGoal = 3;

int levelForXp(int xp) => (xp < 0 ? 0 : xp) ~/ xpPerLevel + 1;

int xpIntoCurrentLevel(int xp) => (xp < 0 ? 0 : xp) % xpPerLevel;

double levelProgress(int xp) => xpIntoCurrentLevel(xp) / xpPerLevel;

int xpToNextLevel(int xp) => xpPerLevel - xpIntoCurrentLevel(xp);

Map<Skill, double> blunderDnaPercentages(Map<Skill, int> mistakeCounts) {
  final total = Skill.values.fold<int>(
    0,
    (sum, skill) => sum + (mistakeCounts[skill] ?? 0),
  );

  if (total <= 0) {
    return {for (final skill in Skill.values) skill: 0};
  }

  return {
    for (final skill in Skill.values)
      skill: (mistakeCounts[skill] ?? 0) / total,
  };
}

Skill? topMistakeSkill(Map<Skill, int> mistakeCounts) {
  final total = mistakeCounts.values.fold<int>(0, (a, b) => a + b);
  if (total <= 0) return null;

  return Skill.values.reduce((a, b) {
    final aCount = mistakeCounts[a] ?? 0;
    final bCount = mistakeCounts[b] ?? 0;
    if (aCount == bCount) return a.index <= b.index ? a : b;
    return aCount >= bCount ? a : b;
  });
}

int overconfidenceMistakeRate({
  required int highConfidenceAttempts,
  required int highConfidenceMistakes,
}) {
  if (highConfidenceAttempts <= 0) return 0;
  return ((highConfidenceMistakes / highConfidenceAttempts) * 100).round();
}

List<SessionRecord> sessionsSince(
  List<SessionRecord> history,
  DateTime start,
) {
  return history.where((record) {
    final date = DateTime.tryParse(record.timestampIso)?.toLocal();
    return date != null && !date.isBefore(start);
  }).toList();
}

List<SessionRecord> trainingSessionsSince(
  List<SessionRecord> history,
  DateTime start,
) {
  return sessionsSince(history, start)
      .where((record) => record.kind != SessionKind.assessment)
      .toList();
}

int averageAccuracy(List<SessionRecord> sessions) {
  if (sessions.isEmpty) return 0;
  final totalCorrect = sessions.fold<int>(0, (sum, r) => sum + r.correct);
  final totalQuestions = sessions.fold<int>(0, (sum, r) => sum + r.total);
  if (totalQuestions <= 0) return 0;
  return ((totalCorrect / totalQuestions) * 100).round();
}

int ratingChangeForSessions(List<SessionRecord> sessions) {
  if (sessions.isEmpty) return 0;
  final chronological = [...sessions]
    ..sort((a, b) => a.timestampIso.compareTo(b.timestampIso));
  return chronological.last.ratingAfter - chronological.first.ratingBefore;
}

Skill? mostImprovedSkill(List<SessionRecord> sessions) {
  if (sessions.length < 2) return null;
  final chronological = [...sessions]
    ..sort((a, b) => a.timestampIso.compareTo(b.timestampIso));

  final first = chronological.first.skillScoresAfter;
  final last = chronological.last.skillScoresAfter;
  Skill? best;
  int? bestDelta;

  for (final skill in Skill.values) {
    final delta = (last[skill] ?? 0) - (first[skill] ?? 0);
    if (bestDelta == null || delta > bestDelta) {
      best = skill;
      bestDelta = delta;
    }
  }
  return best;
}

int skillDeltaForSessions(List<SessionRecord> sessions, Skill skill) {
  if (sessions.length < 2) return 0;
  final chronological = [...sessions]
    ..sort((a, b) => a.timestampIso.compareTo(b.timestampIso));
  return (chronological.last.skillScoresAfter[skill] ?? 0) -
      (chronological.first.skillScoresAfter[skill] ?? 0);
}

int defaultXpForResult(TrainingResult result) {
  if (result.xpEarned > 0) return result.xpEarned;
  final perfectBonus = result.total > 0 && result.correct == result.total ? 15 : 0;
  return 15 + result.correct * 5 + perfectBonus;
}
