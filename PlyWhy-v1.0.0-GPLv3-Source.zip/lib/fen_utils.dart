const Map<String, String> _pieceSymbols = {
  'K': '♔',
  'Q': '♕',
  'R': '♖',
  'B': '♗',
  'N': '♘',
  'P': '♙',
  'k': '♚',
  'q': '♛',
  'r': '♜',
  'b': '♝',
  'n': '♞',
  'p': '♟',
};

Map<String, String> parseFenBoard(String fen) {
  final board = <String, String>{};
  final fields = fen.trim().split(RegExp(r'\s+'));
  if (fields.isEmpty) {
    throw const FormatException('FEN is empty.');
  }

  final boardPart = fields.first;
  final ranks = boardPart.split('/');

  if (ranks.length != 8) {
    throw const FormatException('FEN board must contain eight ranks.');
  }

  for (int rankIndex = 0; rankIndex < 8; rankIndex++) {
    int fileIndex = 0;

    for (final char in ranks[rankIndex].split('')) {
      final spaces = int.tryParse(char);
      if (spaces != null) {
        if (spaces < 1 || spaces > 8) {
          throw const FormatException('Invalid empty-square count in FEN.');
        }
        fileIndex += spaces;
      } else {
        if (!_pieceSymbols.containsKey(char) || fileIndex >= 8) {
          throw const FormatException('Invalid piece placement in FEN.');
        }

        final file = String.fromCharCode('a'.codeUnitAt(0) + fileIndex);
        final rank = 8 - rankIndex;
        board['$file$rank'] = _pieceSymbols[char]!;
        fileIndex++;
      }
    }

    if (fileIndex != 8) {
      throw const FormatException('Each FEN rank must contain eight squares.');
    }
  }

  return board;
}

bool isFenStructurallyValid(String fen) {
  try {
    final fields = fen.trim().split(RegExp(r'\s+'));
    if (fields.length != 6) return false;

    final board = parseFenBoard(fen);
    if (board.values.where((piece) => piece == '♔').length != 1) return false;
    if (board.values.where((piece) => piece == '♚').length != 1) return false;

    if (fields[1] != 'w' && fields[1] != 'b') return false;

    final castling = fields[2];
    if (castling != '-' && !RegExp(r'^(K?Q?k?q?)$').hasMatch(castling)) {
      return false;
    }

    final enPassant = fields[3];
    if (enPassant != '-' && !RegExp(r'^[a-h][36]$').hasMatch(enPassant)) {
      return false;
    }

    final halfmove = int.tryParse(fields[4]);
    final fullmove = int.tryParse(fields[5]);
    if (halfmove == null || halfmove < 0) return false;
    if (fullmove == null || fullmove < 1) return false;

    return !_kingsAreAdjacent(board);
  } on FormatException {
    return false;
  }
}

bool _kingsAreAdjacent(Map<String, String> board) {
  String? whiteKing;
  String? blackKing;

  for (final entry in board.entries) {
    if (entry.value == '♔') whiteKing = entry.key;
    if (entry.value == '♚') blackKing = entry.key;
  }

  if (whiteKing == null || blackKing == null) return true;

  final whiteFile = whiteKing.codeUnitAt(0);
  final whiteRank = int.parse(whiteKing.substring(1));
  final blackFile = blackKing.codeUnitAt(0);
  final blackRank = int.parse(blackKing.substring(1));

  return (whiteFile - blackFile).abs() <= 1 &&
      (whiteRank - blackRank).abs() <= 1;
}

Map<String, String> applyUciMoveToBoard(
  Map<String, String> board,
  String uci,
) {
  if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(uci)) {
    throw FormatException('Invalid UCI move: $uci');
  }

  final from = uci.substring(0, 2);
  final to = uci.substring(2, 4);
  final promotion = uci.length == 5 ? uci[4] : null;
  final piece = board[from];
  if (piece == null) {
    throw FormatException('No piece on UCI source square $from.');
  }

  final updated = Map<String, String>.from(board);
  final targetWasEmpty = !updated.containsKey(to);
  updated.remove(from);

  final isWhitePawn = piece == '♙';
  final isBlackPawn = piece == '♟';

  // En passant: a legal pawn capture can land on an empty square. The captured
  // pawn is on the destination file and the source rank.
  if ((isWhitePawn || isBlackPawn) &&
      targetWasEmpty &&
      from.codeUnitAt(0) != to.codeUnitAt(0)) {
    final capturedSquare = '${to[0]}${from[1]}';
    updated.remove(capturedSquare);
  }

  // Castling needs the rook movement too so the interactive board remains
  // visually correct for source positions loaded from the large puzzle pack.
  if (piece == '♔' && from == 'e1' && to == 'g1') {
    final rook = updated.remove('h1');
    if (rook != null) updated['f1'] = rook;
  } else if (piece == '♔' && from == 'e1' && to == 'c1') {
    final rook = updated.remove('a1');
    if (rook != null) updated['d1'] = rook;
  } else if (piece == '♚' && from == 'e8' && to == 'g8') {
    final rook = updated.remove('h8');
    if (rook != null) updated['f8'] = rook;
  } else if (piece == '♚' && from == 'e8' && to == 'c8') {
    final rook = updated.remove('a8');
    if (rook != null) updated['d8'] = rook;
  }

  var placedPiece = piece;
  if (promotion != null && (isWhitePawn || isBlackPawn)) {
    const whitePromotions = {
      'q': '♕',
      'r': '♖',
      'b': '♗',
      'n': '♘',
    };
    const blackPromotions = {
      'q': '♛',
      'r': '♜',
      'b': '♝',
      'n': '♞',
    };
    placedPiece = isWhitePawn
        ? whitePromotions[promotion]!
        : blackPromotions[promotion]!;
  }

  updated[to] = placedPiece;
  return updated;
}

Map<String, String> boardAfterUciMoves(String fen, List<String> moves) {
  var board = parseFenBoard(fen);
  for (final move in moves) {
    board = applyUciMoveToBoard(board, move);
  }
  return board;
}

String sideToMoveAfterUciMoves(String fen, int moveCount) {
  final fields = fen.trim().split(RegExp(r'\s+'));
  if (fields.length < 2 || (fields[1] != 'w' && fields[1] != 'b')) {
    throw const FormatException('FEN has no valid side-to-move field.');
  }
  final startsWhite = fields[1] == 'w';
  final whiteToMove = moveCount.isEven ? startsWhite : !startsWhite;
  return whiteToMove ? 'w' : 'b';
}

bool isBlackToMoveAfterUciMoves(String fen, int moveCount) {
  return sideToMoveAfterUciMoves(fen, moveCount) == 'b';
}

String uciFromSquares(String? from, String? to) {
  if (from == null || to == null) return '';
  return '$from$to';
}
