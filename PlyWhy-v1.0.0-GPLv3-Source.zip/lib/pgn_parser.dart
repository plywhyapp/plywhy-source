class ParsedPgnGame {
  final Map<String, String> headers;
  final List<String> sanMoves;
  final Map<int, String> annotations;
  final String result;

  const ParsedPgnGame({
    required this.headers,
    required this.sanMoves,
    this.annotations = const {},
    required this.result,
  });

  String get white => headers['White']?.trim().isNotEmpty == true
      ? headers['White']!.trim()
      : 'White';

  String get black => headers['Black']?.trim().isNotEmpty == true
      ? headers['Black']!.trim()
      : 'Black';

  String get event => headers['Event']?.trim() ?? '';
  String get date => headers['Date']?.trim() ?? '';

  int get plyCount => sanMoves.length;
  int get fullMoveCount => (sanMoves.length + 1) ~/ 2;
}

class PgnParser {
  static final RegExp _tagPattern = RegExp(
    r'^\[([A-Za-z0-9_]+)\s+"((?:\\.|[^"\\])*)"\]\s*$',
  );

  static final RegExp _moveNumberPrefix = RegExp(r'^\d+\.(?:\.\.)?');
  static final RegExp _nagTokenPattern = RegExp(r'^\$(\d+)$');
  static final RegExp _annotationSuffix = RegExp(r'[!?]+$');

  static const Set<String> _results = {
    '1-0',
    '0-1',
    '1/2-1/2',
    '*',
  };

  List<ParsedPgnGame> parse(String input) {
    final normalized = input.replaceAll('\r\n', '\n').replaceAll('\r', '\n').trim();
    if (normalized.isEmpty) return const [];

    final games = <ParsedPgnGame>[];
    var headers = <String, String>{};
    final movetext = StringBuffer();
    var sawMovetext = false;

    void flush() {
      final rawMoves = movetext.toString().trim();
      if (headers.isEmpty && rawMoves.isEmpty) return;

      final parsed = _parseMovetext(rawMoves);
      final headerResult = headers['Result'];
      final result = _results.contains(headerResult)
          ? headerResult!
          : parsed.result;

      games.add(
        ParsedPgnGame(
          headers: Map.unmodifiable(Map<String, String>.from(headers)),
          sanMoves: List.unmodifiable(parsed.moves),
          annotations: Map.unmodifiable(parsed.annotations),
          result: result,
        ),
      );

      headers = <String, String>{};
      movetext.clear();
      sawMovetext = false;
    }

    for (final rawLine in normalized.split('\n')) {
      final line = rawLine.trim();
      if (line.isEmpty) continue;

      final tag = _tagPattern.firstMatch(line);
      if (tag != null) {
        if (sawMovetext) flush();
        headers[tag.group(1)!] = _unescapeTag(tag.group(2)!);
        continue;
      }

      sawMovetext = true;
      movetext.writeln(rawLine);
    }

    flush();
    return games;
  }

  _MovetextResult _parseMovetext(String input) {
    if (input.isEmpty) {
      return const _MovetextResult(moves: [], result: '*');
    }

    var text = _removeSemicolonComments(input);
    text = _removeBraceComments(text);
    text = _removeVariations(text);
    final moves = <String>[];
    final annotations = <int, String>{};
    var result = '*';

    for (var token in text.split(RegExp(r'\s+'))) {
      token = token.trim();
      if (token.isEmpty) continue;

      while (_moveNumberPrefix.hasMatch(token)) {
        token = token.replaceFirst(_moveNumberPrefix, '');
      }

      if (token.isEmpty || token == '...') continue;

      if (_results.contains(token)) {
        result = token;
        continue;
      }

      final nag = _nagTokenPattern.firstMatch(token);
      if (nag != null) {
        if (moves.isNotEmpty) {
          final marker = _annotationFromNag(int.parse(nag.group(1)!));
          if (marker != null) annotations[moves.length - 1] = marker;
        }
        continue;
      }

      final annotationMatch = _annotationSuffix.firstMatch(token);
      final annotation = annotationMatch?.group(0);
      if (annotation != null) {
        token = token.substring(0, token.length - annotation.length);
      }
      if (token.isEmpty) continue;

      final moveIndex = moves.length;
      moves.add(token);
      if (annotation != null) annotations[moveIndex] = annotation;
    }

    return _MovetextResult(
      moves: moves,
      annotations: annotations,
      result: result,
    );
  }

  String _removeSemicolonComments(String input) {
    return input
        .split('\n')
        .map((line) {
          final index = line.indexOf(';');
          return index == -1 ? line : line.substring(0, index);
        })
        .join('\n');
  }

  String _removeBraceComments(String input) {
    final out = StringBuffer();
    var depth = 0;

    for (final rune in input.runes) {
      final char = String.fromCharCode(rune);
      if (char == '{') {
        depth++;
        continue;
      }
      if (char == '}' && depth > 0) {
        depth--;
        continue;
      }
      if (depth == 0) out.write(char);
    }

    return out.toString();
  }

  String _removeVariations(String input) {
    final out = StringBuffer();
    var depth = 0;

    for (final rune in input.runes) {
      final char = String.fromCharCode(rune);
      if (char == '(') {
        depth++;
        continue;
      }
      if (char == ')' && depth > 0) {
        depth--;
        continue;
      }
      if (depth == 0) out.write(char);
    }

    return out.toString();
  }


  static String? _annotationFromNag(int nag) {
    switch (nag) {
      case 1:
        return '!';
      case 2:
        return '?';
      case 3:
        return '!!';
      case 4:
        return '??';
      case 5:
        return '!?';
      case 6:
        return '?!';
      default:
        return null;
    }
  }

  static String _unescapeTag(String value) {
    return value.replaceAll(r'\"', '"').replaceAll(r'\\', '\\');
  }
}

class _MovetextResult {
  final List<String> moves;
  final Map<int, String> annotations;
  final String result;

  const _MovetextResult({
    required this.moves,
    this.annotations = const {},
    required this.result,
  });
}
