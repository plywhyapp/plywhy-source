import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'personal_game_analysis.dart';

enum PersonalReviewGrade { hard, good, easy }

class PersonalReviewItem {
  final String id;
  final String gameLabel;
  final String date;
  final String event;
  final PersonalGameMove move;

  const PersonalReviewItem({
    required this.id,
    required this.gameLabel,
    required this.date,
    required this.event,
    required this.move,
  });

  PgnMistakeSeverity get severity => move.mistakeSeverity!;
}

class PersonalReviewBuilder {
  const PersonalReviewBuilder();

  List<PersonalReviewItem> build(Iterable<PersonalGameAnalysis> analyses) {
    final items = <PersonalReviewItem>[];

    for (final analysis in analyses) {
      if (!analysis.isValid) continue;
      final game = analysis.game;
      for (final move in analysis.annotatedReviewMoves) {
        final sourceKey = [
          game.white,
          game.black,
          game.date,
          game.event,
          move.plyIndex.toString(),
          move.fenBefore,
          move.san,
          move.annotation ?? '',
        ].join('|');

        items.add(
          PersonalReviewItem(
            id: _stableId(sourceKey),
            gameLabel: '${game.white} vs ${game.black}',
            date: game.date,
            event: game.event,
            move: move,
          ),
        );
      }
    }

    items.sort((a, b) {
      final severityCompare = _severityRank(b.severity).compareTo(
        _severityRank(a.severity),
      );
      if (severityCompare != 0) return severityCompare;
      return a.move.plyIndex.compareTo(b.move.plyIndex);
    });

    return List.unmodifiable(items);
  }

  static int _severityRank(PgnMistakeSeverity severity) {
    switch (severity) {
      case PgnMistakeSeverity.blunder:
        return 3;
      case PgnMistakeSeverity.mistake:
        return 2;
      case PgnMistakeSeverity.dubious:
        return 1;
    }
  }

  static String _stableId(String input) {
    int fnv(String value, int seed) {
      var hash = seed & 0xffffffff;
      for (final unit in value.codeUnits) {
        hash ^= unit;
        hash = (hash * 0x01000193) & 0xffffffff;
      }
      return hash;
    }

    final a = fnv(input, 0x811c9dc5);
    final b = fnv(input, 0x9e3779b9);
    return '${a.toRadixString(16).padLeft(8, '0')}${b.toRadixString(16).padLeft(8, '0')}';
  }
}

class PersonalReviewProgress {
  final int repetitions;
  final int intervalDays;
  final DateTime dueAt;

  const PersonalReviewProgress({
    required this.repetitions,
    required this.intervalDays,
    required this.dueAt,
  });

  bool isDue(DateTime now) => !dueAt.isAfter(now);

  Map<String, dynamic> toMap() => {
        'repetitions': repetitions,
        'intervalDays': intervalDays,
        'dueAt': dueAt.toUtc().toIso8601String(),
      };

  factory PersonalReviewProgress.fromMap(Map<String, dynamic> map) {
    return PersonalReviewProgress(
      repetitions: (map['repetitions'] as num?)?.toInt() ?? 0,
      intervalDays: (map['intervalDays'] as num?)?.toInt() ?? 1,
      dueAt: DateTime.parse(map['dueAt'] as String).toUtc(),
    );
  }
}

class PersonalReviewScheduler {
  const PersonalReviewScheduler();

  PersonalReviewProgress next({
    required PersonalReviewProgress? previous,
    required PersonalReviewGrade grade,
    required DateTime now,
  }) {
    final currentRepetitions = previous?.repetitions ?? 0;
    late final int repetitions;
    late final int intervalDays;

    switch (grade) {
      case PersonalReviewGrade.hard:
        repetitions = currentRepetitions > 0 ? currentRepetitions - 1 : 0;
        intervalDays = 1;
        break;
      case PersonalReviewGrade.good:
        repetitions = currentRepetitions + 1;
        intervalDays = _goodInterval(repetitions);
        break;
      case PersonalReviewGrade.easy:
        repetitions = currentRepetitions + 1;
        intervalDays = _easyInterval(repetitions);
        break;
    }

    final base = now.toUtc();
    return PersonalReviewProgress(
      repetitions: repetitions,
      intervalDays: intervalDays,
      dueAt: base.add(Duration(days: intervalDays)),
    );
  }

  int _goodInterval(int repetitions) {
    const intervals = [1, 3, 7, 14, 30, 60];
    final index = repetitions - 1;
    return intervals[index < intervals.length ? index : intervals.length - 1];
  }

  int _easyInterval(int repetitions) {
    const intervals = [3, 7, 14, 30, 60, 90];
    final index = repetitions - 1;
    return intervals[index < intervals.length ? index : intervals.length - 1];
  }
}

class PersonalReviewStore {
  static const _key = 'personalReviewProgressV1';

  Future<Map<String, PersonalReviewProgress>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return <String, PersonalReviewProgress>{};

    try {
      final decoded = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final result = <String, PersonalReviewProgress>{};
      for (final entry in decoded.entries) {
        final value = entry.value;
        if (value is Map) {
          result[entry.key] = PersonalReviewProgress.fromMap(
            Map<String, dynamic>.from(value),
          );
        }
      }
      return result;
    } catch (_) {
      return <String, PersonalReviewProgress>{};
    }
  }

  Future<void> save(
    String itemId,
    PersonalReviewProgress progress,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final all = await load();
    all[itemId] = progress;
    await prefs.setString(
      _key,
      jsonEncode({
        for (final entry in all.entries) entry.key: entry.value.toMap(),
      }),
    );
  }
}
