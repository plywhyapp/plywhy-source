import 'package:chess/chess.dart' as chess;

import 'engine_api.dart';
import 'engine_explanation.dart';
import 'fen_utils.dart';
import 'personal_game_analysis.dart';
import 'pgn_parser.dart';

/// Legal moves and observable consequences; never substitutes a heuristic for
/// an engine evaluation. The saved reply belongs ONLY to the original mistake.
class PatternPractice {
  final String fenBefore;
  final String savedMoveUci;
  final String originalSan;
  late final List<Map<String, dynamic>> legalMoves;

  PatternPractice({
    required this.fenBefore,
    required this.savedMoveUci,
    required this.originalSan,
  }) {
    if (!isFenStructurallyValid(fenBefore)) {
      throw const FormatException('The saved position is invalid.');
    }
    legalMoves = _moves(chess.Chess.fromFEN(fenBefore));
  }

  // chess 0.8.1 verbose maps omit promotion and return PieceType for captures.
  // Use typed moves so underpromotions and captured-piece names remain exact.
  static List<Map<String, dynamic>> _moves(chess.Chess board) => board
      .moves({'asObjects': true})
      .cast<chess.Move>()
      .map(
        (move) => {
          'from': move.fromAlgebraic,
          'to': move.toAlgebraic,
          'san': board.move_to_san(move),
          'promotion': move.promotion?.name,
          'captured': move.captured?.name,
        },
      )
      .toList(growable: false);

  static String uciOf(Map<String, dynamic> move) =>
      '${move['from']}${move['to']}${move['promotion'] ?? ''}';

  Set<String> destinations(String from) => {
    for (final move in legalMoves)
      if (move['from'] == from) move['to'] as String,
  };

  PracticeAttempt play(String uci) {
    final matching = legalMoves.where((move) => uciOf(move) == uci);
    if (matching.isEmpty) {
      throw const FormatException('Choose a legal highlighted destination.');
    }
    final move = matching.first;
    final board = chess.Chess.fromFEN(fenBefore);
    if (!board.move(move)) {
      throw const FormatException('This move is not legal.');
    }
    final san = move['san'] as String;
    final replies = _moves(board);
    final forcing = replies.where((reply) {
      final replySan = reply['san'] as String;
      return reply['captured'] != null ||
          replySan.contains('+') ||
          replySan.contains('#');
    }).toList();
    forcing.sort((a, b) => _priority(b).compareTo(_priority(a)));
    final facts = <String>[];
    if (san.contains('#')) {
      facts.add(
        'Your move delivers checkmate. The opponent has no legal escape.',
      );
    } else if (replies.isEmpty) {
      facts.add(
        'Your move produces stalemate: no legal move and no check. The game is drawn.',
      );
    } else {
      if (san.contains('+')) {
        facts.add('Your move gives check, so the opponent must answer it.');
      }
      if (move['captured'] != null) {
        facts.add(
          'You capture a ${_pieceName(move['captured'] as String)}. '
          'Check the reply before deciding whether the exchange helps you.',
        );
      }
      if (forcing.isNotEmpty) {
        final examples = forcing
            .take(3)
            .map(
              (reply) =>
                  '${reply['san']} (${humanizeUciMove(board.fen, uciOf(reply))})',
            )
            .join(', ');
        facts.add(
          'The opponent has these legal checks or captures: $examples. '
          'They are candidates to examine, not proof that your move loses.',
        );
      } else {
        facts.add(
          'The opponent has no immediate legal check or capture. '
          'That alone does not establish that your move is good; look for their next threat.',
        );
      }
    }
    return PracticeAttempt(
      uci: uci,
      san: san,
      fenAfter: board.fen,
      matchesSavedMove: uci == savedMoveUci,
      repeatsOriginalMove: san == originalSan,
      facts: List.unmodifiable(facts),
    );
  }

  /// Reconstructs only a legal reply from this attempt's actual position.
  static String? afterReply(PracticeAttempt attempt, String? uci) {
    if (uci == null ||
        !RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(uci)) {
      return null;
    }
    final board = chess.Chess.fromFEN(attempt.fenAfter);
    if (!board.move({
      'from': uci.substring(0, 2),
      'to': uci.substring(2, 4),
      if (uci.length == 5) 'promotion': uci[4],
    })) {
      return null;
    }
    return board.fen;
  }

  PersonalGameMove contextFor(PracticeAttempt attempt) {
    final fields = fenBefore.split(RegExp(r'\s+'));
    final white = fields[1] == 'w';
    return PersonalGameMove(
      plyIndex: white ? 0 : 1,
      moveNumber: int.parse(fields[5]),
      isWhiteMove: white,
      san: attempt.san,
      annotation: null,
      fenBefore: fenBefore,
      fenAfter: attempt.fenAfter,
    );
  }

  Future<EngineMoveResult> analyze(
    PracticeAttempt attempt,
    EngineApiClient client,
  ) async {
    final context = contextFor(attempt);
    final result = await client.analyzeGame(
      PersonalGameAnalysis(
        game: ParsedPgnGame(
          headers: {
            'FEN': fenBefore,
            'SetUp': '1',
            'Event': 'Pattern Card practice',
          },
          sanMoves: [attempt.san],
          result: '*',
        ),
        moves: [context],
      ),
    );
    final matches = result.moves.where(
      (move) => move.plyIndex == context.plyIndex && move.san == attempt.san,
    );
    if (matches.length != 1) {
      throw const EngineApiException('No matching evaluation was returned.');
    }
    final evaluated = matches.single;
    if (!legalMoves.any((move) => uciOf(move) == evaluated.bestMoveUci)) {
      throw const EngineApiException(
        'The engine returned an invalid recommended move.',
      );
    }
    final reply = evaluated.opponentBestReplyUci;
    if (reply != null &&
        reply.isNotEmpty &&
        afterReply(attempt, reply) == null) {
      throw const EngineApiException('The engine returned an illegal reply.');
    }
    return evaluated;
  }

  static int _priority(Map<String, dynamic> move) {
    final san = move['san'] as String;
    if (san.contains('#')) return 100;
    if (san.contains('+')) return 20;
    return const {'q': 9, 'r': 5, 'b': 3, 'n': 3, 'p': 1}[move['captured']] ??
        0;
  }

  static String _pieceName(String piece) =>
      const {
        'p': 'pawn',
        'n': 'knight',
        'b': 'bishop',
        'r': 'rook',
        'q': 'queen',
        'k': 'king',
      }[piece] ??
      'piece';
}

class PracticeAttempt {
  final String uci;
  final String san;
  final String fenAfter;
  final bool matchesSavedMove;
  final bool repeatsOriginalMove;
  final List<String> facts;

  const PracticeAttempt({
    required this.uci,
    required this.san,
    required this.fenAfter,
    required this.matchesSavedMove,
    required this.repeatsOriginalMove,
    required this.facts,
  });
}
