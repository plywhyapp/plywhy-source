import 'dart:math';

import 'models.dart';
import 'profile_logic.dart';

int targetDifficultyForScore(int score) {
  final normalized = score.clamp(0, 100);
  if (normalized <= 34) return 1;
  if (normalized <= 69) return 2;
  return 3;
}

List<Exercise> buildAdaptiveSession({
  required Map<Skill, int> scores,
  required List<Exercise> exerciseBank,
  List<String> recentExerciseIds = const [],
  int sessionSize = 10,
  Random? random,
}) {
  if (exerciseBank.isEmpty || sessionSize <= 0) return const [];

  final rng = random ?? Random();
  final rankedSkills = rankSkillsWeakestFirst(scores);
  final weakest = rankedSkills[0];
  final secondWeakest = rankedSkills[1];
  final recentSet = recentExerciseIds.toSet();
  final selected = <Exercise>[];
  final selectedIds = <String>{};

  List<Exercise> candidatesForSkill(Skill skill) {
    final targetDifficulty = targetDifficultyForScore(scores[skill] ?? 0);
    final candidates = exerciseBank.where((e) => e.skill == skill).toList()
      ..shuffle(rng);

    candidates.sort((a, b) {
      final aRecent = recentSet.contains(a.id) ? 1 : 0;
      final bRecent = recentSet.contains(b.id) ? 1 : 0;
      final recentCompare = aRecent.compareTo(bRecent);
      if (recentCompare != 0) return recentCompare;

      final aDistance = (a.difficulty - targetDifficulty).abs();
      final bDistance = (b.difficulty - targetDifficulty).abs();
      return aDistance.compareTo(bDistance);
    });

    return candidates;
  }

  void addFrom(List<Exercise> candidates, int count) {
    var remaining = count;
    for (final exercise in candidates) {
      if (selected.length >= sessionSize || remaining <= 0) break;
      if (selectedIds.add(exercise.id)) {
        selected.add(exercise);
        remaining--;
      }
    }
  }

  final desiredWeakest = min(4, sessionSize);
  final desiredSecond = min(3, max(0, sessionSize - desiredWeakest));

  addFrom(candidatesForSkill(weakest), desiredWeakest);
  addFrom(candidatesForSkill(secondWeakest), desiredSecond);

  // Spread the remaining questions across the other skills so a normal
  // 10-question session still samples the entire thinking profile.
  final otherSkills = rankedSkills.skip(2).toList();
  var mixedIndex = 0;
  var attemptsWithoutAdd = 0;
  while (selected.length < sessionSize && otherSkills.isNotEmpty) {
    final skill = otherSkills[mixedIndex % otherSkills.length];
    final before = selected.length;
    addFrom(candidatesForSkill(skill), 1);
    mixedIndex++;

    if (selected.length == before) {
      attemptsWithoutAdd++;
      if (attemptsWithoutAdd >= otherSkills.length) break;
    } else {
      attemptsWithoutAdd = 0;
    }
  }

  if (selected.length < sessionSize) {
    final fallback = exerciseBank.where((e) => !selectedIds.contains(e.id)).toList()
      ..shuffle(rng);

    fallback.sort((a, b) {
      final aRecent = recentSet.contains(a.id) ? 1 : 0;
      final bRecent = recentSet.contains(b.id) ? 1 : 0;
      final recentCompare = aRecent.compareTo(bRecent);
      if (recentCompare != 0) return recentCompare;

      final aTarget = targetDifficultyForScore(scores[a.skill] ?? 0);
      final bTarget = targetDifficultyForScore(scores[b.skill] ?? 0);
      final aDistance = (a.difficulty - aTarget).abs();
      final bDistance = (b.difficulty - bTarget).abs();
      return aDistance.compareTo(bDistance);
    });

    addFrom(fallback, sessionSize - selected.length);
  }

  selected.shuffle(rng);
  return selected;
}
