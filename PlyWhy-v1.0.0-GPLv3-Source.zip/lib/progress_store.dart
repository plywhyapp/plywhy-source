import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class ProgressStore {
  static const _assessmentCompletedKey = 'assessmentCompleted';
  static const _sessionsCompletedKey = 'sessionsCompleted';
  static const _streakKey = 'streak';
  static const _lastTrainingAccuracyKey = 'lastTrainingAccuracy';
  static const _lastTrainingDateKey = 'lastTrainingDate';
  static const _historyKey = 'sessionHistoryV2';
  static const _recentExerciseIdsKey = 'recentExerciseIdsV2';
  static const _xpKey = 'xpV1';
  static const _mistakeCountsKey = 'mistakeCountsV1';
  static const _highConfidenceAttemptsKey = 'highConfidenceAttemptsV1';
  static const _highConfidenceMistakesKey = 'highConfidenceMistakesV1';
  static const _survivalBestKey = 'survivalBestV1';
  static const _blunderPatternCountsKey = 'blunderPatternCountsV1';

  String _skillKey(Skill skill) => 'skill_${skill.name}';

  Future<AppProgress> load() async {
    final prefs = await SharedPreferences.getInstance();

    final scores = <Skill, int>{
      for (final skill in Skill.values) skill: prefs.getInt(_skillKey(skill)) ?? 0,
    };

    final historyJson = prefs.getString(_historyKey);
    final history = <SessionRecord>[];

    if (historyJson != null && historyJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(historyJson) as List<dynamic>;
        for (final item in decoded) {
          history.add(
            SessionRecord.fromMap(Map<String, dynamic>.from(item as Map)),
          );
        }
      } catch (_) {
        // Preserve legacy progress even if history data is malformed.
      }
    }

    final mistakes = <Skill, int>{for (final skill in Skill.values) skill: 0};
    final mistakesJson = prefs.getString(_mistakeCountsKey);
    if (mistakesJson != null && mistakesJson.isNotEmpty) {
      try {
        final decoded = Map<String, dynamic>.from(jsonDecode(mistakesJson) as Map);
        for (final skill in Skill.values) {
          mistakes[skill] = (decoded[skill.name] as num?)?.toInt() ?? 0;
        }
      } catch (_) {
        // Newer diagnostics should never make legacy progress unloadable.
      }
    }


    final patternCounts = <String, int>{};
    final patternJson = prefs.getString(_blunderPatternCountsKey);
    if (patternJson != null && patternJson.isNotEmpty) {
      try {
        final decoded = Map<String, dynamic>.from(jsonDecode(patternJson) as Map);
        for (final entry in decoded.entries) {
          patternCounts[entry.key] = (entry.value as num?)?.toInt() ?? 0;
        }
      } catch (_) {
        // Pattern diagnostics are optional and must not block loading.
      }
    }

    return AppProgress(
      assessmentCompleted: prefs.getBool(_assessmentCompletedKey) ?? false,
      skillScores: scores,
      sessionsCompleted: prefs.getInt(_sessionsCompletedKey) ?? 0,
      streak: prefs.getInt(_streakKey) ?? 0,
      lastTrainingAccuracy: prefs.getInt(_lastTrainingAccuracyKey),
      lastTrainingDate: prefs.getString(_lastTrainingDateKey),
      history: history,
      recentExerciseIds: prefs.getStringList(_recentExerciseIdsKey) ?? const [],
      xp: prefs.getInt(_xpKey) ??
          history.where((record) => record.kind != SessionKind.assessment).length * 50,
      mistakeCounts: mistakes,
      highConfidenceAttempts: prefs.getInt(_highConfidenceAttemptsKey) ?? 0,
      highConfidenceMistakes: prefs.getInt(_highConfidenceMistakesKey) ?? 0,
      survivalBest: prefs.getInt(_survivalBestKey) ?? 0,
      blunderPatternCounts: patternCounts,
    );
  }

  Future<void> save(AppProgress progress) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_assessmentCompletedKey, progress.assessmentCompleted);
    await prefs.setInt(_sessionsCompletedKey, progress.sessionsCompleted);
    await prefs.setInt(_streakKey, progress.streak);
    await prefs.setInt(_xpKey, progress.xp);
    await prefs.setInt(
      _highConfidenceAttemptsKey,
      progress.highConfidenceAttempts,
    );
    await prefs.setInt(
      _highConfidenceMistakesKey,
      progress.highConfidenceMistakes,
    );
    await prefs.setInt(_survivalBestKey, progress.survivalBest);

    if (progress.lastTrainingAccuracy == null) {
      await prefs.remove(_lastTrainingAccuracyKey);
    } else {
      await prefs.setInt(
        _lastTrainingAccuracyKey,
        progress.lastTrainingAccuracy!,
      );
    }

    if (progress.lastTrainingDate == null) {
      await prefs.remove(_lastTrainingDateKey);
    } else {
      await prefs.setString(_lastTrainingDateKey, progress.lastTrainingDate!);
    }

    for (final skill in Skill.values) {
      await prefs.setInt(_skillKey(skill), progress.skillScores[skill] ?? 0);
    }

    await prefs.setString(
      _historyKey,
      jsonEncode(progress.history.map((record) => record.toMap()).toList()),
    );

    await prefs.setStringList(_recentExerciseIdsKey, progress.recentExerciseIds);

    await prefs.setString(
      _mistakeCountsKey,
      jsonEncode({
        for (final skill in Skill.values)
          skill.name: progress.mistakeCounts[skill] ?? 0,
      }),
    );


    await prefs.setString(
      _blunderPatternCountsKey,
      jsonEncode(progress.blunderPatternCounts),
    );
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.remove(_assessmentCompletedKey);
    await prefs.remove(_sessionsCompletedKey);
    await prefs.remove(_streakKey);
    await prefs.remove(_lastTrainingAccuracyKey);
    await prefs.remove(_lastTrainingDateKey);
    await prefs.remove(_historyKey);
    await prefs.remove(_recentExerciseIdsKey);
    await prefs.remove(_xpKey);
    await prefs.remove(_mistakeCountsKey);
    await prefs.remove(_highConfidenceAttemptsKey);
    await prefs.remove(_highConfidenceMistakesKey);
    await prefs.remove(_survivalBestKey);
    await prefs.remove(_blunderPatternCountsKey);

    for (final skill in Skill.values) {
      await prefs.remove(_skillKey(skill));
    }
  }
}
