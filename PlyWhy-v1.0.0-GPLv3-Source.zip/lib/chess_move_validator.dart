import 'package:chess/chess.dart' as chess_lib;

enum MoveMatchStatus {
  exactMatch,      // Both moves represent the exact same legal move and board state
  differentMoves,  // Both moves are legal, but they are different moves
  invalidFen,      // The FEN position is invalid or unparseable
  invalidMove,     // One or both moves are illegal in the given FEN
}

class MoveValidationResult {
  final MoveMatchStatus status;
  final String fenBefore;
  final String? playedUci;
  final String? playedSan;
  final String? targetUci;
  final String? targetSan;
  final String? fenAfterPlayed;
  final String? fenAfterTarget;
  final String? detail;

  const MoveValidationResult({
    required this.status,
    required this.fenBefore,
    this.playedUci,
    this.playedSan,
    this.targetUci,
    this.targetSan,
    this.fenAfterPlayed,
    this.fenAfterTarget,
    this.detail,
  });

  bool get isExactMatch => status == MoveMatchStatus.exactMatch;
  bool get isDifferentMoves => status == MoveMatchStatus.differentMoves;
  bool get isValid => isExactMatch || isDifferentMoves;

  @override
  String toString() {
    return 'MoveValidationResult(status: $status, played: $playedSan ($playedUci), target: $targetSan ($targetUci), detail: $detail)';
  }
}

class ChessMoveValidator {
  const ChessMoveValidator();

  /// Validates whether [playedInput] and [targetInput] (each can be SAN or UCI)
  /// represent the EXACT same legal move in [fenBefore].
  ///
  /// Performs full legal conversion, attribute checking (from, to, promotion),
  /// and resulting FEN verification (preserving turn, castling rights, and en passant).
  MoveValidationResult validate({
    required String fenBefore,
    required String playedInput,
    required String targetInput,
  }) {
    // 1. Strict FEN Validation using chess.dart
    final fenCheck = chess_lib.Chess.validate_fen(fenBefore);
    if (fenCheck['valid'] != true) {
      return MoveValidationResult(
        status: MoveMatchStatus.invalidFen,
        fenBefore: fenBefore,
        detail: 'Invalid FEN position: ${fenCheck['error'] ?? 'unparseable FEN'}',
      );
    }

    chess_lib.Chess game;
    try {
      game = chess_lib.Chess.fromFEN(fenBefore);
    } catch (e) {
      return MoveValidationResult(
        status: MoveMatchStatus.invalidFen,
        fenBefore: fenBefore,
        detail: 'Failed to initialize board from FEN: $e',
      );
    }

    final playedResolved = _resolveMove(game, fenBefore, playedInput);
    if (playedResolved == null) {
      return MoveValidationResult(
        status: MoveMatchStatus.invalidMove,
        fenBefore: fenBefore,
        detail: 'Played move "$playedInput" is illegal or invalid in FEN.',
      );
    }

    final targetResolved = _resolveMove(game, fenBefore, targetInput);
    if (targetResolved == null) {
      return MoveValidationResult(
        status: MoveMatchStatus.invalidMove,
        fenBefore: fenBefore,
        playedUci: playedResolved.uci,
        playedSan: playedResolved.san,
        fenAfterPlayed: playedResolved.fenAfter,
        detail: 'Target move "$targetInput" is illegal or invalid in FEN.',
      );
    }

    // Attribute comparison: source square, destination square, promotion
    final sameFrom = playedResolved.from == targetResolved.from;
    final sameTo = playedResolved.to == targetResolved.to;
    final samePromotion = playedResolved.promotion == targetResolved.promotion;
    final sameFenAfter = playedResolved.fenAfter == targetResolved.fenAfter;

    final isMatch = sameFrom && sameTo && samePromotion && sameFenAfter;

    return MoveValidationResult(
      status: isMatch ? MoveMatchStatus.exactMatch : MoveMatchStatus.differentMoves,
      fenBefore: fenBefore,
      playedUci: playedResolved.uci,
      playedSan: playedResolved.san,
      targetUci: targetResolved.uci,
      targetSan: targetResolved.san,
      fenAfterPlayed: playedResolved.fenAfter,
      fenAfterTarget: targetResolved.fenAfter,
      detail: isMatch
          ? 'Exact match verified.'
          : 'Different moves: played ${playedResolved.san} (${playedResolved.uci}) vs target ${targetResolved.san} (${targetResolved.uci}).',
    );
  }

  _ResolvedMove? _resolveMove(
    chess_lib.Chess game,
    String fenBefore,
    String input,
  ) {
    final rawInput = input.trim();
    if (rawInput.isEmpty) return null;

    final cleanInput = rawInput
        .replaceAll('+', '')
        .replaceAll('#', '')
        .replaceAll('!', '')
        .replaceAll('?', '')
        .replaceAll('=', '')
        .trim();

    final legalMoves = game.moves({'verbose': true});

    for (final move in legalMoves) {
      final from = move['from']?.toString() ?? '';
      final to = move['to']?.toString() ?? '';
      final promotion = _extractPromotionFromMove(move);
      final uci = '$from$to$promotion';

      final moveSan = (move['san']?.toString() ?? '')
          .replaceAll('+', '')
          .replaceAll('#', '')
          .replaceAll('!', '')
          .replaceAll('?', '')
          .replaceAll('=', '')
          .trim();

      // 1. Direct UCI match
      if (uci.toLowerCase() == cleanInput.toLowerCase()) {
        final fenAfter = _computeFenAfter(fenBefore, from, to, promotion);
        if (fenAfter == null) return null;
        return _ResolvedMove(
          from: from,
          to: to,
          promotion: promotion.isEmpty ? null : promotion,
          uci: uci,
          san: move['san']?.toString() ?? rawInput,
          fenAfter: fenAfter,
        );
      }

      // 2. Direct SAN match
      if (moveSan.toLowerCase() == cleanInput.toLowerCase()) {
        final fenAfter = _computeFenAfter(fenBefore, from, to, promotion);
        if (fenAfter == null) return null;
        return _ResolvedMove(
          from: from,
          to: to,
          promotion: promotion.isEmpty ? null : promotion,
          uci: uci,
          san: move['san']?.toString() ?? rawInput,
          fenAfter: fenAfter,
        );
      }

      // 3. Disambiguated SAN & Promotion match
      final piece = (move['piece']?.toString() ?? '').toUpperCase();
      final isPawn = piece == 'P' || piece.isEmpty;
      final piecePrefix = isPawn ? '' : piece;
      final fullSan = '$piecePrefix$from$to';
      final fileSan = '$piecePrefix${from[0]}$to';
      final rankSan = '$piecePrefix${from[1]}$to';
      final captureFullSan = '$piecePrefix${from}x$to';
      final captureFileSan = '$piecePrefix${from[0]}x$to';
      final captureRankSan = '$piecePrefix${from[1]}x$to';
      final pawnPromSan = '$to$promotion';
      final pawnPromFileSan = '${from[0]}x$to$promotion';

      final candidates = [
        fullSan,
        fileSan,
        rankSan,
        captureFullSan,
        captureFileSan,
        captureRankSan,
        if (promotion.isNotEmpty) pawnPromSan,
        if (promotion.isNotEmpty) pawnPromFileSan,
      ].map((s) => s.toLowerCase()).toSet();

      if (candidates.contains(cleanInput.toLowerCase())) {
        final fenAfter = _computeFenAfter(fenBefore, from, to, promotion);
        if (fenAfter == null) return null;
        return _ResolvedMove(
          from: from,
          to: to,
          promotion: promotion.isEmpty ? null : promotion,
          uci: uci,
          san: move['san']?.toString() ?? rawInput,
          fenAfter: fenAfter,
        );
      }
    }

    // 4. Fallback: try clone.move()
    try {
      final clone = chess_lib.Chess.fromFEN(fenBefore);
      final moveSuccess = clone.move(rawInput);
      if (moveSuccess) {
        final history = clone.history.last;
        final from = history.move.fromAlgebraic;
        final to = history.move.toAlgebraic;
        final promotionPiece = history.move.promotion;
        final promotion = promotionPiece == null ? '' : promotionPiece.name.toLowerCase();
        final uci = '$from$to$promotion';
        final fenAfter = clone.generate_fen();

        return _ResolvedMove(
          from: from,
          to: to,
          promotion: promotion.isEmpty ? null : promotion,
          uci: uci,
          san: rawInput,
          fenAfter: fenAfter,
        );
      }
    } catch (_) {}

    return null;
  }

  static String _extractPromotionFromMove(Map<dynamic, dynamic> move) {
    final rawProm = move['promotion'];
    if (rawProm != null) {
      if (rawProm is chess_lib.PieceType) return rawProm.name.toLowerCase();
      final str = rawProm.toString().toLowerCase();
      if (str.length == 1) return str;
      if (str.contains('.')) return str.split('.').last.toLowerCase();
    }
    final san = move['san']?.toString() ?? '';
    final eqIndex = san.indexOf('=');
    if (eqIndex != -1 && eqIndex + 1 < san.length) {
      return san[eqIndex + 1].toLowerCase();
    }
    return '';
  }

  String? _computeFenAfter(
    String fenBefore,
    String from,
    String to,
    String promotion,
  ) {
    try {
      final clone = chess_lib.Chess.fromFEN(fenBefore);
      final moveMap = <String, String>{'from': from, 'to': to};
      if (promotion.isNotEmpty) moveMap['promotion'] = promotion;
      if (clone.move(moveMap)) {
        return clone.generate_fen();
      }
    } catch (_) {}
    return null;
  }
}

class _ResolvedMove {
  final String from;
  final String to;
  final String? promotion;
  final String uci;
  final String san;
  final String fenAfter;

  const _ResolvedMove({
    required this.from,
    required this.to,
    this.promotion,
    required this.uci,
    required this.san,
    required this.fenAfter,
  });
}
