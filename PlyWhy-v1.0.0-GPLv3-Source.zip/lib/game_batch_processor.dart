import 'package:flutter/foundation.dart';

import 'game_platform_import.dart';
import 'personal_game_analysis.dart';
import 'pgn_parser.dart';

/// CPU-heavy PGN parsing and position reconstruction must not run on the
/// Android UI isolate. This public entry point is used by My Games for both
/// automatic sync (Chess.com/Lichess) and manual imports.
Future<List<PersonalGameAnalysis>> reconstructPgnOffMainThread(String pgn) {
  return compute(_parseAndReconstruct, pgn, debugLabel: 'ChessSense PGN import');
}

// A top-level function keeps the isolate entry point independent of widgets,
// controllers, transports, and BuildContext.
List<PersonalGameAnalysis> _parseAndReconstruct(String pgn) {
  final games = PgnParser().parse(pgn)
      .where((game) => game.sanMoves.isNotEmpty)
      .toList(growable: false);

  if (games.isEmpty) {
    throw const GamePlatformImportException(
      'No playable PGN moves were found in the imported games.',
    );
  }

  const analyzer = PersonalGameAnalyzer();
  return List<PersonalGameAnalysis>.unmodifiable([
    for (final game in games) analyzer.analyze(game),
  ]);
}
