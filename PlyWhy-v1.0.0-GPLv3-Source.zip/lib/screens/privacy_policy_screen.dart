import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Privacy Policy for ChessSense',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Pre-Release Draft · Subject to final URL',
              style: TextStyle(color: Color(0xFFEFC888), fontSize: 13, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              '1. Data Collection and Usage\n'
              'ChessSense is designed with privacy in mind. We do not require account registration, and we do not collect personal identifiers, email addresses, or phone numbers.\n\n'
              '2. Public Game Synchronization\n'
              'When you use the "My Games" feature to sync public chess games, the app sends HTTPS requests directly to public Lichess (https://lichess.org) and Chess.com (https://api.chess.com) endpoints using the public username provided. No account passwords or private tokens are requested or stored.\n\n'
              '3. Local On-Device Processing and Storage\n'
              'All chess analysis, blunder detection, and training progress metrics are processed and stored locally on your device using an embedded native Stockfish engine without sending game data to external servers.\n\n'
              '4. Data Deletion\n'
              'All synced games and profile statistics are stored locally on your device. You can clear application data at any time via Android System Settings -> Apps -> ChessSense -> Storage -> Clear Data.\n\n'
              '5. Contact Information\n'
              'Developer contact details and hosted policy URL will be finalized prior to public release.',
              style: TextStyle(fontSize: 14, height: 1.5, color: Color(0xFFF3F6F3)),
            ),
          ],
        ),
      ),
    );
  }
}
