import 'package:flutter/material.dart';
import 'package:chess/chess.dart' as chess;

import '../content_repository.dart';
import '../engine_api.dart';
import '../engine_explanation.dart';
import '../fen_utils.dart';
import '../pattern_cards.dart';
import '../pattern_transfer.dart';
import '../personal_game_analysis.dart';
import '../pgn_parser.dart';
import '../widgets/interactive_chessboard.dart';

class PatternTransferScreen extends StatefulWidget {
  final PatternCard card;
  final ContentPack pack;
  final EngineApiClient apiClient;
  final VoidCallback onCompleted;
  final Function(int successes, int attempts) onResults;

  const PatternTransferScreen({
    super.key,
    required this.card,
    required this.pack,
    required this.apiClient,
    required this.onCompleted,
    required this.onResults,
  });

  @override
  State<PatternTransferScreen> createState() => _PatternTransferScreenState();
}

class _PatternTransferScreenState extends State<PatternTransferScreen> {
  late List<ContentPuzzle> _puzzles;
  int _index = 0;

  int _successes = 0;
  int _attempts = 0;

  bool _loadingEngine = false;
  String? _error;
  
  String? _selectedSquare;
  EngineMoveResult? _evalResult;
  EngineMoveExplanation? _explanation;

  @override
  void initState() {
    super.initState();
    _puzzles = selectPatternTransferPuzzles(
      widget.pack.puzzles,
      lessonTitle: widget.card.lessonTitle,
      count: 2,
    );
    if (_puzzles.isEmpty) {
      // No puzzles found, immediately return
      WidgetsBinding.instance.addPostFrameCallback((_) {
        widget.onResults(0, 0);
        widget.onCompleted();
      });
    }
  }

  Future<void> _handleMove(String uci) async {
    if (_loadingEngine || _evalResult != null) return;
    final puzzle = _puzzles[_index];

    final boardEngine = chess.Chess.fromFEN(puzzle.fen);
    final oppMove = puzzle.moveList[0];
    boardEngine.move({
      'from': oppMove.substring(0, 2), 
      'to': oppMove.substring(2, 4), 
      if (oppMove.length == 5) 'promotion': oppMove[4]
    });
    
    final fenBeforeUser = boardEngine.fen;
    
    final userMoveList = boardEngine.moves({'asObjects': true}).cast<chess.Move>();
    final matching = userMoveList.where((m) => '${m.fromAlgebraic}${m.toAlgebraic}${m.promotion?.name ?? ''}' == uci).toList();
    if (matching.isEmpty) return; // Illegal

    final isWhiteMove = boardEngine.turn == chess.Color.WHITE;
    final userMove = matching.first;
    final playedSan = boardEngine.move_to_san(userMove);

    boardEngine.move(userMove);
    final fenAfterUser = boardEngine.fen;

    setState(() {
      _loadingEngine = true;
      _error = null;
    });

    try {
      final moveContext = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: isWhiteMove,
        san: playedSan,
        annotation: null,
        fenBefore: fenBeforeUser,
        fenAfter: fenAfterUser,
      );

      final result = await widget.apiClient.analyzeGame(
        PersonalGameAnalysis(
          game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '*'),
          moves: [moveContext],
        ),
      );

      if (!mounted) return;

      final evalResult = result.moves.first;
      final isGood = evalResult.lossCp < 80 ||
          evalResult.quality == EngineMoveQuality.best ||
          evalResult.quality == EngineMoveQuality.excellent ||
          evalResult.quality == EngineMoveQuality.good;
      
      EngineMoveExplanation? explanation;
      if (!isGood) {
        explanation = buildEngineMoveExplanation(evalResult, moveContext);
      }

      setState(() {
        _loadingEngine = false;
        _evalResult = evalResult;
        _explanation = explanation;
        _attempts++;
        if (isGood) _successes++;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadingEngine = false;
        _error = error.toString();
      });
    }
  }

  void _handleSquareTap(String square) async {
    if (_loadingEngine || _evalResult != null) return;
    
    final puzzle = _puzzles[_index];
    final boardEngine = chess.Chess.fromFEN(puzzle.fen);
    final oppMove = puzzle.moveList[0];
    boardEngine.move({'from': oppMove.substring(0, 2), 'to': oppMove.substring(2, 4), if (oppMove.length == 5) 'promotion': oppMove[4]});
    
    if (_selectedSquare == square) {
      setState(() => _selectedSquare = null);
      return;
    }

    final userMoveList = boardEngine.moves({'asObjects': true}).cast<chess.Move>();
    final candidates = userMoveList.where((m) => m.fromAlgebraic == _selectedSquare && m.toAlgebraic == square).toList();
    
    if (candidates.isEmpty) {
      // Check if selected square has valid moves
      final hasMoves = userMoveList.any((m) => m.fromAlgebraic == square);
      if (hasMoves) {
        setState(() => _selectedSquare = square);
      }
      return;
    }
    
    var move = candidates.first;
    if (candidates.length > 1) {
      final promotion = await showDialog<String>(
        context: context,
        builder: (context) => SimpleDialog(
          title: const Text('Promote to'),
          children: [
            for (final entry in const {
              'q': 'Queen',
              'r': 'Rook',
              'b': 'Bishop',
              'n': 'Knight',
            }.entries)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(context, entry.key),
                child: Text(entry.value),
              ),
          ],
        ),
      );
      if (promotion == null) return;
      move = candidates.firstWhere((m) => m.promotion?.name == promotion);
    }
    
    final uci = '${move.fromAlgebraic}${move.toAlgebraic}${move.promotion?.name ?? ''}';
    _handleMove(uci);
  }

  void _next() {
    if (_index + 1 < _puzzles.length) {
      setState(() {
        _index++;
        _evalResult = null;
        _explanation = null;
        _selectedSquare = null;
        _error = null;
      });
    } else {
      widget.onResults(_successes, _attempts);
      widget.onCompleted();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_puzzles.isEmpty) return const SizedBox.shrink();

    final puzzle = _puzzles[_index];
    final boardEngine = chess.Chess.fromFEN(puzzle.fen);
    final oppMove = puzzle.moveList[0];
    boardEngine.move({'from': oppMove.substring(0, 2), 'to': oppMove.substring(2, 4), if (oppMove.length == 5) 'promotion': oppMove[4]});
    
    final activeFen = boardEngine.fen;
    final isWhiteTurn = boardEngine.turn == chess.Color.WHITE;

    return Scaffold(
      appBar: AppBar(title: const Text('Pattern Transfer')),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Apply: ${widget.card.lessonTitle}',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Position ${_index + 1} of ${_puzzles.length} · Find a move that respects the pattern.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                AspectRatio(
                  aspectRatio: 1.0,
                  child: InteractiveChessBoard(
                    board: parseFenBoard(activeFen),
                    flipped: !isWhiteTurn,
                    onSquareTap: _evalResult == null ? _handleSquareTap : null,
                    selectedFrom: _selectedSquare,
                    destinationSquares: _selectedSquare == null ? {} : boardEngine.moves({'asObjects': true}).cast<chess.Move>().where((m) => m.fromAlgebraic == _selectedSquare).map((m) => m.toAlgebraic).toSet(),
                    accentSquares: const {},
                    arrows: const [],
                  ),
                ),
                const SizedBox(height: 16),
                if (_loadingEngine)
                  const Center(child: CircularProgressIndicator())
                else if (_error != null)
                  Text(
                    'Engine error: $_error',
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  )
                else if (_evalResult != null) ...[
                  if (_explanation == null) ...[
                    Card(
                      color: Colors.green.shade100,
                      child: const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Excellent move! You successfully applied the pattern here.',
                          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ] else ...[
                    Card(
                      color: Colors.red.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Incorrect',
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.error,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(_explanation!.whatFailed),
                            const SizedBox(height: 8),
                            Text(_explanation!.betterChoice),
                          ],
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _next,
                    child: const Text('Continue'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
