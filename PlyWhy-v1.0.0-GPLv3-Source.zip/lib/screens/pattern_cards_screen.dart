import 'package:flutter/material.dart';

import '../content_repository.dart';
import '../engine_api.dart';
import '../engine_config.dart';
import '../pattern_cards.dart';
import '../widgets/pattern_practice_card.dart';
import 'pattern_transfer_screen.dart';

/// Study personal patterns directly from analyzed games.
class PatternCardsScreen extends StatefulWidget {
  final List<PatternCard> newCards;
  final EngineApiClient? apiClient;
  final ContentPack? pack;

  const PatternCardsScreen({super.key, this.newCards = const [], this.apiClient, this.pack});

  @override
  State<PatternCardsScreen> createState() => _PatternCardsScreenState();
}

class _PatternCardsScreenState extends State<PatternCardsScreen> {
  final _store = PatternCardStore();
  List<PatternCard> _cards = const [];
  List<PatternCard> _session = const [];
  bool _loading = true;
  bool _revealed = false;
  bool _practiceEarly = false;
  bool _saving = false;
  String? _error;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final cards = widget.newCards.isEmpty
          ? await _store.load()
          : await _store.upsertAll(widget.newCards);
      if (!mounted) return;
      setState(() {
        _cards = cards;
        _session = _dueCards(cards);
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not load Pattern Cards: $error';
        _loading = false;
      });
    }
  }

  List<PatternCard> _dueCards(List<PatternCard> cards) {
    final now = DateTime.now();
    return List<PatternCard>.unmodifiable(
      cards.where((card) => card.isDueAt(now)),
    );
  }

  Future<void> _grade(PatternGrade grade) async {
    if (_saving || _index >= _session.length) return;
    final card = _session[_index];
    setState(() => _saving = true);
    
    try {
      final repo = PuzzleContentRepository();
      final pack = widget.pack ?? await repo.loadPack();
      
      if (!mounted) return;
      
      final client = widget.apiClient ?? EngineApiClient.forBaseUrl(EngineConfig.baseUrl);

      var finalGrade = grade;
      var transferSuccesses = 0;
      var transferAttempts = 0;

      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PatternTransferScreen(
            card: card,
            pack: pack,
            apiClient: client,
            onCompleted: () => Navigator.of(context).pop(),
            onResults: (successes, attempts) {
              transferSuccesses = successes;
              transferAttempts = attempts;
              if (attempts > 0 && successes < attempts) {
                if (grade == PatternGrade.good) {
                  finalGrade = PatternGrade.hard;
                } else if (grade == PatternGrade.hard) {
                  finalGrade = PatternGrade.again;
                }
              }
            },
          ),
        ),
      );

      final updated = card.graded(finalGrade, DateTime.now()).withTransferResults(transferSuccesses, transferAttempts);
      await _store.saveGrade(updated);
      
      if (!mounted) return;
      setState(() {
        _cards = [
          for (final current in _cards)
            if (current.id == card.id) updated else current,
        ];
        _index++;
        _revealed = false;
        _saving = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not load transfer exercises: $error';
        _saving = false;
      });
    }
  }

  void _studyEarly() {
    setState(() {
      _practiceEarly = true;
      _session = List.unmodifiable(_cards);
      _index = 0;
      _revealed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final complete = !_loading && _index >= _session.length;
    return Scaffold(
      appBar: AppBar(title: const Text('Pattern Cards')),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'My Patterns · ${_cards.length} saved',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Try a move, examine the reply, then explain the pattern.',
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Text(
                      _error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  if (complete && _error == null) ...[
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            const Icon(Icons.school_outlined, size: 36),
                            const SizedBox(height: 10),
                            Text(
                              _cards.isEmpty
                                  ? 'No Pattern Cards yet'
                                  : 'All due cards reviewed',
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _cards.isEmpty
                                  ? 'Analyze a game in My Games and choose Study these Pattern Cards.'
                                  : 'Again: 10 minutes · Hard: 1 day · Good: spaced review.',
                              textAlign: TextAlign.center,
                            ),
                            if (_cards.isNotEmpty && !_practiceEarly) ...[
                              const SizedBox(height: 12),
                              OutlinedButton(
                                onPressed: _studyEarly,
                                child: const Text('Practice all cards now'),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ] else if (!complete) ...[
                    Text('Card ${_index + 1} of ${_session.length}'),
                    const SizedBox(height: 8),
                    PatternPracticeCard(
                      key: ValueKey(
                        '${_session[_index].id}:$_index:$_practiceEarly',
                      ),
                      card: _session[_index],
                      revealed: _revealed,
                    ),
                    const SizedBox(height: 12),
                    if (!_revealed)
                      FilledButton.icon(
                        key: const ValueKey('pattern-reveal'),
                        onPressed: () => setState(() => _revealed = true),
                        icon: const Icon(Icons.visibility_outlined),
                        label: const Text('Reveal explanation'),
                      )
                    else ...[
                      const Text('How well did you recognize this pattern?'),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: _saving
                                  ? null
                                  : () => _grade(PatternGrade.again),
                              child: const Text('Again'),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: _saving
                                  ? null
                                  : () => _grade(PatternGrade.hard),
                              child: const Text('Hard'),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: FilledButton(
                              onPressed: _saving
                                  ? null
                                  : () => _grade(PatternGrade.good),
                              child: const Text('Good'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ],
              ),
      ),
    );
  }
}
