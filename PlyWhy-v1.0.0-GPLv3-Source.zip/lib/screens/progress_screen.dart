import 'package:flutter/material.dart';

import '../models.dart';
import '../profile_logic.dart';
import '../progression_logic.dart';
import '../widgets/rating_sparkline.dart';
import '../widgets/skill_bar.dart';

class ProgressScreen extends StatelessWidget {
  final AppProgress progress;

  const ProgressScreen({super.key, required this.progress});

  String _formatTimestamp(String iso) {
    final date = DateTime.tryParse(iso)?.toLocal();
    if (date == null) return iso;
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '${date.year}-$month-$day $hour:$minute';
  }

  IconData _iconForKind(SessionKind kind) {
    switch (kind) {
      case SessionKind.assessment:
        return Icons.psychology_alt_outlined;
      case SessionKind.training:
        return Icons.auto_awesome_outlined;
      case SessionKind.blunderShield:
        return Icons.shield_outlined;
      case SessionKind.opponentVision:
        return Icons.visibility_outlined;
      case SessionKind.blunderSurvival:
        return Icons.favorite_border;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final rating = calculateChessSenseRating(progress.skillScores);
    final ratingTrend = progress.history
        .take(12)
        .toList()
        .reversed
        .map((record) => record.ratingAfter)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Progress')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            const Text(
              'Your thinking profile',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 5),
            Text(
              'Your progress, based on completed ChessSense sessions.',
              style: TextStyle(color: colors.onSurfaceVariant, fontSize: 13),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _MetricCard(
                    icon: Icons.insights_outlined,
                    label: 'RATING',
                    value: '$rating',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _MetricCard(
                    icon: Icons.military_tech_outlined,
                    label: 'LEVEL',
                    value: '${levelForXp(progress.xp)}',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _MetricCard(
                    icon: Icons.local_fire_department_outlined,
                    label: 'STREAK',
                    value: '${progress.streak}d',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Level progress',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        Text(
                          '${xpIntoCurrentLevel(progress.xp)}/$xpPerLevel XP',
                          style: TextStyle(
                            color: colors.onSurfaceVariant,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: levelProgress(progress.xp),
                        minHeight: 9,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 21),
            const _SectionTitle(
              title: 'Rating trend',
              subtitle: 'Your most recent saved rating records',
            ),
            const SizedBox(height: 9),
            Card(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
                child: RatingSparkline(values: ratingTrend),
              ),
            ),
            const SizedBox(height: 23),
            const _SectionTitle(
              title: 'Thinking skills',
              subtitle: 'Scores from 0 to 100; lower scores need more focus',
            ),
            const SizedBox(height: 9),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
                child: Column(
                  children: [
                    for (final skill in Skill.values)
                      SkillBar(
                        skill: skill,
                        score: progress.skillScores[skill] ?? 0,
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 23),
            const _SectionTitle(
              title: 'Recent activity',
              subtitle: 'Your latest saved sessions',
            ),
            const SizedBox(height: 9),
            if (progress.history.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Text(
                    'No saved session history yet.',
                    style: TextStyle(color: colors.onSurfaceVariant),
                  ),
                ),
              )
            else
              for (final record in progress.history.take(12))
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 4,
                    ),
                    leading: CircleAvatar(
                      backgroundColor: colors.primary.withValues(alpha: 0.11),
                      foregroundColor: colors.primary,
                      child: Icon(_iconForKind(record.kind), size: 21),
                    ),
                    title: Text(
                      sessionKindName(record.kind),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(
                      '${_formatTimestamp(record.timestampIso)}  •  ${record.correct}/${record.total} (${record.accuracy}%)',
                      style: const TextStyle(fontSize: 11),
                    ),
                    trailing: Text(
                      '${record.ratingBefore}\n→ ${record.ratingAfter}',
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _MetricCard({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, size: 21, color: colors.primary),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                letterSpacing: 0.8,
                fontWeight: FontWeight.w700,
                color: colors.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
