import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../profile_logic.dart';
import '../progression_logic.dart';

class BlunderDnaScreen extends StatelessWidget {
  final AppProgress progress;

  const BlunderDnaScreen({
    super.key,
    required this.progress,
  });

  String _coachMessage(Skill skill) {
    switch (skill) {
      case Skill.threatAwareness:
        return 'Your biggest leak is failing to notice what the opponent just changed or attacked.';
      case Skill.opponentResponse:
        return 'Your biggest leak is committing a move before calculating the opponent’s strongest reply.';
      case Skill.loosePieceDetection:
        return 'Your biggest leak is leaving pieces undefended or missing loose pieces on the board.';
      case Skill.moveSafety:
        return 'Your biggest leak is choosing a move before checking whether the destination square is safe.';
      case Skill.boardChangeAwareness:
        return 'Your biggest leak is not updating your mental picture after the opponent moves.';
    }
  }

  String _shareText() {
    final dna = blunderDnaPercentages(progress.mistakeCounts);
    final rating = calculateChessSenseRating(progress.skillScores);
    final buffer = StringBuffer()
      ..writeln('MY CHESSSENSE BLUNDER DNA')
      ..writeln('ChessSense Rating: $rating')
      ..writeln('Level: ${levelForXp(progress.xp)}');

    final totalMistakes = progress.mistakeCounts.values.fold<int>(
      0,
      (sum, value) => sum + value,
    );
    if (totalMistakes > 0) {
      for (final skill in Skill.values) {
        buffer.writeln(
          '${skillName(skill)}: ${((dna[skill] ?? 0) * 100).round()}%',
        );
      }
    }

    if (progress.highConfidenceAttempts > 0) {
      buffer.writeln(
        'High-confidence mistakes: ${overconfidenceMistakeRate(highConfidenceAttempts: progress.highConfidenceAttempts, highConfidenceMistakes: progress.highConfidenceMistakes)}%',
      );
    }
    buffer.write('ChessSense — Stop blundering before you move.');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    final dna = blunderDnaPercentages(progress.mistakeCounts);
    final totalMistakes = progress.mistakeCounts.values.fold<int>(
      0,
      (sum, value) => sum + value,
    );
    final topMistake = topMistakeSkill(progress.mistakeCounts);
    final provisionalWeakness = calculateWeakestSkill(progress.skillScores);
    final overconfidence = overconfidenceMistakeRate(
      highConfidenceAttempts: progress.highConfidenceAttempts,
      highConfidenceMistakes: progress.highConfidenceMistakes,
    );
    final patternEntries = progress.blunderPatternCounts.entries
        .where((entry) => entry.value > 0)
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final patternTotal = patternEntries.fold<int>(
      0,
      (sum, entry) => sum + entry.value,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Blunder DNA'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Why you blunder',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text(
              'ChessSense tracks the thinking failure behind your mistakes — not just the move that was wrong.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      totalMistakes == 0 ? 'Provisional profile' : 'Primary blunder pattern',
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      skillName(topMistake ?? provisionalWeakness),
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _coachMessage(topMistake ?? provisionalWeakness),
                    ),
                    if (totalMistakes == 0) ...[
                      const SizedBox(height: 8),
                      const Text(
                        'This is based on your current skill profile. Complete BlunderShield, Opponent Vision or Survival sessions to build real mistake data.',
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Blunder breakdown',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            ...Skill.values.map((skill) {
              final percent = (dna[skill] ?? 0) * 100;
              final count = progress.mistakeCounts[skill] ?? 0;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(skillName(skill))),
                        Text(
                          totalMistakes == 0
                              ? '—'
                              : '${percent.round()}%  ($count)',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    LinearProgressIndicator(
                      value: totalMistakes == 0 ? 0 : dna[skill] ?? 0,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 8),
            if (patternEntries.isNotEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Specific danger patterns',
                        style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      ...patternEntries.take(3).map((entry) {
                        final percent = patternTotal == 0
                            ? 0
                            : ((entry.value / patternTotal) * 100).round();
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            children: [
                              Expanded(child: Text(entry.key)),
                              Text(
                                '$percent%',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
            ],
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.psychology_alt),
                        SizedBox(width: 8),
                        Text(
                          'Confidence vs Reality',
                          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      progress.highConfidenceAttempts == 0
                          ? 'No high-confidence decisions recorded yet.'
                          : '$overconfidence% of your “Very sure” decisions were wrong.',
                      style: const TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      progress.highConfidenceAttempts == 0
                          ? 'Use BlunderShield or Opponent Vision and rate your confidence before committing.'
                          : '${progress.highConfidenceMistakes} mistakes in ${progress.highConfidenceAttempts} high-confidence decisions.',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: _shareText()));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Blunder DNA copied to clipboard.')),
                  );
                }
              },
              icon: const Icon(Icons.ios_share),
              label: const Text('Copy Shareable Blunder DNA'),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const Icon(Icons.favorite_border),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'Blunder Survival personal best',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Text(
                      '${progress.survivalBest}',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
