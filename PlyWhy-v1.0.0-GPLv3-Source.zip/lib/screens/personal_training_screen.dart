import 'package:flutter/material.dart';

import '../fen_utils.dart';
import '../personal_game_analysis.dart';
import '../personal_review_training.dart';
import '../widgets/interactive_chessboard.dart';

class PersonalTrainingScreen extends StatefulWidget {
  final List<PersonalReviewItem> items;

  const PersonalTrainingScreen({
    super.key,
    required this.items,
  });

  @override
  State<PersonalTrainingScreen> createState() => _PersonalTrainingScreenState();
}

class _PersonalTrainingScreenState extends State<PersonalTrainingScreen> {
  final _store = PersonalReviewStore();
  final _scheduler = const PersonalReviewScheduler();

  Map<String, PersonalReviewProgress> _progress = const {};
  List<PersonalReviewItem> _queue = const [];
  bool _loading = true;
  bool _revealed = false;
  int _index = 0;
  int _completed = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final progress = await _store.load();
    final now = DateTime.now().toUtc();
    final due = widget.items.where((item) {
      final saved = progress[item.id];
      return saved == null || saved.isDue(now);
    }).toList(growable: false);

    if (!mounted) return;
    setState(() {
      _progress = progress;
      _queue = due;
      _loading = false;
    });
  }

  void _reviewAnyway() {
    setState(() {
      _queue = List<PersonalReviewItem>.from(widget.items);
      _index = 0;
      _completed = 0;
      _revealed = false;
    });
  }

  Future<void> _grade(PersonalReviewGrade grade) async {
    final item = _queue[_index];
    final next = _scheduler.next(
      previous: _progress[item.id],
      grade: grade,
      now: DateTime.now().toUtc(),
    );

    await _store.save(item.id, next);
    if (!mounted) return;

    final updated = Map<String, PersonalReviewProgress>.from(_progress)
      ..[item.id] = next;
    final nextIndex = _index + 1;

    setState(() {
      _progress = updated;
      _completed++;
      _revealed = false;
      if (nextIndex < _queue.length) {
        _index = nextIndex;
      } else {
        _index = _queue.length;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Personal Training')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (widget.items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Personal Training')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'There are no PGN-marked mistakes available for personal training yet.',
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      );
    }

    if (_queue.isEmpty) {
      final nextDue = _nextDue();
      return Scaffold(
        appBar: AppBar(title: const Text('Personal Training')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.task_alt, size: 52),
                  const SizedBox(height: 12),
                  const Text(
                    'Nothing is due right now',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    nextDue == null
                        ? 'Your personal review queue is clear.'
                        : 'Next scheduled review: ${_formatDate(nextDue)}',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 18),
                  OutlinedButton.icon(
                    onPressed: _reviewAnyway,
                    icon: const Icon(Icons.replay),
                    label: const Text('Review anyway'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    if (_index >= _queue.length) {
      return Scaffold(
        appBar: AppBar(title: const Text('Personal Training')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.verified_outlined, size: 56),
                  const SizedBox(height: 12),
                  const Text(
                    'Review complete',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('$_completed position${_completed == 1 ? '' : 's'} scheduled for future review.'),
                  const SizedBox(height: 18),
                  FilledButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Done'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    final item = _queue[_index];
    final move = item.move;
    final board = parseFenBoard(move.fenBefore);
    final blackToMove = move.fenBefore.split(RegExp(r'\s+'))[1] == 'b';

    return Scaffold(
      appBar: AppBar(title: const Text('Personal Training')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.gameLabel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                Text('${_index + 1}/${_queue.length}'),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Your move is hidden. Rebuild the thought process before you reveal it.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 10),
            InteractiveChessBoard(
              board: board,
              flipped: blackToMove,
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ChessSense scan',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const _Prompt('1. What changed after the opponent\'s last move?'),
                    const _Prompt('2. What is threatened right now?'),
                    const _Prompt('3. Checks, captures, and loose pieces?'),
                    const _Prompt('4. What is the opponent\'s strongest reply?'),
                    const _Prompt('5. Is the move you want to play still safe?'),
                    const SizedBox(height: 10),
                    if (!_revealed)
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () => setState(() => _revealed = true),
                          icon: const Icon(Icons.visibility_outlined),
                          label: const Text('Reveal what I played'),
                        ),
                      )
                    else ...[
                      const Divider(height: 20),
                      Text(
                        'You played: ${move.moveLabel}',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${pgnMistakeLabel(item.severity)} · marked ${move.annotation} in the imported PGN',
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'How well did you recognize the danger this time?',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => _grade(PersonalReviewGrade.hard),
                              child: const Text('Hard'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.tonal(
                              onPressed: () => _grade(PersonalReviewGrade.good),
                              child: const Text('Good'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton(
                              onPressed: () => _grade(PersonalReviewGrade.easy),
                              child: const Text('Easy'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Quality rule: the mistake label comes from the imported PGN. This review trains your thought process; it does not pretend to know an engine best move.',
              style: TextStyle(fontSize: 11),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  DateTime? _nextDue() {
    DateTime? next;
    for (final item in widget.items) {
      final due = _progress[item.id]?.dueAt;
      if (due == null) continue;
      if (next == null || due.isBefore(next)) next = due;
    }
    return next;
  }

  static String _formatDate(DateTime value) {
    final local = value.toLocal();
    final month = local.month.toString().padLeft(2, '0');
    final day = local.day.toString().padLeft(2, '0');
    return '${local.year}-$month-$day';
  }
}

class _Prompt extends StatelessWidget {
  final String text;

  const _Prompt(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(Icons.radio_button_unchecked, size: 17),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
