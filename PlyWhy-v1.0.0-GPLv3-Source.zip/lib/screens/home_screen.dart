import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../models.dart';
import '../profile_logic.dart';
import '../progression_logic.dart';
import 'assessment_screen.dart';
import 'blunder_dna_screen.dart';
import 'blunder_shield_screen.dart';
import 'blunder_survival_screen.dart';
import 'daily_training_screen.dart';
import 'opponent_vision_screen.dart';
import 'open_source_licenses_screen.dart';
import 'pgn_import_screen.dart';
import 'pattern_cards_screen.dart';
import 'privacy_policy_screen.dart';
import 'progress_screen.dart';
import 'weekly_report_screen.dart';

class HomeScreen extends StatelessWidget {
  final AppProgress progress;
  final Future<void> Function(AssessmentResult) onAssessmentComplete;
  final Future<void> Function(TrainingResult) onTrainingComplete;
  final Future<void> Function() onResetProgress;
  final Future<void> Function() onRunQuickQa;

  const HomeScreen({
    super.key,
    required this.progress,
    required this.onAssessmentComplete,
    required this.onTrainingComplete,
    required this.onResetProgress,
    required this.onRunQuickQa,
  });

  @override
  Widget build(BuildContext context) {
    final rating = calculateChessSenseRating(progress.skillScores);
    final weakest = calculateWeakestSkill(progress.skillScores);
    final level = levelForXp(progress.xp);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ChessSense',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          if (kDebugMode)
            IconButton(
              tooltip: 'Run Quick QA Session',
              onPressed: onRunQuickQa,
              icon: const Icon(Icons.bolt),
            ),
        ],
      ),
      body: SafeArea(
        child: !progress.assessmentCompleted
            ? ListView(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
                children: [
                  const Text(
                    'Stop blundering before you move.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Train the thinking process — not just the answer.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 16),
                  _AssessmentPrompt(onStart: () => _openAssessment(context)),
                ],
              )
            : Padding(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Stop blundering before you move.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    _RatingStrip(
                      rating: rating,
                      level: level,
                      xp: progress.xp,
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        Expanded(
                          child: _CompactStat(
                            icon: Icons.local_fire_department,
                            label: 'Streak',
                            value: '${progress.streak}d',
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _CompactStat(
                            icon: Icons.school_outlined,
                            label: 'Sessions',
                            value: '${progress.sessionsCompleted}',
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _CompactStat(
                            icon: Icons.favorite_border,
                            label: 'Survival',
                            value: '${progress.survivalBest}',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    _FocusStrip(skill: skillName(weakest)),
                    const SizedBox(height: 10),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Train',
                          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                        ),
                        Text('4 modes', style: TextStyle(fontSize: 11)),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Expanded(
                      child: GridView.count(
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: 2,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                        childAspectRatio: 1.58,
                        children: [
                          _ModeTile(
                            icon: Icons.auto_awesome,
                            title: 'Daily Sense',
                            badge: 'ADAPTIVE',
                            subtitle: 'Train your weakest thinking skills.',
                            onTap: () => _openDailyTraining(context),
                          ),
                          _ModeTile(
                            icon: Icons.shield_outlined,
                            title: 'BlunderShield',
                            badge: 'CORE MODE',
                            subtitle: 'Scan first. Move second.',
                            onTap: () => _openBlunderShield(context),
                          ),
                          _ModeTile(
                            icon: Icons.visibility_outlined,
                            title: 'Opponent Vision',
                            badge: '5K PACK',
                            subtitle: 'Play the opponent\'s strongest reply.',
                            onTap: () => _openOpponentVision(context),
                          ),
                          _ModeTile(
                            icon: Icons.favorite_border,
                            title: 'Blunder Survival',
                            badge: 'FAST MODE',
                            subtitle: 'SAFE or BLUNDER. Three lives.',
                            onTap: () => _openBlunderSurvival(context),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: _QuickAction(
                            icon: Icons.fingerprint,
                            label: 'Blunder DNA',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => BlunderDnaScreen(progress: progress),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _QuickAction(
                            icon: Icons.calendar_view_week,
                            label: 'Weekly Report',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => WeeklyReportScreen(progress: progress),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    SizedBox(
                      height: 40,
                      child: Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.upload_file, size: 18),
                              label: const Text('My Games'),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const PgnImportScreen(),
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.insights, size: 18),
                              label: const Text('Progress'),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ProgressScreen(progress: progress),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    SizedBox(
                      height: 38,
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.style_outlined, size: 18),
                        label: const Text('Pattern Cards'),
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const PatternCardsScreen(),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 34,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () => _openAssessment(context),
                            child: const Text('Retake Assessment'),
                          ),
                          if (kDebugMode) ...[
                            const Text('•'),
                            TextButton(
                              onPressed: () => _confirmReset(context),
                              child: const Text('Reset Local Data'),
                            ),
                          ],
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 34,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const OpenSourceLicensesScreen()),
                            ),
                            child: const Text('Licenses'),
                          ),
                          const Text('•'),
                          TextButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()),
                            ),
                            child: const Text('Privacy Policy'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Future<void> _openAssessment(BuildContext context) async {
    final result = await Navigator.push<AssessmentResult>(
      context,
      MaterialPageRoute(builder: (_) => const AssessmentScreen()),
    );
    if (result != null) await onAssessmentComplete(result);
  }

  Future<void> _openDailyTraining(BuildContext context) async {
    final result = await Navigator.push<TrainingResult>(
      context,
      MaterialPageRoute(
        builder: (_) => DailyTrainingScreen(
          skillScores: progress.skillScores,
          recentExerciseIds: progress.recentExerciseIds,
        ),
      ),
    );
    if (result != null) await onTrainingComplete(result);
  }

  Future<void> _openBlunderShield(BuildContext context) async {
    final result = await Navigator.push<TrainingResult>(
      context,
      MaterialPageRoute(builder: (_) => const BlunderShieldScreen()),
    );
    if (result != null) await onTrainingComplete(result);
  }

  Future<void> _openOpponentVision(BuildContext context) async {
    final result = await Navigator.push<TrainingResult>(
      context,
      MaterialPageRoute(
        builder: (_) => OpponentVisionScreen(
          skillScore: progress.skillScores[Skill.opponentResponse] ?? 50,
          recentExerciseIds: progress.recentExerciseIds,
        ),
      ),
    );
    if (result != null) await onTrainingComplete(result);
  }

  Future<void> _openBlunderSurvival(BuildContext context) async {
    final result = await Navigator.push<TrainingResult>(
      context,
      MaterialPageRoute(builder: (_) => const BlunderSurvivalScreen()),
    );
    if (result != null) await onTrainingComplete(result);
  }

  Future<void> _confirmReset(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset local test data?'),
        content: const Text(
          'This clears the locally saved ChessSense profile on this emulator.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );

    if (confirmed == true) await onResetProgress();
  }
}

class _AssessmentPrompt extends StatelessWidget {
  final VoidCallback onStart;

  const _AssessmentPrompt({required this.onStart});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.psychology_alt, size: 52),
            const SizedBox(height: 14),
            const Text(
              'Discover your ChessSense Profile',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'Complete the 20-question assessment to identify your strongest and weakest thinking skills.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: onStart,
                child: const Text('Start Initial Assessment'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RatingStrip extends StatelessWidget {
  final int rating;
  final int level;
  final int xp;

  const _RatingStrip({required this.rating, required this.level, required this.xp});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ChessSense Rating', style: TextStyle(fontSize: 11)),
                  Text(
                    '$rating',
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, height: 1),
                  ),
                  const Text('Internal metric — not Elo', style: TextStyle(fontSize: 9)),
                ],
              ),
            ),
            SizedBox(
              width: 118,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('LEVEL $level', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 7),
                  LinearProgressIndicator(
                    value: levelProgress(xp),
                    minHeight: 6,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  const SizedBox(height: 3),
                  Text('${xpIntoCurrentLevel(xp)}/$xpPerLevel XP', style: const TextStyle(fontSize: 9)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _CompactStat({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 5),
          Column(
            children: [
              Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              Text(label, style: const TextStyle(fontSize: 8)),
            ],
          ),
        ],
      ),
    );
  }
}

class _FocusStrip extends StatelessWidget {
  final String skill;

  const _FocusStrip({required this.skill});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.gps_fixed, size: 17),
          const SizedBox(width: 8),
          const Text('Focus:', style: TextStyle(fontSize: 11)),
          const SizedBox(width: 5),
          Expanded(
            child: Text(
              skill,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String badge;
  final VoidCallback onTap;

  const _ModeTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, size: 22),
                  const Spacer(),
                  const Icon(Icons.chevron_right, size: 17),
                ],
              ),
              const Spacer(),
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 1),
              Text(
                badge,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 9.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 42,
      child: OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 17),
        label: Text(label, style: const TextStyle(fontSize: 11)),
      ),
    );
  }
}
