import 'package:flutter/material.dart';

import '../exercise_bank.dart';
import '../models.dart';
import '../profile_logic.dart';
import '../widgets/exercise_page.dart';
import '../widgets/skill_bar.dart';

class AssessmentScreen extends StatefulWidget {
  const AssessmentScreen({super.key});

  @override
  State<AssessmentScreen> createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends State<AssessmentScreen> {
  late final List<Exercise> exercises;

  int current = 0;
  int? selected;
  int correct = 0;
  bool finished = false;

  final Map<Skill, int> correctBySkill = {
    for (final skill in Skill.values) skill: 0,
  };

  final Map<Skill, int> totalBySkill = {
    for (final skill in Skill.values) skill: 0,
  };

  @override
  void initState() {
    super.initState();
    exercises = initialAssessmentExercises;

    for (final exercise in exercises) {
      totalBySkill[exercise.skill] = (totalBySkill[exercise.skill] ?? 0) + 1;
    }
  }

  void _chooseAnswer(int index) {
    if (selected != null) return;

    final exercise = exercises[current];
    setState(() {
      selected = index;
      if (index == exercise.correctIndex) {
        correct++;
        correctBySkill[exercise.skill] = (correctBySkill[exercise.skill] ?? 0) + 1;
      }
    });
  }

  void _next() {
    if (current < exercises.length - 1) {
      setState(() {
        current++;
        selected = null;
      });
      return;
    }

    setState(() {
      finished = true;
    });
  }

  AssessmentResult _buildResult() {
    final scores = <Skill, int>{};
    for (final skill in Skill.values) {
      final total = totalBySkill[skill] ?? 0;
      final skillCorrect = correctBySkill[skill] ?? 0;
      scores[skill] = total == 0 ? 0 : ((skillCorrect / total) * 100).round();
    }

    return AssessmentResult(
      correct: correct,
      total: exercises.length,
      skillScores: scores,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (finished) {
      final result = _buildResult();
      final rating = calculateChessSenseRating(result.skillScores);
      final weakest = calculateWeakestSkill(result.skillScores);

      return Scaffold(
        appBar: AppBar(
          title: const Text('Assessment Complete'),
          centerTitle: true,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Text('ChessSense Rating'),
                        Text(
                          '$rating',
                          style: const TextStyle(
                            fontSize: 50,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text('${result.correct} / ${result.total} correct'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Primary Weakness'),
                        const SizedBox(height: 6),
                        Text(
                          skillName(weakest),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Skill Profile',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                ...Skill.values.map(
                  (skill) => SkillBar(
                    skill: skill,
                    score: result.skillScores[skill] ?? 0,
                  ),
                ),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () => Navigator.pop(context, result),
                  child: const Text('Save Profile & Return Home'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final exercise = exercises[current];
    return ExercisePage(
      title: 'Initial Assessment',
      currentNumber: current + 1,
      totalNumber: exercises.length,
      exercise: exercise,
      selected: selected,
      onSelect: _chooseAnswer,
      onNext: _next,
      finalButton: current == exercises.length - 1 ? 'See Results' : 'Next',
    );
  }
}
