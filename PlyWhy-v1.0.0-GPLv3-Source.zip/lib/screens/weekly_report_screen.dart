import 'package:flutter/material.dart';

import '../models.dart';
import '../progression_logic.dart';

class WeeklyReportScreen extends StatelessWidget {
  final AppProgress progress;

  const WeeklyReportScreen({
    super.key,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final start = DateTime.now().subtract(const Duration(days: 7));
    final sessions = trainingSessionsSince(progress.history, start);
    final accuracy = averageAccuracy(sessions);
    final ratingDelta = ratingChangeForSessions(sessions);
    final improved = mostImprovedSkill(sessions);
    final improvedDelta = improved == null ? 0 : skillDeltaForSessions(sessions, improved);
    final danger = topMistakeSkill(progress.mistakeCounts);
    final goalProgress =
        (sessions.length / weeklySessionGoal).clamp(0.0, 1.0).toDouble();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Weekly ChessSense Report'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Last 7 days',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _Metric(
                    label: 'Sessions',
                    value: '${sessions.length}',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _Metric(
                    label: 'Accuracy',
                    value: sessions.isEmpty ? '—' : '$accuracy%',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _Metric(
                    label: 'Rating',
                    value: sessions.isEmpty
                        ? '—'
                        : '${ratingDelta >= 0 ? '+' : ''}$ratingDelta',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Weekly challenge',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text('Complete $weeklySessionGoal training sessions'),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: goalProgress,
                      minHeight: 9,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    const SizedBox(height: 6),
                    Text('${sessions.length}/$weeklySessionGoal sessions'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Biggest improvement',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      improved == null
                          ? 'Complete at least two sessions this week to measure improvement.'
                          : '${skillName(improved)} ${improvedDelta >= 0 ? '+' : ''}$improvedDelta',
                      style: const TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Danger pattern',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      danger == null
                          ? 'No mistake pattern yet. Complete the new training modes to build your Blunder DNA.'
                          : '${skillName(danger)} is currently your most frequent recorded mistake type.',
                      style: const TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Next focus',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      danger == Skill.opponentResponse
                          ? 'Before every move, force yourself to name the opponent’s best reply.'
                          : danger == Skill.moveSafety
                              ? 'Before committing, scan the destination square and all forcing responses.'
                              : danger == Skill.threatAwareness
                                  ? 'After every opponent move, ask: “What changed and what is attacked now?”'
                                  : danger == Skill.loosePieceDetection
                                      ? 'Scan every piece that is undefended or defended only once.'
                                      : danger == Skill.boardChangeAwareness
                                          ? 'Rebuild the tactical picture after every opponent move.'
                                          : 'Build more data with Daily Sense, BlunderShield and Opponent Vision.',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;

  const _Metric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
        child: Column(
          children: [
            Text(label, style: Theme.of(context).textTheme.labelMedium),
            const SizedBox(height: 5),
            Text(
              value,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
