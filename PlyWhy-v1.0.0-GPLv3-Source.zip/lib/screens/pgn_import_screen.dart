import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../game_platform_import.dart';
import '../game_batch_processor.dart';
import '../personal_game_analysis.dart';
import 'engine_game_analysis_screen.dart';
import 'personal_game_review_screen.dart';

enum _ImportSource { lichess, chessCom, manual }

class _ImportedAnalysis {
  final _ImportSource source;
  final PersonalGameAnalysis analysis;
  final String? playerUsername;

  const _ImportedAnalysis({
    required this.source,
    required this.analysis,
    required this.playerUsername,
  });
}

class PgnImportScreen extends StatefulWidget {
  const PgnImportScreen({super.key});

  @override
  State<PgnImportScreen> createState() => _PgnImportScreenState();
}

class _PgnImportScreenState extends State<PgnImportScreen> {
  static const _lichessUserKey = 'chesssense_lichess_username';
  static const _chessComUserKey = 'chesssense_chesscom_username';

  final _pgnController = TextEditingController();
  final _lichessController = TextEditingController();
  final _chessComController = TextEditingController();
  final _scrollController = ScrollController();
  final _resultsKey = GlobalKey();
  late final OnlineGameImportService _onlineService;

  List<_ImportedAnalysis> _analyses = const [];
  String? _error;
  bool _loadingLichess = false;
  bool _loadingChessCom = false;
  bool _loadingSavedAccounts = true;
  bool _manualExpanded = false;

  @override
  void initState() {
    super.initState();
    _onlineService = OnlineGameImportService.io();
    _loadSavedAccounts();
  }

  @override
  void dispose() {
    _pgnController.dispose();
    _lichessController.dispose();
    _chessComController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadSavedAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    _lichessController.text = prefs.getString(_lichessUserKey) ?? '';
    _chessComController.text = prefs.getString(_chessComUserKey) ?? '';
    setState(() => _loadingSavedAccounts = false);

    // Show the screen before automatic network sync/reconstruction begins.
    // Keep usernames and refresh behavior, but avoid a startup workload burst.
    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (!mounted) return;
    // Saved accounts still refresh automatically without requiring pasted PGN.
    if (_lichessController.text.trim().isNotEmpty) {
      await _syncLichess(showSuccessMessage: false);
    }
    if (!mounted) return;
    if (_chessComController.text.trim().isNotEmpty) {
      await _syncChessCom(showSuccessMessage: false);
    }
  }

  Future<void> _syncLichess({bool showSuccessMessage = true}) async {
    final username = _lichessController.text.trim();
    if (username.isEmpty) {
      _showError('Enter your Lichess username first.');
      return;
    }

    setState(() {
      _loadingLichess = true;
      _error = null;
    });

    try {
      final pgn = await _onlineService.fetchLichessPgn(username);
      if (!mounted) return;
      final count = await _replaceSourceFromPgn(
        _ImportSource.lichess,
        pgn,
        playerUsername: username,
        scrollToResults: showSuccessMessage,
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_lichessUserKey, username);
      if (!mounted) return;
      if (showSuccessMessage) {
        _showMessage('Loaded $count recent Lichess game${count == 1 ? '' : 's'}.');
      }
    } catch (error) {
      if (!mounted) return;
      _showError(error.toString());
    } finally {
      if (mounted) setState(() => _loadingLichess = false);
    }
  }

  Future<void> _syncChessCom({bool showSuccessMessage = true}) async {
    final username = _chessComController.text.trim();
    if (username.isEmpty) {
      _showError('Enter your Chess.com username first.');
      return;
    }

    setState(() {
      _loadingChessCom = true;
      _error = null;
    });

    try {
      final pgn = await _onlineService.fetchChessComPgn(username);
      if (!mounted) return;
      final count = await _replaceSourceFromPgn(
        _ImportSource.chessCom,
        pgn,
        playerUsername: username,
        scrollToResults: showSuccessMessage,
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_chessComUserKey, username);
      if (!mounted) return;
      if (showSuccessMessage) {
        _showMessage('Loaded $count recent Chess.com game${count == 1 ? '' : 's'}.');
      }
    } catch (error) {
      if (!mounted) return;
      _showError(error.toString());
    } finally {
      if (mounted) setState(() => _loadingChessCom = false);
    }
  }

  Future<int> _replaceSourceFromPgn(
    _ImportSource source,
    String pgn, {
    String? playerUsername,
    bool scrollToResults = true,
  }) async {
    // PGN decoding and chess move reconstruction are CPU-intensive. Do not
    // execute them on the Android UI isolate: Future.delayed(Duration.zero)
    // cannot interrupt one expensive chess.move() or PgnParser.parse() call.
    final analyses = await reconstructPgnOffMainThread(pgn);
    if (!mounted) return 0;
    final imported = <_ImportedAnalysis>[
      for (final analysis in analyses)
        _ImportedAnalysis(
          source: source,
          analysis: analysis,
          playerUsername: playerUsername,
        ),
    ];

    if (!mounted) return imported.length;
    setState(() {
      _analyses = [
        ...imported,
        ..._analyses.where((item) => item.source != source),
      ];
      final invalidCount = imported
          .where((item) => !item.analysis.isValid)
          .length;
      _error = invalidCount == 0
          ? null
          : '$invalidCount imported game${invalidCount == 1 ? '' : 's'} could not be fully reconstructed.';
    });
    if (scrollToResults) _scrollToResults();
    return imported.length;
  }

  Future<void> _importManualPgn() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final text = _pgnController.text.trim();
    if (text.isEmpty) {
      _showError('Paste a PGN first.');
      return;
    }

    try {
      final count = await _replaceSourceFromPgn(_ImportSource.manual, text);
      if (!mounted) return;
      _showMessage('Imported $count PGN game${count == 1 ? '' : 's'}.');
    } catch (error) {
      if (!mounted) return;
      _showError(error.toString());
    }
  }

  void _clearManual() {
    _pgnController.clear();
    setState(() {
      _analyses = _analyses
          .where((item) => item.source != _ImportSource.manual)
          .toList(growable: false);
      _error = null;
    });
  }

  void _showError(String message) {
    setState(() => _error = message);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _showMessage(String message) {
    setState(() => _error = null);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _scrollToResults() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final resultsContext = _resultsKey.currentContext;
      if (resultsContext != null) {
        Scrollable.ensureVisible(
          resultsContext,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          alignment: 0.05,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalPlies = _analyses.fold<int>(
      0,
      (sum, item) => sum + item.analysis.moves.length,
    );
    final reviewCount = _analyses.fold<int>(
      0,
      (sum, item) => sum + item.analysis.annotatedReviewMoves.length,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('My Games')),
      body: SafeArea(
        child: ListView(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            const Text(
              'Your games, automatically',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text(
              'Enter each public username once. ChessSense remembers it and refreshes your recent games on this device.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 14),
            if (_loadingSavedAccounts)
              const LinearProgressIndicator()
            else ...[
              _AccountImportCard(
                title: 'Lichess',
                icon: Icons.bolt_outlined,
                controller: _lichessController,
                hint: 'Lichess username',
                loading: _loadingLichess,
                onSync: _syncLichess,
              ),
              const SizedBox(height: 10),
              _AccountImportCard(
                title: 'Chess.com',
                icon: Icons.public,
                controller: _chessComController,
                hint: 'Chess.com username',
                loading: _loadingChessCom,
                onSync: _syncChessCom,
              ),
            ],
            const SizedBox(height: 10),
            Card(
              child: ExpansionTile(
                initiallyExpanded: _manualExpanded,
                onExpansionChanged: (value) {
                  setState(() => _manualExpanded = value);
                },
                leading: const Icon(Icons.content_paste_outlined),
                title: const Text('Paste PGN manually'),
                subtitle: const Text('Fallback for any game source'),
                childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                children: [
                  TextField(
                    controller: _pgnController,
                    minLines: 7,
                    maxLines: 12,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Paste PGN here',
                      alignLabelWithHint: true,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _importManualPgn,
                          icon: const Icon(Icons.upload_file),
                          label: const Text('Import PGN'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton(
                        onPressed: _clearManual,
                        child: const Text('Clear'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(
                _error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ],
            if (_analyses.isNotEmpty) ...[
              SizedBox(key: _resultsKey, height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle_outline),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_analyses.length} recent game${_analyses.length == 1 ? '' : 's'} ready',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text('$totalPlies half-moves · $reviewCount PGN-marked review position${reviewCount == 1 ? '' : 's'}'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Recent games',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              ..._analyses.take(40).map(
                    (item) => _GameCard(
                      analysis: item.analysis,
                      source: item.source,
                      onReview: item.analysis.isValid
                          ? () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => PersonalGameReviewScreen(
                                    analysis: item.analysis,
                                  ),
                                ),
                              );
                            }
                          : null,
                      onEngineAnalysis: item.analysis.isValid
                          ? () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => EngineGameAnalysisScreen(
                                    analysis: item.analysis,
                                    playerUsername: item.playerUsername,
                                  ),
                                ),
                              );
                            }
                          : null,
                    ),
                  ),
              if (_analyses.length > 40)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    '+ ${_analyses.length - 40} more games loaded',
                    textAlign: TextAlign.center,
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _AccountImportCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final TextEditingController controller;
  final String hint;
  final bool loading;
  final Future<void> Function() onSync;

  const _AccountImportCard({
    required this.title,
    required this.icon,
    required this.controller,
    required this.hint,
    required this.loading,
    required this.onSync,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: controller,
              autocorrect: false,
              enableSuggestions: false,
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: hint,
                isDense: true,
              ),
              onSubmitted: loading ? null : (_) => onSync(),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: loading ? null : onSync,
                icon: loading
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.sync),
                label: Text(loading ? 'Syncing…' : 'Sync recent games'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GameCard extends StatelessWidget {
  final PersonalGameAnalysis analysis;
  final _ImportSource source;
  final VoidCallback? onReview;
  final VoidCallback? onEngineAnalysis;

  const _GameCard({
    required this.analysis,
    required this.source,
    required this.onReview,
    required this.onEngineAnalysis,
  });

  @override
  Widget build(BuildContext context) {
    final game = analysis.game;
    final reviewCount = analysis.annotatedReviewMoves.length;
    final sourceLabel = switch (source) {
      _ImportSource.lichess => 'Lichess',
      _ImportSource.chessCom => 'Chess.com',
      _ImportSource.manual => 'PGN',
    };
    final secondary = <String>[
      sourceLabel,
      if (game.date.isNotEmpty && game.date != '????.??.??') game.date,
      game.result,
      '${game.fullMoveCount} moves',
      if (analysis.isValid) '$reviewCount PGN review',
      if (!analysis.isValid) 'PGN reconstruction stopped',
    ].join(' · ');

    return Card(
      child: Column(
        children: [
          ListTile(
            leading: Icon(
              analysis.isValid
                  ? Icons.sports_esports_outlined
                  : Icons.warning_amber_rounded,
            ),
            title: Text(
              '${game.white} vs ${game.black}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(secondary),
            trailing: analysis.isValid
                ? const Icon(Icons.chevron_right)
                : null,
            onTap: onReview,
          ),
          if (onEngineAnalysis != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.tonalIcon(
                  onPressed: onEngineAnalysis,
                  icon: const Icon(Icons.memory_outlined),
                  label: const Text('Analyze with ChessSense'),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
