import 'dart:math';

import 'package:flutter/material.dart';

import '../fen_utils.dart';
import '../mode_content.dart';
import '../models.dart';
import '../widgets/interactive_chessboard.dart';

class BlunderShieldScreen extends StatefulWidget {
  const BlunderShieldScreen({super.key});

  @override
  State<BlunderShieldScreen> createState() => _BlunderShieldScreenState();
}

class _BlunderShieldScreenState extends State<BlunderShieldScreen> {
  late final List<InteractiveMoveScenario> scenarios;
  int current = 0;
  int correct = 0;
  int highConfidenceAttempts = 0;
  int highConfidenceMistakes = 0;
  int mistakes = 0;
  final Map<String, int> patternMistakes = <String, int>{};
  String? selectedFrom;
  String? selectedTo;
  ConfidenceLevel? confidence;
  bool answered = false;
  bool? lastCorrect;
  final Set<int> completedScans = <int>{};

  static const _scanLabels = [
    'What changed?',
    'Threats',
    'Checks',
    'Captures',
    'Loose pieces',
  ];

  @override
  void initState() {
    super.initState();
    scenarios = [...blunderShieldScenarios]..shuffle(Random());
    scenarios.removeRange(5, scenarios.length);
  }

  InteractiveMoveScenario get scenario => scenarios[current];

  void _tapSquare(String square) {
    if (answered) return;

    setState(() {
      if (selectedFrom == null) {
        selectedFrom = square;
        selectedTo = null;
        return;
      }

      if (selectedFrom == square) {
        selectedFrom = null;
        selectedTo = null;
        return;
      }

      final candidateDestinations = scenario.candidates
          .where((choice) => choice.uci.substring(0, 2) == selectedFrom)
          .map((choice) => choice.uci.substring(2, 4))
          .toSet();

      if (candidateDestinations.contains(square)) {
        selectedTo = square;
        return;
      }

      final board = parseFenBoard(scenario.fen);
      if (board.containsKey(square)) {
        selectedFrom = square;
        selectedTo = null;
      } else {
        selectedTo = square;
      }
    });
  }

  Set<String> _candidateDestinations() {
    if (selectedFrom == null) return const {};
    return scenario.candidates
        .where((choice) => choice.uci.substring(0, 2) == selectedFrom)
        .map((choice) => choice.uci.substring(2, 4))
        .toSet();
  }

  String? _selectedMoveLabel() {
    final uci = uciFromSquares(selectedFrom, selectedTo);
    for (final choice in scenario.candidates) {
      if (choice.uci == uci) return choice.label;
    }
    return uci.isEmpty ? null : uci;
  }

  bool get _canCommit =>
      completedScans.length == _scanLabels.length &&
      selectedFrom != null &&
      selectedTo != null &&
      confidence != null &&
      !answered;

  void _commit() {
    if (!_canCommit) return;
    final isCorrect =
        uciFromSquares(selectedFrom, selectedTo) == scenario.correctMoveUci;

    setState(() {
      answered = true;
      lastCorrect = isCorrect;
      if (isCorrect) {
        correct++;
      } else {
        mistakes++;
        patternMistakes[scenario.dangerPattern] =
            (patternMistakes[scenario.dangerPattern] ?? 0) + 1;
      }
      if (confidence == ConfidenceLevel.verySure) {
        highConfidenceAttempts++;
        if (!isCorrect) highConfidenceMistakes++;
      }
    });
  }

  void _next() {
    if (current >= scenarios.length - 1) {
      _finish();
      return;
    }

    setState(() {
      current++;
      selectedFrom = null;
      selectedTo = null;
      confidence = null;
      answered = false;
      lastCorrect = null;
      completedScans.clear();
    });
  }

  void _finish() {
    final result = TrainingResult(
      correct: correct,
      total: scenarios.length,
      correctBySkill: {Skill.moveSafety: correct},
      totalBySkill: {Skill.moveSafety: scenarios.length},
      exerciseIds: scenarios.map((e) => e.id).toList(),
      kind: SessionKind.blunderShield,
      mistakesBySkill: {Skill.moveSafety: mistakes},
      highConfidenceAttempts: highConfidenceAttempts,
      highConfidenceMistakes: highConfidenceMistakes,
      xpEarned: 30 + correct * 12,
      patternMistakes: Map<String, int>.from(patternMistakes),
    );
    Navigator.pop(context, result);
  }

  @override
  Widget build(BuildContext context) {
    final board = parseFenBoard(scenario.fen);
    final selectedLabel = _selectedMoveLabel();

    return Scaffold(
      appBar: AppBar(
        title: const Text('BlunderShield'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
          children: [
            Row(
              children: [
                Text(
                  '${current + 1}/${scenarios.length}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: LinearProgressIndicator(
                    value: (current + 1) / scenarios.length,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              scenario.title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              scenario.subtitle,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            InteractiveChessBoard(
              board: board,
              onSquareTap: _tapSquare,
              selectedFrom: selectedFrom,
              selectedTo: selectedTo,
              destinationSquares: _candidateDestinations(),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'BlunderShield scan',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Complete the scan before ChessSense lets you commit the move.',
                      style: TextStyle(fontSize: 12),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 7,
                      runSpacing: 7,
                      children: List.generate(_scanLabels.length, (index) {
                        return FilterChip(
                          label: Text(_scanLabels[index]),
                          selected: completedScans.contains(index),
                          onSelected: answered
                              ? null
                              : (selected) {
                                  setState(() {
                                    if (selected) {
                                      completedScans.add(index);
                                    } else {
                                      completedScans.remove(index);
                                    }
                                  });
                                },
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              selectedLabel == null
                  ? 'Tap the queen, then tap a destination.'
                  : 'Selected move: $selectedLabel',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            const Text(
              'How confident are you?',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 7),
            SegmentedButton<ConfidenceLevel>(
              segments: ConfidenceLevel.values
                  .map(
                    (value) => ButtonSegment(
                      value: value,
                      label: Text(
                        confidenceName(value),
                        style: const TextStyle(fontSize: 11),
                      ),
                    ),
                  )
                  .toList(),
              selected: confidence == null ? <ConfidenceLevel>{} : {confidence!},
              emptySelectionAllowed: true,
              onSelectionChanged: answered
                  ? null
                  : (selection) {
                      setState(() {
                        confidence = selection.isEmpty ? null : selection.first;
                      });
                    },
            ),
            const SizedBox(height: 14),
            if (!answered)
              FilledButton.icon(
                onPressed: _canCommit ? _commit : null,
                icon: const Icon(Icons.shield),
                label: const Text('Commit Move'),
              )
            else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lastCorrect == true ? '✓ Safe decision' : '✗ Blunder detected',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: lastCorrect == true
                              ? Colors.greenAccent
                              : Colors.redAccent,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text('Best move: ${scenario.correctMoveLabel}'),
                      const SizedBox(height: 6),
                      Text(scenario.explanation),
                      const SizedBox(height: 8),
                      Text(
                        'Pattern: ${scenario.dangerPattern}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _next,
                child: Text(
                  current == scenarios.length - 1 ? 'Finish Session' : 'Next Position',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
