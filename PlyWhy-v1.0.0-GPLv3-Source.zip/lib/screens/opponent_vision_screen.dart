import 'package:flutter/material.dart';

import '../content_repository.dart';
import '../fen_utils.dart';
import '../models.dart';
import '../widgets/interactive_chessboard.dart';

class OpponentVisionScreen extends StatefulWidget {
  final int skillScore;
  final List<String> recentExerciseIds;

  const OpponentVisionScreen({
    super.key,
    required this.skillScore,
    this.recentExerciseIds = const [],
  });

  @override
  State<OpponentVisionScreen> createState() => _OpponentVisionScreenState();
}

class _OpponentVisionScreenState extends State<OpponentVisionScreen> {
  List<InteractiveMoveScenario> scenarios = const [];
  bool loading = true;
  String? loadError;
  int current = 0;
  int correct = 0;
  int mistakes = 0;
  int highConfidenceAttempts = 0;
  int highConfidenceMistakes = 0;
  final Map<String, int> patternMistakes = <String, int>{};
  String? selectedFrom;
  String? selectedTo;
  ConfidenceLevel? confidence;
  bool answered = false;
  bool? lastCorrect;

  @override
  void initState() {
    super.initState();
    _loadSession();
  }

  Future<void> _loadSession() async {
    try {
      final loaded = await PuzzleContentRepository().buildOpponentVisionSession(
        skillScore: widget.skillScore,
        recentExerciseIds: widget.recentExerciseIds,
      );
      if (!mounted) return;
      setState(() {
        scenarios = loaded;
        loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        loadError = '$error';
        loading = false;
      });
    }
  }

  InteractiveMoveScenario get scenario => scenarios[current];

  Map<String, String> get board =>
      boardAfterUciMoves(scenario.fen, scenario.setupMovesUci);

  bool get _isLargePackScenario => scenario.id.startsWith('LCH_');

  void _tapSquare(String square) {
    if (answered) return;
    setState(() {
      if (selectedFrom == null) {
        selectedFrom = square;
        selectedTo = null;
      } else if (selectedFrom == square) {
        selectedFrom = null;
        selectedTo = null;
      } else {
        selectedTo = square;
      }
    });
  }

  bool get _canCommit =>
      selectedFrom != null &&
      selectedTo != null &&
      confidence != null &&
      !answered;

  void _commit() {
    if (!_canCommit) return;
    final isCorrect =
        uciFromSquares(selectedFrom, selectedTo) == scenario.correctMoveUci;

    setState(() {
      answered = true;
      lastCorrect = isCorrect;
      if (isCorrect) {
        correct++;
      } else {
        mistakes++;
        patternMistakes[scenario.dangerPattern] =
            (patternMistakes[scenario.dangerPattern] ?? 0) + 1;
      }
      if (confidence == ConfidenceLevel.verySure) {
        highConfidenceAttempts++;
        if (!isCorrect) highConfidenceMistakes++;
      }
    });
  }

  void _next() {
    if (current >= scenarios.length - 1) {
      _finish();
      return;
    }

    setState(() {
      current++;
      selectedFrom = null;
      selectedTo = null;
      confidence = null;
      answered = false;
      lastCorrect = null;
    });
  }

  void _finish() {
    Navigator.pop(
      context,
      TrainingResult(
        correct: correct,
        total: scenarios.length,
        correctBySkill: {Skill.opponentResponse: correct},
        totalBySkill: {Skill.opponentResponse: scenarios.length},
        exerciseIds: scenarios.map((e) => e.id).toList(),
        kind: SessionKind.opponentVision,
        mistakesBySkill: {Skill.opponentResponse: mistakes},
        highConfidenceAttempts: highConfidenceAttempts,
        highConfidenceMistakes: highConfidenceMistakes,
        xpEarned: 30 + correct * 12,
        patternMistakes: Map<String, int>.from(patternMistakes),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Opponent Vision'),
        centerTitle: true,
      ),
      body: SafeArea(child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (loading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Building your adaptive session…'),
            ],
          ),
        ),
      );
    }

    if (loadError != null || scenarios.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              const Text(
                'Could not load an Opponent Vision session.',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              if (loadError != null) ...[
                const SizedBox(height: 8),
                Text(loadError!, textAlign: TextAlign.center),
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  setState(() {
                    loading = true;
                    loadError = null;
                  });
                  _loadSession();
                },
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    final blackToMove = isBlackToMoveAfterUciMoves(
      scenario.fen,
      scenario.setupMovesUci.length,
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
      children: [
        Row(
          children: [
            Text(
              '${current + 1}/${scenarios.length}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: LinearProgressIndicator(
                value: (current + 1) / scenarios.length,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Center(
          child: Chip(
            avatar: Icon(
              _isLargePackScenario ? Icons.dataset_outlined : Icons.verified_outlined,
              size: 17,
            ),
            label: Text(
              _isLargePackScenario
                  ? '5,000-position adaptive pack'
                  : 'Curated fallback position',
              style: const TextStyle(fontSize: 11),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          scenario.title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 5),
        Text(
          scenario.subtitle,
          textAlign: TextAlign.center,
        ),
        if (scenario.setupMoveLabel != null) ...[
          const SizedBox(height: 8),
          Center(
            child: Chip(
              avatar: const Icon(Icons.history_toggle_off, size: 18),
              label: Text('Last move: ${scenario.setupMoveLabel}'),
            ),
          ),
        ],
        const SizedBox(height: 12),
        InteractiveChessBoard(
          board: board,
          onSquareTap: _tapSquare,
          selectedFrom: selectedFrom,
          selectedTo: selectedTo,
          flipped: blackToMove,
        ),
        const SizedBox(height: 8),
        Text(
          blackToMove ? 'Black to move' : 'White to move',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Text(
              'Play the opponent. Tap the piece first, then the destination square for the strongest response.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          selectedFrom == null
              ? 'No move selected'
              : selectedTo == null
                  ? 'From: $selectedFrom — choose a destination'
                  : 'Selected: $selectedFrom → $selectedTo',
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),
        const Text(
          'How confident are you?',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 7),
        SegmentedButton<ConfidenceLevel>(
          segments: ConfidenceLevel.values
              .map(
                (value) => ButtonSegment(
                  value: value,
                  label: Text(
                    confidenceName(value),
                    style: const TextStyle(fontSize: 11),
                  ),
                ),
              )
              .toList(),
          selected: confidence == null ? <ConfidenceLevel>{} : {confidence!},
          emptySelectionAllowed: true,
          onSelectionChanged: answered
              ? null
              : (selection) {
                  setState(() {
                    confidence = selection.isEmpty ? null : selection.first;
                  });
                },
        ),
        const SizedBox(height: 14),
        if (!answered)
          FilledButton.icon(
            onPressed: _canCommit ? _commit : null,
            icon: const Icon(Icons.visibility),
            label: const Text('Commit Opponent Response'),
          )
        else ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lastCorrect == true
                        ? '✓ You saw the response'
                        : '✗ Opponent response missed',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: lastCorrect == true
                          ? Colors.greenAccent
                          : Colors.redAccent,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('Best response: ${scenario.correctMoveLabel}'),
                  const SizedBox(height: 6),
                  Text(scenario.explanation),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.verified, size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          _isLargePackScenario
                              ? 'Source solution from the Lichess puzzle database; ChessSense filters ambiguous mate-in-1 positions.'
                              : scenario.validationStatus ==
                                      ValidationStatus.engineValidated
                                  ? 'This curated response was validated with Stockfish.'
                                  : 'Rules-validated scenario.',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _next,
            child: Text(
              current == scenarios.length - 1
                  ? 'Finish Session'
                  : 'Next Position',
            ),
          ),
        ],
      ],
    );
  }
}
