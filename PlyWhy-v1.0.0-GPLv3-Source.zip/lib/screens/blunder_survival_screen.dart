import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../fen_utils.dart';
import '../mode_content.dart';
import '../models.dart';
import '../widgets/interactive_chessboard.dart';

class BlunderSurvivalScreen extends StatefulWidget {
  const BlunderSurvivalScreen({super.key});

  @override
  State<BlunderSurvivalScreen> createState() => _BlunderSurvivalScreenState();
}

class _BlunderSurvivalScreenState extends State<BlunderSurvivalScreen> {
  late final List<SurvivalScenario> scenarios;
  int current = 0;
  int lives = 3;
  int correct = 0;
  int mistakes = 0;
  final Map<String, int> patternMistakes = <String, int>{};
  int secondsLeft = 5;
  bool answered = false;
  bool? lastCorrect;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    scenarios = [...blunderSurvivalScenarios]..shuffle(Random());
    scenarios.removeRange(10, scenarios.length);
    _startTimer();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  SurvivalScenario get scenario => scenarios[current];

  void _startTimer() {
    timer?.cancel();
    secondsLeft = 5;
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || answered) return;
      if (secondsLeft <= 1) {
        timer.cancel();
        _answer(null);
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  void _answer(bool? safeChoice) {
    if (answered) return;
    timer?.cancel();
    final isCorrect = safeChoice != null && safeChoice == scenario.isSafe;

    setState(() {
      answered = true;
      lastCorrect = isCorrect;
      if (isCorrect) {
        correct++;
      } else {
        mistakes++;
        lives = lives > 0 ? lives - 1 : 0;
        if (!scenario.isSafe) {
          patternMistakes[scenario.dangerPattern] =
              (patternMistakes[scenario.dangerPattern] ?? 0) + 1;
        }
      }
    });
  }

  void _next() {
    if (current >= scenarios.length - 1 || lives == 0) {
      _finish();
      return;
    }

    setState(() {
      current++;
      answered = false;
      lastCorrect = null;
      secondsLeft = 5;
    });
    _startTimer();
  }

  void _finish() {
    timer?.cancel();
    Navigator.pop(
      context,
      TrainingResult(
        correct: correct,
        total: current + 1,
        correctBySkill: {Skill.moveSafety: correct},
        totalBySkill: {Skill.moveSafety: current + 1},
        exerciseIds: scenarios.take(current + 1).map((e) => e.id).toList(),
        kind: SessionKind.blunderSurvival,
        mistakesBySkill: {Skill.moveSafety: mistakes},
        xpEarned: 20 + correct * 10 + lives * 5,
        survivalScore: correct,
        patternMistakes: Map<String, int>.from(patternMistakes),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final from = scenario.proposedMoveUci.substring(0, 2);
    final to = scenario.proposedMoveUci.substring(2, 4);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Blunder Survival'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Round ${current + 1}/${scenarios.length}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Row(
                  children: List.generate(
                    3,
                    (index) => Padding(
                      padding: const EdgeInsets.only(left: 3),
                      child: Icon(
                        index < lives ? Icons.favorite : Icons.favorite_border,
                        color: index < lives ? Colors.redAccent : null,
                        size: 22,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: answered ? 0 : secondsLeft / 5,
              minHeight: 8,
              borderRadius: BorderRadius.circular(999),
            ),
            const SizedBox(height: 6),
            Text(
              answered ? 'Decision locked' : '$secondsLeft seconds',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'SAFE or BLUNDER?',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            Text(
              'Proposed move: ${scenario.proposedMoveLabel}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 14),
            InteractiveChessBoard(
              board: parseFenBoard(scenario.fen),
              accentSquares: {from, to},
            ),
            const SizedBox(height: 16),
            if (!answered)
              Row(
                children: [
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed: () => _answer(true),
                      icon: const Icon(Icons.check_circle_outline),
                      label: const Text('SAFE'),
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 18),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => _answer(false),
                      icon: const Icon(Icons.warning_amber),
                      label: const Text('BLUNDER'),
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 18),
                      ),
                    ),
                  ),
                ],
              )
            else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lastCorrect == true ? '✓ Survived' : '✗ Life lost',
                        style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.bold,
                          color: lastCorrect == true
                              ? Colors.greenAccent
                              : Colors.redAccent,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(scenario.explanation),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _next,
                child: Text(
                  current >= scenarios.length - 1 || lives == 0
                      ? 'See Survival Result'
                      : 'Next Round',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
