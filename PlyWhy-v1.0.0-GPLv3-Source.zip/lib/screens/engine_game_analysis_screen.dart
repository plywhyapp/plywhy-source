import 'package:flutter/material.dart';

import '../engine_api.dart';
import '../engine_config.dart';
import '../engine_explanation.dart';
import '../fen_utils.dart';
import '../personal_game_analysis.dart';
import '../pattern_cards.dart';
import 'pattern_cards_screen.dart';
import '../widgets/interactive_chessboard.dart';

class EngineGameAnalysisScreen extends StatefulWidget {
  final PersonalGameAnalysis analysis;
  final EngineApiClient? client;
  final String? playerUsername;

  const EngineGameAnalysisScreen({
    super.key,
    required this.analysis,
    this.client,
    this.playerUsername,
  });

  @override
  State<EngineGameAnalysisScreen> createState() => _EngineGameAnalysisScreenState();
}

class _EngineGameAnalysisScreenState extends State<EngineGameAnalysisScreen> {
  EngineGameResult? _result;
  String? _error;
  bool _loading = false;

  bool get _configured => widget.client != null || EngineConfig.isConfigured;

  @override
  void initState() {
    super.initState();
    if (_configured) {
      _runAnalysis();
    }
  }

  Future<void> _runAnalysis() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final client = widget.client ?? EngineApiClient.forBaseUrl(EngineConfig.baseUrl);
      final result = await client.analyzeGame(widget.analysis);
      if (!mounted) return;
      setState(() {
        _result = result;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  bool? _playerIsWhite() {
    final username = widget.playerUsername?.trim().toLowerCase();
    if (username == null || username.isEmpty) return null;

    final game = widget.analysis.game;
    if (game.white.trim().toLowerCase() == username) return true;
    if (game.black.trim().toLowerCase() == username) return false;
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final game = widget.analysis.game;
    final playerSide = _playerIsWhite();

    return Scaffold(
      appBar: AppBar(title: const Text('ChessSense Game Review')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              '${game.white} vs ${game.black}',
              style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text('${game.result} · ${game.fullMoveCount} moves'),
            if (playerSide != null) ...[
              const SizedBox(height: 4),
              Text(
                'Reviewing ${widget.playerUsername} · ${playerSide ? 'White' : 'Black'}',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ],
            const SizedBox(height: 16),
            if (!_configured) ...[
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Engine service not configured yet',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'ChessSense is ready to use a remote engine API, but Stockfish is intentionally not bundled inside the Android app. This keeps the engine separated from the proprietary app architecture.',
                      ),
                    ],
                  ),
                ),
              ),
            ] else if (_loading) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 12),
              const Text('Analyzing your game and finding the moments that matter...'),
            ] else if (_error != null) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Engine analysis failed',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(_error!),
                      const SizedBox(height: 12),
                      FilledButton(
                        onPressed: _runAnalysis,
                        child: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              ),
            ] else if (_result != null) ...[
              _AnalysisContent(
                result: _result!,
                analysis: widget.analysis,
                playerIsWhite: playerSide,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

enum _BoardViewMode {
  before,
  after,
  better,
  reply,
}

class _AnalysisContent extends StatefulWidget {
  final EngineGameResult result;
  final PersonalGameAnalysis analysis;
  final bool? playerIsWhite;

  const _AnalysisContent({
    required this.result,
    required this.analysis,
    required this.playerIsWhite,
  });

  @override
  State<_AnalysisContent> createState() => _AnalysisContentState();
}

class _AnalysisContentState extends State<_AnalysisContent> {
  int _reviewIndex = 0;
  _BoardViewMode _boardView = _BoardViewMode.before;

  bool _belongsToPlayer(EngineMoveResult move) {
    if (widget.playerIsWhite == null) return true;
    final contextMove = {
      for (final m in widget.analysis.moves) m.plyIndex: m,
    }[move.plyIndex];

    final isWhiteMove = contextMove != null ? contextMove.isWhiteMove : move.plyIndex.isEven;
    return isWhiteMove == widget.playerIsWhite;
  }

  bool _isReviewMove(EngineMoveResult move) {
    return move.quality == EngineMoveQuality.inaccuracy ||
        move.quality == EngineMoveQuality.mistake ||
        move.quality == EngineMoveQuality.blunder;
  }

  void _moveReview(int delta, int reviewCount) {
    final next = _reviewIndex + delta;
    if (next < 0 || next >= reviewCount) return;
    setState(() {
      _reviewIndex = next;
      _boardView = _BoardViewMode.before;
    });
  }

  @override
  Widget build(BuildContext context) {
    final moveContext = {
      for (final move in widget.analysis.moves) move.plyIndex: move,
    };
    final playerMoves = widget.result.moves.where(_belongsToPlayer).toList(growable: false);
    final reviewMoves = playerMoves.where(_isReviewMove).toList(growable: false);

    if (reviewMoves.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SummaryCard(moves: playerMoves),
          const SizedBox(height: 14),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'No engine-classified inaccuracies, mistakes, or blunders were found in the moves being reviewed.',
              ),
            ),
          ),
        ],
      );
    }

    final safeIndex = _reviewIndex.clamp(0, reviewMoves.length - 1).toInt();
    final move = reviewMoves[safeIndex];
    final contextMove = moveContext[move.plyIndex];

    if (contextMove == null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SummaryCard(moves: playerMoves),
          const SizedBox(height: 14),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('ChessSense could not reconstruct this review position.'),
            ),
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Review moment ${safeIndex + 1} of ${reviewMoves.length}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            Text(
              engineMoveQualityLabel(move.quality),
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        const Text(
          'Keep the board and the explanation together. Switch views to see what happened, the stronger move, and the reply you needed to anticipate.',
          style: TextStyle(fontSize: 13),
        ),
        const SizedBox(height: 10),
        _SynchronizedBoard(
          move: move,
          contextMove: contextMove,
          playerIsWhite: widget.playerIsWhite,
          mode: _boardView,
          onModeChanged: (mode) => setState(() => _boardView = mode),
        ),
        const SizedBox(height: 10),
        _MoveExplanationCard(move: move, contextMove: contextMove),
        const SizedBox(height: 10),
        FilledButton.icon(
          key: const ValueKey('study-pattern-cards'),
          icon: const Icon(Icons.style_outlined),
          label: const Text('Study these Pattern Cards'),
          onPressed: () {
            final cards = const PatternCardBuilder().fromGame(
              analysis: widget.analysis,
              result: widget.result,
              playerIsWhite: widget.playerIsWhite,
            );
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PatternCardsScreen(newCards: cards),
              ),
            );
          },
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: safeIndex == 0
                    ? null
                    : () => _moveReview(-1, reviewMoves.length),
                icon: const Icon(Icons.chevron_left),
                label: const Text('Previous mistake'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: safeIndex >= reviewMoves.length - 1
                    ? null
                    : () => _moveReview(1, reviewMoves.length),
                icon: const Icon(Icons.chevron_right),
                label: const Text('Next mistake'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        _SummaryCard(moves: playerMoves),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final List<EngineMoveResult> moves;

  const _SummaryCard({required this.moves});

  @override
  Widget build(BuildContext context) {
    final blunders = moves.where((move) => move.quality == EngineMoveQuality.blunder).length;
    final mistakes = moves.where((move) => move.quality == EngineMoveQuality.mistake).length;
    final inaccuracies = moves.where((move) => move.quality == EngineMoveQuality.inaccuracy).length;
    int severity(EngineMoveResult move) => switch (move.quality) {
      EngineMoveQuality.blunder => 3,
      EngineMoveQuality.mistake => 2,
      EngineMoveQuality.inaccuracy => 1,
      _ => 0,
    };
    EngineMoveResult? worst;
    for (final move in moves) {
      if (severity(move) == 0) continue;
      if (worst == null ||
          severity(move) > severity(worst) ||
          (severity(move) == severity(worst) && move.lossCp > worst.lossCp)) {
        worst = move;
      }
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Your review summary',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('$blunders blunders · $mistakes mistakes · $inaccuracies inaccuracies'),
            if (worst != null) ...[
              const SizedBox(height: 8),
              Text('Most important moment: ${worst.san}'),
            ],
          ],
        ),
      ),
    );
  }
}

class _SynchronizedBoard extends StatelessWidget {
  final EngineMoveResult move;
  final PersonalGameMove contextMove;
  final bool? playerIsWhite;
  final _BoardViewMode mode;
  final ValueChanged<_BoardViewMode> onModeChanged;

  const _SynchronizedBoard({
    required this.move,
    required this.contextMove,
    required this.playerIsWhite,
    required this.mode,
    required this.onModeChanged,
  });

  bool get _hasReply => (move.opponentBestReplyUci?.trim().isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    final boardState = _boardStateForMode();
    final flipped = playerIsWhite == false ||
        (playerIsWhite == null && !contextMove.isWhiteMove);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              contextMove.moveLabel,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            InteractiveChessBoard(
              key: const ValueKey('pedagogical-review-board'),
              board: boardState.board,
              flipped: flipped,
              selectedFrom: boardState.from,
              selectedTo: boardState.to,
              arrows: boardState.arrows,
            ),
            const SizedBox(height: 10),
            Text(
              boardState.caption,
              key: const ValueKey('pedagogical-board-caption'),
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                ChoiceChip(
                  label: const Text('Before move'),
                  selected: mode == _BoardViewMode.before,
                  onSelected: (_) => onModeChanged(_BoardViewMode.before),
                ),
                ChoiceChip(
                  label: const Text('After your move'),
                  selected: mode == _BoardViewMode.after,
                  onSelected: (_) => onModeChanged(_BoardViewMode.after),
                ),
                ChoiceChip(
                  label: const Text('Better move'),
                  selected: mode == _BoardViewMode.better,
                  onSelected: (_) => onModeChanged(_BoardViewMode.better),
                ),
                if (_hasReply)
                  ChoiceChip(
                    label: const Text('Opponent reply'),
                    selected: mode == _BoardViewMode.reply,
                    onSelected: (_) => onModeChanged(_BoardViewMode.reply),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  _BoardState _boardStateForMode() {
    switch (mode) {
      case _BoardViewMode.before:
        return _BoardState(
          board: parseFenBoard(contextMove.fenBefore),
          caption: 'Position before ${contextMove.moveLabel}. Your move was ${contextMove.san}.',
        );
      case _BoardViewMode.after:
        final actualMove = _inferMoveSquares(
          contextMove.fenBefore,
          contextMove.fenAfter,
          contextMove.isWhiteMove,
        );
        return _BoardState(
          board: parseFenBoard(contextMove.fenAfter),
          caption: 'Position immediately after your move ${contextMove.san}.',
          from: actualMove.$1,
          to: actualMove.$2,
          arrows: _arrowForSquares(
            actualMove,
            const Color(0xD9D8A21B),
          ),
        );
      case _BoardViewMode.better:
        return _applyMoveSafely(
          fen: contextMove.fenBefore,
          uci: move.bestMoveUci,
          caption: 'Stronger choice: ${humanizeUciMove(contextMove.fenBefore, move.bestMoveUci)}.',
        );
      case _BoardViewMode.reply:
        final reply = move.opponentBestReplyUci?.trim() ?? '';
        if (reply.isEmpty) {
          return _BoardState(
            board: parseFenBoard(contextMove.fenAfter),
            caption: 'No concrete opponent reply was returned for this position.',
          );
        }
        return _applyMoveSafely(
          fen: contextMove.fenAfter,
          uci: reply,
          caption: 'Opponent reply to anticipate: ${humanizeUciMove(contextMove.fenAfter, reply)}.',
        );
    }
  }

  _BoardState _applyMoveSafely({
    required String fen,
    required String uci,
    required String caption,
  }) {
    try {
      final board = boardAfterUciMoves(fen, [uci]);
      final squares = _uciSquares(uci);
      final arrowColor = mode == _BoardViewMode.reply
          ? const Color(0xD9D64545)
          : const Color(0xD92F7D32);
      return _BoardState(
        board: board,
        caption: caption,
        from: squares.$1,
        to: squares.$2,
        arrows: _arrowForSquares(squares, arrowColor),
      );
    } on FormatException {
      return _BoardState(
        board: parseFenBoard(fen),
        caption: caption,
      );
    }
  }
}

class _BoardState {
  final Map<String, String> board;
  final String caption;
  final String? from;
  final String? to;
  final List<BoardArrow> arrows;

  const _BoardState({
    required this.board,
    required this.caption,
    this.from,
    this.to,
    this.arrows = const [],
  });
}

(String?, String?) _uciSquares(String uci) {
  final clean = uci.trim();
  if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(clean)) {
    return (null, null);
  }
  return (clean.substring(0, 2), clean.substring(2, 4));
}

List<BoardArrow> _arrowForSquares(
  (String?, String?) squares,
  Color color,
) {
  final from = squares.$1;
  final to = squares.$2;
  if (from == null || to == null) return const [];
  return [BoardArrow(from: from, to: to, color: color)];
}

(String?, String?) _inferMoveSquares(
  String fenBefore,
  String fenAfter,
  bool moverIsWhite,
) {
  final before = parseFenBoard(fenBefore);
  final after = parseFenBoard(fenAfter);
  final moverPieces = moverIsWhite
      ? const {'♔', '♕', '♖', '♗', '♘', '♙'}
      : const {'♚', '♛', '♜', '♝', '♞', '♟'};
  final king = moverIsWhite ? '♔' : '♚';

  final removed = <String>[];
  final added = <String>[];

  for (final file in 'abcdefgh'.split('')) {
    for (var rank = 1; rank <= 8; rank++) {
      final square = '$file$rank';
      final beforePiece = before[square];
      final afterPiece = after[square];

      if (beforePiece != afterPiece &&
          beforePiece != null &&
          moverPieces.contains(beforePiece)) {
        removed.add(square);
      }
      if (beforePiece != afterPiece &&
          afterPiece != null &&
          moverPieces.contains(afterPiece)) {
        added.add(square);
      }
    }
  }

  if (removed.isEmpty || added.isEmpty) return (null, null);

  if (removed.length > 1 || added.length > 1) {
    String? kingFrom;
    String? kingTo;
    for (final square in removed) {
      if (before[square] == king) {
        kingFrom = square;
        break;
      }
    }
    for (final square in added) {
      if (after[square] == king) {
        kingTo = square;
        break;
      }
    }
    if (kingFrom != null && kingTo != null) return (kingFrom, kingTo);
  }

  return (removed.first, added.first);
}

class _MoveExplanationCard extends StatelessWidget {
  final EngineMoveResult move;
  final PersonalGameMove contextMove;

  const _MoveExplanationCard({
    required this.move,
    required this.contextMove,
  });

  @override
  Widget build(BuildContext context) {
    final explanation = buildEngineMoveExplanation(move, contextMove);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${contextMove.moveLabel} · ${engineMoveQualityLabel(move.quality)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 12),
            _ExplanationSection(
              title: '1. Concrete mistake',
              text: explanation.whatFailed,
            ),
            _ExplanationSection(
              title: '2. Position change & opponent gain',
              text: explanation.whyItWorks,
            ),
            _ExplanationSection(
              title: '3. Strongest reply',
              text: explanation.opponentPunishment,
            ),
            _ExplanationSection(
              title: '4. Verifiable consequence',
              text: explanation.consequence,
            ),
            _ExplanationSection(
              title: '5. Better choice comparison',
              text: explanation.betterChoice,
            ),
            _ExplanationSection(
              title: '6. Chess principle · ${explanation.lessonTitle}',
              text: explanation.lessonText,
            ),
            _ExplanationSection(
              title: '7. Reflection question',
              text: explanation.reflectionQuestion,
              last: true,
            ),
          ],
        ),
      ),
    );
  }
}

class _ExplanationSection extends StatelessWidget {
  final String title;
  final String text;
  final bool last;

  const _ExplanationSection({
    required this.title,
    required this.text,
    this.last = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: last ? 0 : 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(text),
        ],
      ),
    );
  }
}
