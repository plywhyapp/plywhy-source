import 'package:flutter/material.dart';

import '../adaptive_training.dart';
import '../exercise_bank.dart';
import '../models.dart';
import '../profile_logic.dart';
import '../widgets/exercise_page.dart';

class DailyTrainingScreen extends StatefulWidget {
  final Map<Skill, int> skillScores;
  final List<String> recentExerciseIds;

  const DailyTrainingScreen({
    super.key,
    required this.skillScores,
    this.recentExerciseIds = const [],
  });

  @override
  State<DailyTrainingScreen> createState() => _DailyTrainingScreenState();
}

class _DailyTrainingScreenState extends State<DailyTrainingScreen> {
  late final List<Exercise> trainingExercises;

  int current = 0;
  int? selected;
  int correct = 0;
  bool finished = false;

  final Map<Skill, int> correctBySkill = {
    for (final skill in Skill.values) skill: 0,
  };

  final Map<Skill, int> totalBySkill = {
    for (final skill in Skill.values) skill: 0,
  };

  @override
  void initState() {
    super.initState();
    trainingExercises = buildAdaptiveSession(
      scores: widget.skillScores,
      exerciseBank: exerciseBank,
      recentExerciseIds: widget.recentExerciseIds,
    );

    for (final exercise in trainingExercises) {
      totalBySkill[exercise.skill] = (totalBySkill[exercise.skill] ?? 0) + 1;
    }
  }

  void _chooseAnswer(int index) {
    if (selected != null) return;

    final exercise = trainingExercises[current];
    setState(() {
      selected = index;
      if (index == exercise.correctIndex) {
        correct++;
        correctBySkill[exercise.skill] = (correctBySkill[exercise.skill] ?? 0) + 1;
      }
    });
  }

  void _next() {
    if (current < trainingExercises.length - 1) {
      setState(() {
        current++;
        selected = null;
      });
      return;
    }

    setState(() {
      finished = true;
    });
  }

  TrainingResult _result() {
    return TrainingResult(
      correct: correct,
      total: trainingExercises.length,
      correctBySkill: Map<Skill, int>.from(correctBySkill),
      totalBySkill: Map<Skill, int>.from(totalBySkill),
      exerciseIds: trainingExercises.map((exercise) => exercise.id).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (finished) {
      final result = _result();
      final updatedScores = updateSkillScores(
        previousScores: widget.skillScores,
        result: result,
      );
      final oldRating = calculateChessSenseRating(widget.skillScores);
      final newRating = calculateChessSenseRating(updatedScores);

      return Scaffold(
        appBar: AppBar(
          title: const Text('Daily Sense'),
          centerTitle: true,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.check_circle_outline, size: 72),
                const SizedBox(height: 16),
                const Text(
                  'Training Complete',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Text(
                  '${result.correct} / ${result.total}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 46, fontWeight: FontWeight.bold),
                ),
                Text(
                  '${result.accuracy}% accuracy',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 22),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('ChessSense Rating'),
                        Text(
                          '$oldRating → $newRating',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Session by Skill',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                ...Skill.values.where((skill) => (totalBySkill[skill] ?? 0) > 0).map(
                  (skill) {
                    final total = totalBySkill[skill] ?? 0;
                    final skillCorrect = correctBySkill[skill] ?? 0;
                    final percent = total == 0 ? 0 : ((skillCorrect / total) * 100).round();
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(skillName(skill)),
                      trailing: Text('$skillCorrect/$total  ($percent%)'),
                    );
                  },
                ),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () => Navigator.pop(context, result),
                  child: const Text('Save Session & Return Home'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final exercise = trainingExercises[current];
    return ExercisePage(
      title: 'Daily Sense',
      currentNumber: current + 1,
      totalNumber: trainingExercises.length,
      exercise: exercise,
      selected: selected,
      onSelect: _chooseAnswer,
      onNext: _next,
      finalButton: current == trainingExercises.length - 1 ? 'See Results' : 'Next',
    );
  }
}
