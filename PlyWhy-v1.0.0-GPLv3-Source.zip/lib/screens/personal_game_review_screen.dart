import 'package:flutter/material.dart';

import '../fen_utils.dart';
import '../personal_game_analysis.dart';
import '../widgets/interactive_chessboard.dart';

class PersonalGameReviewScreen extends StatefulWidget {
  final PersonalGameAnalysis analysis;

  const PersonalGameReviewScreen({
    super.key,
    required this.analysis,
  });

  @override
  State<PersonalGameReviewScreen> createState() =>
      _PersonalGameReviewScreenState();
}

class _PersonalGameReviewScreenState extends State<PersonalGameReviewScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final reviewMoves = widget.analysis.annotatedReviewMoves;

    if (reviewMoves.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('My Game Review')),
        body: const SafeArea(
          child: Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'This PGN has no moves marked ?, ??, or ?!. ChessSense will not invent a blunder without evidence.',
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      );
    }

    final move = reviewMoves[_index];
    final severity = move.mistakeSeverity!;
    final board = parseFenBoard(move.fenBefore);
    final blackToMove = move.fenBefore.split(RegExp(r'\s+'))[1] == 'b';

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.analysis.game.white} vs ${widget.analysis.game.black}'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Review ${_index + 1} of ${reviewMoves.length}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                _SeverityChip(severity: severity),
              ],
            ),
            const SizedBox(height: 10),
            InteractiveChessBoard(
              board: board,
              flipped: blackToMove,
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      move.moveLabel,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${pgnMistakeLabel(severity)} · marked ${move.annotation} in the imported PGN',
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Rewind your thinking',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    const _ChecklistLine('What changed after the opponent\'s last move?'),
                    const _ChecklistLine('What is threatened?'),
                    const _ChecklistLine('Checks, captures, and loose pieces?'),
                    const _ChecklistLine('What is the opponent\'s strongest reply?'),
                    const _ChecklistLine('Is my intended move still safe?'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Source: PGN annotation. ChessSense reconstructs the exact board position locally; this screen does not claim an engine best move.',
              style: TextStyle(fontSize: 11),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _index == 0
                        ? null
                        : () => setState(() => _index--),
                    icon: const Icon(Icons.chevron_left),
                    label: const Text('Previous'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _index >= reviewMoves.length - 1
                        ? null
                        : () => setState(() => _index++),
                    icon: const Icon(Icons.chevron_right),
                    label: const Text('Next'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SeverityChip extends StatelessWidget {
  final PgnMistakeSeverity severity;

  const _SeverityChip({required this.severity});

  @override
  Widget build(BuildContext context) {
    final text = switch (severity) {
      PgnMistakeSeverity.blunder => 'BLUNDER',
      PgnMistakeSeverity.mistake => 'MISTAKE',
      PgnMistakeSeverity.dubious => 'DUBIOUS',
    };

    return Chip(
      visualDensity: VisualDensity.compact,
      label: Text(
        text,
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _ChecklistLine extends StatelessWidget {
  final String text;

  const _ChecklistLine(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(Icons.check_box_outline_blank, size: 18),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
