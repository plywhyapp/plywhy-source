class EngineConfig {
  static const String baseUrl = String.fromEnvironment(
    'CHESSSENSE_ENGINE_API_URL',
    defaultValue: 'http://10.0.2.2:8787',
  );

  static bool get isConfigured => baseUrl.trim().isNotEmpty;
}
