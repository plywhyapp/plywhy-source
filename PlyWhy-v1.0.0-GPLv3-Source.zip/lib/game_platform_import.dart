import 'dart:convert';
import 'dart:io';

class GamePlatformImportException implements Exception {
  final String message;
  final int? statusCode;

  const GamePlatformImportException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class GamePlatformHttpResponse {
  final int statusCode;
  final String body;

  const GamePlatformHttpResponse({
    required this.statusCode,
    required this.body,
  });
}

abstract class GamePlatformTransport {
  Future<GamePlatformHttpResponse> get(
    Uri uri, {
    Map<String, String> headers = const {},
  });
}

class IoGamePlatformTransport implements GamePlatformTransport {
  final Duration timeout;
  final HttpClient _client;

  IoGamePlatformTransport({
    this.timeout = const Duration(seconds: 30),
    HttpClient? client,
  }) : _client = client ?? HttpClient();

  @override
  Future<GamePlatformHttpResponse> get(
    Uri uri, {
    Map<String, String> headers = const {},
  }) async {
    final request = await _client.getUrl(uri).timeout(timeout);
    request.headers.set(
      HttpHeaders.userAgentHeader,
      'ChessSense/0.1 Android',
    );
    headers.forEach(request.headers.set);

    final response = await request.close().timeout(timeout);
    final body = await utf8.decoder.bind(response).join();
    return GamePlatformHttpResponse(
      statusCode: response.statusCode,
      body: body,
    );
  }

  void close() => _client.close(force: true);
}

class OnlineGameImportService {
  final GamePlatformTransport transport;

  const OnlineGameImportService({required this.transport});

  factory OnlineGameImportService.io() {
    return OnlineGameImportService(transport: IoGamePlatformTransport());
  }

  Future<String> fetchLichessPgn(
    String username, {
    int maxGames = 20,
  }) async {
    final clean = username.trim();
    if (clean.isEmpty) {
      throw const GamePlatformImportException('Enter a Lichess username.');
    }

    final primary = Uri.https(
      'lichess.org',
      '/api/games/user/$clean',
      {
        'max': '$maxGames',
        'moves': 'true',
        'clocks': 'false',
        'evals': 'false',
        'opening': 'false',
      },
    );

    final first = await transport.get(
      primary,
      headers: const {'Accept': 'application/x-chess-pgn'},
    );

    if (first.statusCode >= 200 && first.statusCode < 300) {
      return _requirePgn(first.body, 'Lichess');
    }

    // Lichess has historically exposed the same export through /games/export.
    // Keep this sequential fallback so a transient route change does not block
    // the user's game import flow.
    final fallback = Uri.https(
      'lichess.org',
      '/games/export/$clean',
      {'max': '$maxGames'},
    );
    final second = await transport.get(
      fallback,
      headers: const {'Accept': 'application/x-chess-pgn'},
    );

    if (second.statusCode >= 200 && second.statusCode < 300) {
      return _requirePgn(second.body, 'Lichess');
    }

    throw GamePlatformImportException(
      _httpMessage('Lichess', second.statusCode, second.body),
      statusCode: second.statusCode,
    );
  }

  Future<String> fetchChessComPgn(
    String username, {
    int maxGames = 20,
  }) async {
    final clean = username.trim().toLowerCase();
    if (clean.isEmpty) {
      throw const GamePlatformImportException('Enter a Chess.com username.');
    }

    final archivesUri = Uri.https(
      'api.chess.com',
      '/pub/player/$clean/games/archives',
    );
    final archivesResponse = await transport.get(
      archivesUri,
      headers: const {'Accept': 'application/json'},
    );

    if (archivesResponse.statusCode < 200 ||
        archivesResponse.statusCode >= 300) {
      throw GamePlatformImportException(
        _httpMessage(
          'Chess.com',
          archivesResponse.statusCode,
          archivesResponse.body,
        ),
        statusCode: archivesResponse.statusCode,
      );
    }

    final decoded = _decodeObject(archivesResponse.body, 'Chess.com');
    final rawArchives = decoded['archives'];
    if (rawArchives is! List || rawArchives.isEmpty) {
      throw const GamePlatformImportException(
        'Chess.com returned no finished game archives for this username.',
      );
    }

    final archives = rawArchives
        .whereType<String>()
        .map(Uri.parse)
        .toList(growable: false);
    final collected = <String>[];

    // Requests remain strictly sequential. Chess.com explicitly recommends
    // serial PubAPI access to avoid rate limiting.
    for (final archive in archives.reversed) {
      final response = await transport.get(
        archive,
        headers: const {'Accept': 'application/json'},
      );
      if (response.statusCode < 200 || response.statusCode >= 300) {
        if (response.statusCode == 429) {
          throw const GamePlatformImportException(
            'Chess.com is rate limiting requests. Wait a minute and try again.',
            statusCode: 429,
          );
        }
        continue;
      }

      final month = _decodeObject(response.body, 'Chess.com');
      final games = month['games'];
      if (games is! List) continue;

      for (final item in games.reversed) {
        if (item is! Map) continue;
        final pgn = item['pgn']?.toString().trim();
        if (pgn == null || pgn.isEmpty) continue;
        collected.add(pgn);
        if (collected.length >= maxGames) break;
      }
      if (collected.length >= maxGames) break;
    }

    if (collected.isEmpty) {
      throw const GamePlatformImportException(
        'Chess.com returned no playable PGN games for this username.',
      );
    }

    return collected.join('\n\n');
  }

  static Map<String, dynamic> _decodeObject(String body, String platform) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map) {
        return Map<String, dynamic>.from(decoded);
      }
    } catch (_) {
      // Fall through to the explicit platform error below.
    }
    throw GamePlatformImportException('$platform returned invalid data.');
  }

  static String _requirePgn(String body, String platform) {
    final trimmed = body.trim();
    if (trimmed.isEmpty || !trimmed.contains('[Event ')) {
      throw GamePlatformImportException(
        '$platform returned no playable PGN games for this username.',
      );
    }
    return trimmed;
  }

  static String _httpMessage(String platform, int statusCode, String body) {
    if (statusCode == 404) {
      return '$platform username was not found, or the public games endpoint is unavailable.';
    }
    if (statusCode == 429) {
      return '$platform is rate limiting requests. Wait a minute and try again.';
    }
    final trimmed = body.trim();
    if (trimmed.isNotEmpty && trimmed.length <= 160) {
      return '$platform returned HTTP $statusCode: $trimmed';
    }
    return '$platform returned HTTP $statusCode.';
  }
}
