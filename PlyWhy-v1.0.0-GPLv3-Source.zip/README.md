# PlyWhy? — On-Device Chess Tactical Training

PlyWhy? is an Android chess training application for improving candidate move scanning, threat detection, and move safety on-device.

## Features

- **BlunderShield:** Core 5-point tactical move safety scanner.
- **Daily Sense:** Adaptive daily exercises tailored to performance history.
- **Opponent Vision:** 5,000-position tactical puzzle pack.
- **Blunder Survival:** Fast 3-life tactical speed challenge.
- **My Games:** Public game import from Lichess and Chess.com over HTTPS.
- **On-Device Analysis:** Embedded Stockfish 18 C++ engine (`libstockfish.so`) calculates evaluations locally without cloud dependencies.

## Open Source & Licensing

PlyWhy? is free software distributed under the terms of the **GNU General Public License Version 3 (GPLv3)**. See the `LICENSE` file in the project root for full terms.

### Third-Party Licenses and Attribution

- **Stockfish 18 Engine:** GNU General Public License v3 (GPLv3) — Copyright (C) 2008-2026 Stockfish developers.
- **Flutter Framework & Dart SDK:** BSD 3-Clause License — Copyright 2014 The Flutter Authors.
- **chess.dart Library:** MIT License — Copyright (c) 2019 Dhaval Patel.
- **Chessnut Vector Piece Assets:** Apache License Version 2.0 (`assets/pieces/chessnut/LICENSE.txt`).
- **Lichess 5,000 Puzzle Dataset:** Creative Commons CC0 Public Domain (`assets/content/lichess_puzzles_5000.json`).

## Reproducible Source Build Instructions

See `docs/BUILDING_STOCKFISH_SOURCE.md` for step-by-step NDK, Gradle, and signing credential build instructions.

## Source release identification

This archive corresponds to PlyWhy? Android production source release 1.0.0+1, prepared from the project version used for the signed AAB reported on 28 October 2026. The AAB has SHA-256 `3ffda09ad540c7c025b2558897e5e1b117fc57a86ef503ea747f1869ea62f287`. This identifies the intended release; it is not a claim of bit-for-bit reproducibility.
