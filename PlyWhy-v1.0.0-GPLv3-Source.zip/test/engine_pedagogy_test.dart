import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'helpers/chess_fixture_validator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('Phase 2B - Verified Pedagogical Accuracy Unit Tests with Executable Fixture Validation', () {
    const fixtureValidator = ChessFixtureValidator();

    test('1. Good vs Bad King Moves in Endgames', () {
      const fenBefore = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';

      // Good King Move 44... Kb5
      const fenAfterKb5 = '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';
      final valKb5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kb5',
        fenAfter: fenAfterKb5,
        opponentReplyUci: 'b3a2',
      );
      expect(valKb5.isValid, isTrue, reason: valKb5.error);

      const moveKb5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kb5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKb5,
        annotation: '',
      );

      final resKb5 = EngineMoveResult(
        plyIndex: 87,
        san: 'Kb5',
        bestMoveUci: 'c5b5',
        bestMoveSan: 'Kb5',
        evalBeforeCp: -2140,
        evalAfterCp: null,
        lossCp: 0,
        quality: EngineMoveQuality.best,
        opponentBestReplyUci: 'b3a2',
      );

      final expKb5 = buildEngineMoveExplanation(resKb5, moveKb5);
      expect(expKb5.whatFailed, contains('unconfirmed'));
      expect(expKb5.betterChoice, contains('unconfirmed'));

      // Bad King Move 44... Kd5
      const fenAfterKd5 = '8/8/8/p2k1p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';
      final valKd5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kd5',
        fenAfter: fenAfterKd5,
        opponentReplyUci: 'b3a4',
      );
      expect(valKd5.isValid, isTrue, reason: valKd5.error);

      const moveKd5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kd5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKd5,
        annotation: '',
      );

      final resKd5 = EngineMoveResult(
        plyIndex: 87,
        san: 'Kd5',
        bestMoveUci: 'c5b5',
        bestMoveSan: 'Kb5',
        evalBeforeCp: -4865,
        evalAfterCp: -3097,
        lossCp: 1768,
        quality: EngineMoveQuality.blunder,
        opponentBestReplyUci: 'b3a4',
      );

      final expKd5 = buildEngineMoveExplanation(resKd5, moveKd5);
      expect(expKd5.whatFailed, isNot(contains('top recommended move')));
      expect(expKd5.betterChoice, contains('Instead of Kd5, Stockfish preferred'));
    });

    test('2. Favorable vs Unfavorable Captures with Validated Legal Board Position', () {
      // Scandinavian Defense: 1. e4 d5 2. exd5 Qxd5 (Black Queen captures d5, allowing Nc3 tempo)
      const fenBefore = 'rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2';
      const fenAfter = 'rnb1kbnr/ppp1pppp/8/3q4/8/8/PPPP1PPP/RNBQKBNR w KQkq - 0 3';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Qxd5',
        fenAfter: fenAfter,
        opponentReplyUci: 'b1c3', // Nc3 attacks Black queen on d5!
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveQxd5 = PersonalGameMove(
        plyIndex: 3,
        moveNumber: 2,
        isWhiteMove: false,
        san: 'Qxd5',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?!',
      );

      final resQxd5 = EngineMoveResult(
        plyIndex: 3,
        san: 'Qxd5',
        bestMoveUci: 'g8f6',
        bestMoveSan: 'Nf6',
        evalBeforeCp: 30,
        evalAfterCp: 80,
        lossCp: 50,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'b1c3',
      );

      final expQxd5 = buildEngineMoveExplanation(resQxd5, moveQxd5);
      expect(expQxd5.whatFailed, contains('allowed the opponent to attack your queen'));
      expect(expQxd5.betterChoice, contains('Instead of Qxd5, Stockfish preferred'));
    });

    test('3. Real Knight Fork Detection on Validated Legal FEN Position', () {
      // Nxc7+ from d5 forking King on e8 and Rook on a8
      const fenBefore = 'r3kbnr/ppp1pppp/2n5/3N4/8/8/PPPP1PPP/R1BQKBNR w KQkq - 0 5';
      const fenAfter = 'r3kbnr/ppN1pppp/2n5/8/8/8/PPPP1PPP/R1BQKBNR b KQkq - 0 5'; // Halfmove clock = 0 after capture!

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Nxc7+',
        fenAfter: fenAfter,
        opponentReplyUci: 'e8d8',
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveNc7 = PersonalGameMove(
        plyIndex: 10,
        moveNumber: 6,
        isWhiteMove: true,
        san: 'Nxc7+',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '!',
      );

      final resNc7 = EngineMoveResult(
        plyIndex: 10,
        san: 'Nxc7+',
        bestMoveUci: 'd5c7',
        bestMoveSan: 'Nxc7+',
        evalBeforeCp: 350,
        evalAfterCp: 350,
        lossCp: 0,
        quality: EngineMoveQuality.best,
        opponentBestReplyUci: 'e8d8',
      );

      final expNc7 = buildEngineMoveExplanation(resNc7, moveNc7);
      expect(expNc7.whatFailed, contains('top recommended move'));
      expect(expNc7.betterChoice, contains('Stockfish confirmed Nxc7+ as the best move'));
    });

    test('4. Defended Pieces vs Loose / Hanging Pieces on Validated FEN Position', () {
      // Na5 from c6 leaves e5 pawn hanging
      const fenBefore = 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3';
      const fenAfter = 'r1bqkbnr/pppp1ppp/8/n3p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Na5',
        fenAfter: fenAfter,
        opponentReplyUci: 'f3e5',
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveHang = PersonalGameMove(
        plyIndex: 6,
        moveNumber: 4,
        isWhiteMove: false,
        san: 'Na5',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?',
      );

      final resHang = EngineMoveResult(
        plyIndex: 6,
        san: 'Na5',
        bestMoveUci: 'g8f6',
        bestMoveSan: 'Nf6',
        evalBeforeCp: 0,
        evalAfterCp: -150,
        lossCp: 150,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'f3e5', // Nxe5 captures e5 pawn
      );

      final expHang = buildEngineMoveExplanation(resHang, moveHang);
      expect(expHang.whatFailed, isNot(contains('top recommended move')));
      expect(expHang.betterChoice, contains('Instead of Na5, Stockfish preferred'));
    });

    test('5. Strong Alternative Moves (Distinct from Top Recommendation) do NOT claim top recommended move', () {
      const fenBefore = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const fenAfter = 'rnbqkbnr/pppppppp/8/8/2P5/8/PP1PPPPP/RNBQKBNR b KQkq c3 0 1';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'c4',
        fenAfter: fenAfter,
        opponentReplyUci: 'e7e5',
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveAlt = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'c4',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '',
      );

      final resAlt = EngineMoveResult(
        plyIndex: 0,
        san: 'c4',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: 15,
        lossCp: 5,
        quality: EngineMoveQuality.excellent,
        opponentBestReplyUci: 'e7e5',
      );

      final expAlt = buildEngineMoveExplanation(resAlt, moveAlt);
      expect(expAlt.whatFailed, contains('you chose a strong alternative'));
      expect(expAlt.whatFailed, isNot(contains('top recommended move'))); // Correctly non-best!
      expect(expAlt.betterChoice, contains('Stockfish slightly preferred move the pawn from e2 to e4'));
    });

    test('6. Black Perspective Evaluation Formatting in Advantage and Disadvantage', () {
      // Black is winning (+M2)
      final evalBlackWin = StructuredEvaluation.mate(moves: 2, winner: 'black');
      expect(evalBlackWin.formatDisplay(forWhite: false), equals('+M2'));
      expect(evalBlackWin.formatDisplay(forWhite: true), equals('-M2'));

      // Black is losing (-3.5 pawns)
      final evalBlackLoss = StructuredEvaluation.centipawns(350); // +3.5 for White
      expect(evalBlackLoss.formatDisplay(forWhite: false), equals('-3.5'));
      expect(evalBlackLoss.formatDisplay(forWhite: true), equals('+3.5'));
    });

    test('7. Restrained Objective Fallback on Validated FEN Position', () {
      const fenBefore = 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2';
      const fenAfter = 'rnbqkbnr/pppp1ppp/8/4p3/4P3/P7/1PPP1PPP/RNBQKBNR b KQkq - 0 2';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'a3',
        fenAfter: fenAfter,
        opponentReplyUci: 'g8f6',
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveSub = PersonalGameMove(
        plyIndex: 4,
        moveNumber: 3,
        isWhiteMove: true,
        san: 'a3',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?!',
      );

      final resSub = EngineMoveResult(
        plyIndex: 4,
        san: 'a3',
        bestMoveUci: 'g1f3',
        bestMoveSan: 'Nf3',
        evalBeforeCp: 30,
        evalAfterCp: -10,
        lossCp: 40,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'g8f6',
      );

      final expSub = buildEngineMoveExplanation(resSub, moveSub);
      expect(expSub.whatFailed, contains('this move was sub-optimal'));
      expect(expSub.betterChoice, contains('Instead of a3, Stockfish preferred'));
    });

    test('8. Full Authentic Regression for 44... Kb5 and 44... Kd5 on Validated Positions', () {
      const fenBefore = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';
      const fenAfterKb5 = '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';

      final valKb5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kb5',
        fenAfter: fenAfterKb5,
        opponentReplyUci: 'b3a2',
      );
      expect(valKb5.isValid, isTrue, reason: valKb5.error);

      const move44Kb5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kb5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKb5,
        annotation: '',
      );

      final analysisKb5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'richard63', 'Black': 'ajb009', 'Date': '2026.10.13'},
          sanMoves: ['Kb5'],
          result: '0-1',
        ),
        moves: [move44Kb5],
      );

      final resKb5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kb5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -2140,
            'evalAfterKind': 'mate',
            'evalAfterValue': -13,
            'evalAfterWinner': 'black',
            'evalAfterCp': null,
            'lossCp': 0,
            'quality': 'best',
            'opponentBestReplyUci': 'b3a2',
          }
        ]
      });

      final cardsKb5 = const PatternCardBuilder().fromGame(
        analysis: analysisKb5,
        result: resKb5,
        playerIsWhite: false,
      );
      expect(cardsKb5, isEmpty);

      // Kd5 blunder
      const fenAfterKd5 = '8/8/8/p2k1p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';
      final valKd5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kd5',
        fenAfter: fenAfterKd5,
        opponentReplyUci: 'b3a4',
      );
      expect(valKd5.isValid, isTrue, reason: valKd5.error);

      const move44Kd5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kd5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKd5,
        annotation: '',
      );

      final analysisKd5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'richard63', 'Black': 'ajb009', 'Date': '2026.10.13'},
          sanMoves: ['Kd5'],
          result: '0-1',
        ),
        moves: [move44Kd5],
      );

      final resKd5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kd5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -4865,
            'evalAfterKind': 'cp',
            'evalAfterCp': -3097,
            'lossCp': 1768,
            'quality': 'blunder',
            'opponentBestReplyUci': 'b3a4',
          }
        ]
      });

      final cardsKd5 = const PatternCardBuilder().fromGame(
        analysis: analysisKd5,
        result: resKd5,
        playerIsWhite: false,
      );
      expect(cardsKd5, hasLength(1));
      expect(cardsKd5.first.wrongMove, equals('Kd5'));
    });
  });
}
