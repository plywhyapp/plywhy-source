import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';

void main() {
  const analyzer = PersonalGameAnalyzer();

  group('PersonalGameAnalyzer', () {
    test('reconstructs a legal board position before and after every move', () {
      final game = PgnParser().parse('1. e4 e5 2. Nf3 Nc6 *').single;
      final analysis = analyzer.analyze(game);

      expect(analysis.isValid, isTrue);
      expect(analysis.moves, hasLength(4));
      expect(
        analysis.moves.first.fenBefore,
        'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      );
      expect(analysis.moves[0].fenAfter.split(' ')[1], 'b');
      expect(analysis.moves[1].fenAfter.split(' ')[1], 'w');
      expect(analysis.moves[2].moveLabel, '2. Nf3');
      expect(analysis.moves[3].moveLabel, '2... Nc6');
    });

    test('creates review positions only from PGN mistake annotations', () {
      final game = PgnParser()
          .parse('1. e4! e5? 2. Nf3?? Nc6?! 3. Bb5!? a6!! *')
          .single;
      final analysis = analyzer.analyze(game);

      expect(analysis.annotatedReviewMoves, hasLength(3));
      expect(analysis.annotatedReviewMoves[0].san, 'e5');
      expect(
        analysis.annotatedReviewMoves[0].mistakeSeverity,
        PgnMistakeSeverity.mistake,
      );
      expect(
        analysis.annotatedReviewMoves[1].mistakeSeverity,
        PgnMistakeSeverity.blunder,
      );
      expect(
        analysis.annotatedReviewMoves[2].mistakeSeverity,
        PgnMistakeSeverity.dubious,
      );
    });

    test('preserves capture and check metadata from SAN', () {
      final game = PgnParser()
          .parse('1. e4 d5 2. exd5 Qxd5 3. Nc3 Qe5+ *')
          .single;
      final analysis = analyzer.analyze(game);

      expect(analysis.isValid, isTrue);
      expect(analysis.moves[2].isCapture, isTrue);
      expect(analysis.moves[3].isCapture, isTrue);
      expect(analysis.moves[5].givesCheck, isTrue);
    });

    test('supports a PGN starting from a custom FEN', () {
      const pgn = '''
[SetUp "1"]
[FEN "8/8/8/8/8/8/4K3/6k1 w - - 0 1"]

1. Kf3 Kf1 *
''';
      final game = PgnParser().parse(pgn).single;
      final analysis = analyzer.analyze(game);

      expect(analysis.isValid, isTrue);
      expect(analysis.moves.first.fenBefore.startsWith('8/8/8/8/8/8/4K3/6k1'), isTrue);
      expect(analysis.moves, hasLength(2));
    });


    test('async reconstruction matches the synchronous analyzer', () async {
      final game = PgnParser().parse('1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 *').single;
      final sync = analyzer.analyze(game);
      final asyncResult = await analyzer.analyzeAsync(
        game,
        yieldEveryPlies: 1,
      );

      expect(asyncResult.isValid, sync.isValid);
      expect(asyncResult.moves, hasLength(sync.moves.length));
      expect(
        asyncResult.moves.map((move) => move.fenAfter).toList(),
        sync.moves.map((move) => move.fenAfter).toList(),
      );
    });

    test('reports the first illegal SAN instead of inventing a position', () {
      final game = ParsedPgnGame(
        headers: const {},
        sanMoves: const ['e4', 'e5', 'NotAMove'],
        result: '*',
      );
      final analysis = analyzer.analyze(game);

      expect(analysis.isValid, isFalse);
      expect(analysis.invalidPlyIndex, 2);
      expect(analysis.invalidSan, 'NotAMove');
      expect(analysis.moves, hasLength(2));
    });
  });
}
