import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/exercise_bank.dart';
import 'package:chess_sense/fen_utils.dart';
import 'package:chess_sense/models.dart';

void main() {
  test('exercise bank has unique IDs and valid answer indexes', () {
    expect(exerciseBank.map((e) => e.id).toSet().length, exerciseBank.length);

    for (final exercise in exerciseBank) {
      expect(exercise.answers.length, 4, reason: exercise.id);
      expect(exercise.correctIndex, inInclusiveRange(0, 3), reason: exercise.id);
      expect(exercise.question.trim(), isNotEmpty, reason: exercise.id);
      expect(exercise.explanation.trim(), isNotEmpty, reason: exercise.id);
      expect(exercise.difficulty, inInclusiveRange(1, 3), reason: exercise.id);
    }
  });

  test('every exercise has a structurally valid six-field FEN', () {
    for (final exercise in exerciseBank) {
      expect(isFenStructurallyValid(exercise.fen), isTrue, reason: exercise.id);
    }
  });

  test('bank contains fifty unique positions and ten exercises per skill', () {
    expect(exerciseBank.length, 50);
    expect(exerciseBank.map((e) => e.fen).toSet().length, exerciseBank.length);

    for (final skill in Skill.values) {
      expect(
        exerciseBank.where((exercise) => exercise.skill == skill).length,
        10,
        reason: skill.name,
      );
    }
  });

  test('every skill has easy, intermediate, and advanced material', () {
    for (final skill in Skill.values) {
      final difficulties = exerciseBank
          .where((exercise) => exercise.skill == skill)
          .map((exercise) => exercise.difficulty)
          .toSet();
      expect(difficulties, containsAll(<int>[1, 2, 3]), reason: skill.name);
    }
  });

  test('initial assessment remains exactly the twenty controlled IDs in order', () {
    expect(initialAssessmentExercises.length, 20);
    expect(
      initialAssessmentExercises.map((e) => e.id).toList(),
      initialAssessmentExerciseIds,
    );
  });

  test('all exercises are at least rules validated', () {
    expect(
      exerciseBank.where(
        (e) => e.validationStatus == ValidationStatus.unvalidated ||
            e.validationStatus == ValidationStatus.manualReviewed,
      ),
      isEmpty,
    );
  });

  test('the ten Opponent Response exercises are Stockfish validated', () {
    final opponent = exerciseBank.where(
      (e) => e.skill == Skill.opponentResponse,
    );
    expect(opponent.length, 10);
    expect(
      opponent.where(
        (e) => e.validationStatus != ValidationStatus.engineValidated,
      ),
      isEmpty,
    );
    expect(
      exerciseBank.where(
        (e) => e.skill != Skill.opponentResponse &&
            e.validationStatus == ValidationStatus.engineValidated,
      ),
      isEmpty,
    );
  });
}
