import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';

class _TestHttpOverrides extends HttpOverrides {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = _TestHttpOverrides();

  test('Test Stockfish 19 Evaluation on Position 1 (b1b7)', () async {
    final apiClient = EngineApiClient.forBaseUrl('http://127.0.0.1:8787');

    final moveContext = const PersonalGameMove(
      plyIndex: 0,
      moveNumber: 1,
      isWhiteMove: true,
      san: 'Rxb7',
      annotation: null,
      fenBefore: '2r2rk1/pbq1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 w - - 4 24',
      fenAfter: '2r2rk1/pbR1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/5RK1 b - - 0 24',
    );

    final result = await apiClient.analyzeGame(
      PersonalGameAnalysis(
        game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '*'),
        moves: [moveContext],
      ),
    );

    final evalResult = result.moves.first;
    expect(evalResult.lossCp < 80 || evalResult.quality == EngineMoveQuality.best || evalResult.quality == EngineMoveQuality.good, isTrue);
  });

  test('Test Stockfish 19 Evaluation on Position 2 (f3e5)', () async {
    final apiClient = EngineApiClient.forBaseUrl('http://127.0.0.1:8787');

    final moveContext = const PersonalGameMove(
      plyIndex: 0,
      moveNumber: 1,
      isWhiteMove: true,
      san: 'Nxe5',
      annotation: null,
      fenBefore: 'r3k2r/ppq1bppp/4pn2/2ppn3/1P4bP/2P2N2/P3BPP1/RNBQ1RK1 w kq - 3 11',
      fenAfter: 'r3k2r/ppq1bppp/4pn2/2ppN3/1P4bP/2P5/P3BPP1/RNBQ1RK1 b kq - 0 11',
    );

    final result = await apiClient.analyzeGame(
      PersonalGameAnalysis(
        game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '*'),
        moves: [moveContext],
      ),
    );

    final evalResult = result.moves.first;
    expect(evalResult.lossCp < 40 || evalResult.quality == EngineMoveQuality.best, isTrue);
  });
}
