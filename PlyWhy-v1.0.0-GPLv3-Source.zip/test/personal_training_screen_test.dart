import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/personal_review_training.dart';
import 'package:chess_sense/screens/personal_training_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  PersonalReviewItem sampleItem() {
    return const PersonalReviewItem(
      id: 'ui-test-blunder-1',
      gameLabel: 'Ada vs Grace',
      date: '2026.10.08',
      event: 'ChessSense UI Test',
      move: PersonalGameMove(
        plyIndex: 4,
        moveNumber: 3,
        isWhiteMove: true,
        san: 'Bb5',
        annotation: '??',
        fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3',
        fenAfter: 'r1bqkbnr/pppp1ppp/2n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3',
      ),
    );
  }

  testWidgets('Personal Training renders the ChessSense scan and reveal flow',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: PersonalTrainingScreen(items: <PersonalReviewItem>[sampleItem()]),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.text('Personal Training'), findsOneWidget);
    expect(find.text('Ada vs Grace'), findsOneWidget);

    await tester.scrollUntilVisible(
      find.text('ChessSense scan'),
      300,
      scrollable: find.byType(Scrollable).first,
    );

    expect(find.text('ChessSense scan'), findsOneWidget);
    expect(find.text('Reveal what I played'), findsOneWidget);
    expect(find.text('Hard'), findsNothing);
    expect(find.text('Good'), findsNothing);
    expect(find.text('Easy'), findsNothing);

    await tester.tap(find.text('Reveal what I played'));
    await tester.pumpAndSettle();

    expect(find.text('You played: 3. Bb5'), findsOneWidget);
    expect(find.textContaining('Blunder'), findsOneWidget);
    expect(find.text('Hard'), findsOneWidget);
    expect(find.text('Good'), findsOneWidget);
    expect(find.text('Easy'), findsOneWidget);
  });

  testWidgets('grading a review item completes the session', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: PersonalTrainingScreen(items: <PersonalReviewItem>[sampleItem()]),
      ),
    );

    await tester.pumpAndSettle();

    await tester.scrollUntilVisible(
      find.text('Reveal what I played'),
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('Reveal what I played'));
    await tester.pumpAndSettle();

    await tester.scrollUntilVisible(
      find.text('Good'),
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('Good'));
    await tester.pumpAndSettle();

    expect(find.text('Review complete'), findsOneWidget);
    expect(find.text('1 position scheduled for future review.'), findsOneWidget);
  });

  testWidgets('empty personal training queue shows a clear empty state',
      (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: PersonalTrainingScreen(items: <PersonalReviewItem>[]),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.text('Personal Training'), findsOneWidget);
    expect(
      find.text(
        'There are no PGN-marked mistakes available for personal training yet.',
      ),
      findsOneWidget,
    );
  });
}
