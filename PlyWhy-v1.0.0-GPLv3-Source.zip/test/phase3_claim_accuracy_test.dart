import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final context = const PersonalGameAnalyzer()
      .analyze(PgnParser().parse('1. e4 *').single)
      .moves
      .first;

  EngineMoveResult result(int? score) => EngineMoveResult(
    plyIndex: 0,
    san: 'e4',
    bestMoveUci: 'e2e4',
    bestMoveSan: 'e4',
    evalBeforeCp: score,
    evalAfterCp: score,
    lossCp: 0,
    quality: EngineMoveQuality.best,
    opponentBestReplyUci: 'e7e5',
  );

  test('an equal best move does not prove an advantage', () {
    final explanation = buildEngineMoveExplanation(result(0), context);
    expect(explanation.consequence, isNot(contains('maintains your advantage')));
    expect(explanation.consequence, isNot(contains('zero evaluation loss')));
  });

  test('a recommendation without scores remains unconfirmed', () {
    final explanation = buildEngineMoveExplanation(result(null), context);
    expect(explanation.lessonTitle, 'Unconfirmed Position Analysis');
    expect(explanation.betterChoice, contains('unconfirmed'));
    expect(explanation.opponentPunishment, isNot(contains('best response')));
  });

  test('a quiet principal variation is not proof of a forcing sequence', () {
    final f3 = const PersonalGameAnalyzer()
        .analyze(PgnParser().parse('1. f3 e5 2. g4 Qh4# 0-1').single)
        .moves.first;
    final move = EngineMoveResult(
      plyIndex: 0, san: 'f3', bestMoveUci: 'e2e4', bestMoveSan: 'e4',
      evalBeforeCp: 30, evalAfterCp: -70, lossCp: 100,
      quality: EngineMoveQuality.inaccuracy,
      opponentBestReplyUci: 'e7e5',
      opponentPunishmentLineUci: ['e7e5', 'e2e4', 'd7d5', 'e4d5'],
    );
    final explanation = buildEngineMoveExplanation(move, f3);
    expect(explanation.whatFailed, isNot(contains('forcing sequence')));
    expect(explanation.whyItWorks, isNot(contains('each move keeps you responding')));
    expect(explanation.consequence, isNot(contains('advantage is converted')));
  });

  test('checkmate reply does not imply another legal response', () {
    final g4 = const PersonalGameAnalyzer()
        .analyze(PgnParser().parse('1. f3 e5 2. g4 Qh4# 0-1').single)
        .moves[2];
    final move = EngineMoveResult(
      plyIndex: 2, san: 'g4', bestMoveUci: 'e2e4', bestMoveSan: 'e4',
      evalBeforeCp: -70, evalAfterCp: null, lossCp: 0,
      structuredEvalAfter: StructuredEvaluation.mate(moves: 1, winner: 'black'),
      quality: EngineMoveQuality.blunder, opponentBestReplyUci: 'd8h4',
    );
    final explanation = buildEngineMoveExplanation(move, g4);
    expect(explanation.whyItWorks, contains('checkmate'));
    expect(explanation.consequence, isNot(contains('your next move')));
  });
}
