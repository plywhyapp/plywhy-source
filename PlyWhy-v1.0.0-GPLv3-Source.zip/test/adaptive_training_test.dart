import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/adaptive_training.dart';
import 'package:chess_sense/exercise_bank.dart';
import 'package:chess_sense/models.dart';

void main() {
  final scores = <Skill, int>{
    Skill.threatAwareness: 80,
    Skill.opponentResponse: 20,
    Skill.loosePieceDetection: 30,
    Skill.moveSafety: 90,
    Skill.boardChangeAwareness: 70,
  };

  test('adaptive session creates ten unique exercises with 4/3/3 priority split', () {
    final session = buildAdaptiveSession(
      scores: scores,
      exerciseBank: exerciseBank,
      random: Random(1),
    );

    expect(session.length, 10);
    expect(session.map((e) => e.id).toSet().length, 10);
    expect(session.where((e) => e.skill == Skill.opponentResponse).length, 4);
    expect(session.where((e) => e.skill == Skill.loosePieceDetection).length, 3);
    expect(
      session.where(
        (e) =>
            e.skill != Skill.opponentResponse &&
            e.skill != Skill.loosePieceDetection,
      ).length,
      3,
    );
  });

  test('mixed portion samples each of the other three skills', () {
    final session = buildAdaptiveSession(
      scores: scores,
      exerciseBank: exerciseBank,
      random: Random(4),
    );

    expect(session.where((e) => e.skill == Skill.threatAwareness).length, 1);
    expect(session.where((e) => e.skill == Skill.boardChangeAwareness).length, 1);
    expect(session.where((e) => e.skill == Skill.moveSafety).length, 1);
  });

  test('adaptive session avoids recent exercises when fresh alternatives exist', () {
    final recent = ['OR01', 'OR02', 'LP01', 'LP02'];
    final session = buildAdaptiveSession(
      scores: scores,
      exerciseBank: exerciseBank,
      recentExerciseIds: recent,
      random: Random(2),
    );

    final selectedRecent = session.where((e) => recent.contains(e.id)).length;
    expect(selectedRecent, 0);
  });

  test('difficulty target rises with the skill score', () {
    expect(targetDifficultyForScore(0), 1);
    expect(targetDifficultyForScore(34), 1);
    expect(targetDifficultyForScore(35), 2);
    expect(targetDifficultyForScore(69), 2);
    expect(targetDifficultyForScore(70), 3);
    expect(targetDifficultyForScore(100), 3);
  });

  test('high-skill training prioritizes advanced exercises for the weakest skill', () {
    final highScores = <Skill, int>{
      Skill.threatAwareness: 100,
      Skill.opponentResponse: 90,
      Skill.loosePieceDetection: 95,
      Skill.moveSafety: 100,
      Skill.boardChangeAwareness: 100,
    };

    final session = buildAdaptiveSession(
      scores: highScores,
      exerciseBank: exerciseBank,
      random: Random(6),
    );
    final opponentIds = session
        .where((e) => e.skill == Skill.opponentResponse)
        .map((e) => e.id)
        .toSet();

    expect(opponentIds, containsAll(<String>['OR09', 'OR10']));
  });

  test('low-skill training prioritizes easy exercises for the weakest skill', () {
    final lowScores = <Skill, int>{
      Skill.threatAwareness: 80,
      Skill.opponentResponse: 20,
      Skill.loosePieceDetection: 70,
      Skill.moveSafety: 90,
      Skill.boardChangeAwareness: 85,
    };

    final session = buildAdaptiveSession(
      scores: lowScores,
      exerciseBank: exerciseBank,
      random: Random(7),
    );
    final opponentIds = session
        .where((e) => e.skill == Skill.opponentResponse)
        .map((e) => e.id)
        .toSet();

    expect(opponentIds, containsAll(<String>['OR01', 'OR02', 'OR03']));
  });
}
