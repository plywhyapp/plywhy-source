import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/models.dart';

void main() {
  test('session record JSON round trip preserves data', () {
    final original = SessionRecord(
      id: 'training-1',
      kind: SessionKind.training,
      timestampIso: '2026-10-05T16:00:00.000',
      correct: 8,
      total: 10,
      ratingBefore: 1400,
      ratingAfter: 1450,
      skillScoresAfter: {
        Skill.threatAwareness: 70,
        Skill.opponentResponse: 60,
        Skill.loosePieceDetection: 80,
        Skill.moveSafety: 75,
        Skill.boardChangeAwareness: 65,
      },
    );

    final decoded = SessionRecord.fromJson(original.toJson());
    expect(decoded.id, original.id);
    expect(decoded.kind, original.kind);
    expect(decoded.correct, 8);
    expect(decoded.total, 10);
    expect(decoded.ratingAfter, 1450);
    expect(decoded.skillScoresAfter[Skill.moveSafety], 75);
  });
}
