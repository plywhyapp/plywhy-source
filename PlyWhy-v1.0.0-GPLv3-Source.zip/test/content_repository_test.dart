import 'dart:math';

import 'package:chess_sense/content_repository.dart';
import 'package:flutter_test/flutter_test.dart';

ContentPuzzle _puzzle({
  required String id,
  int rating = 1500,
  int popularity = 90,
  int ratingDeviation = 80,
  List<String> themes = const ['fork', 'middlegame'],
  String moves = 'a2a3 b7b6 c2c3',
}) {
  return ContentPuzzle(
    id: id,
    fen: '7k/8/8/8/8/8/P7/K7 w - - 0 1',
    moves: moves,
    rating: rating,
    ratingDeviation: ratingDeviation,
    popularity: popularity,
    plays: 1000,
    themes: themes,
  );
}

void main() {
  test('parses compact content-pack JSON', () {
    final pack = ContentPack.parse(
      '[{"id":"abc","fen":"7k/8/8/8/8/8/P7/K7 w - - 0 1",'
      '"moves":"a2a3 h8g8","rating":1200,"rd":70,'
      '"popularity":95,"plays":500,"themes":["fork"]}]',
    );

    expect(pack.puzzles, hasLength(1));
    expect(pack.puzzles.single.id, 'abc');
    expect(pack.puzzles.single.moveList, ['a2a3', 'h8g8']);
  });

  test('maps ChessSense skill to an adaptive Lichess rating target', () {
    expect(targetLichessPuzzleRating(0), 850);
    expect(targetLichessPuzzleRating(50), 1550);
    expect(targetLichessPuzzleRating(100), 2250);
    expect(targetLichessPuzzleRating(-20), 850);
    expect(targetLichessPuzzleRating(150), 2250);
  });

  test('filters ambiguous mate-in-1, promotions, weak popularity and high RD', () {
    final selected = selectOpponentVisionPuzzles(
      [
        _puzzle(id: 'good1', rating: 1500),
        _puzzle(id: 'good2', rating: 1550),
        _puzzle(id: 'mate', themes: const ['mate', 'mateIn1']),
        _puzzle(id: 'promotion', moves: 'a2a3 b7b8q'),
        _puzzle(id: 'unpopular', popularity: 59),
        _puzzle(id: 'uncertain', ratingDeviation: 141),
      ],
      skillScore: 50,
      recentExerciseIds: const [],
      count: 10,
      random: Random(4),
    );

    expect(selected.map((p) => p.id).toSet(), {'good1', 'good2'});
  });

  test('deprioritizes recently seen positions when alternatives exist', () {
    final selected = selectOpponentVisionPuzzles(
      [
        _puzzle(id: 'recent', rating: 1550),
        _puzzle(id: 'fresh1', rating: 1540),
        _puzzle(id: 'fresh2', rating: 1560),
      ],
      skillScore: 50,
      recentExerciseIds: const ['LCH_recent'],
      count: 2,
      random: Random(2),
    );

    expect(selected.map((p) => p.id), isNot(contains('recent')));
  });

  test('converts source setup and reply into an Opponent Vision scenario', () {
    final scenario = opponentVisionScenarioFromPuzzle(
      _puzzle(
        id: 'xyz',
        rating: 1400,
        moves: 'a2a3 h8g8 g1f2',
        themes: const ['hangingPiece', 'middlegame'],
      ),
    );

    expect(scenario.id, 'LCH_xyz');
    expect(scenario.setupMovesUci, ['a2a3']);
    expect(scenario.correctMoveUci, 'h8g8');
    expect(scenario.dangerPattern, 'Loose piece blindness');
  });
}
