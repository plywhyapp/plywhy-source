import 'package:chess_sense/chess_move_validator.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const validator = ChessMoveValidator();

  group('ChessMoveValidator - Real Game Regression', () {
    test('44... Kb5 in richard63 vs ajb009 is exactly identified as c5b5', () {
      const fen = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'Kb5',
        targetInput: 'c5b5',
      );

      expect(result.status, equals(MoveMatchStatus.exactMatch));
      expect(result.isExactMatch, isTrue);
      expect(result.playedUci, equals('c5b5'));
      expect(result.targetUci, equals('c5b5'));
      expect(result.playedSan, equals('Kb5'));
      expect(result.fenAfterPlayed, equals('8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45'));
      expect(result.fenAfterPlayed, equals(result.fenAfterTarget));
    });

    test('44... Kb5 (c5b5) vs 44... Kd5 (c5d5) are correctly identified as DIFFERENT moves', () {
      const fen = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'Kb5',
        targetInput: 'c5d5',
      );

      expect(result.status, equals(MoveMatchStatus.differentMoves));
      expect(result.isExactMatch, isFalse);
      expect(result.playedUci, equals('c5b5'));
      expect(result.targetUci, equals('c5d5'));
      expect(result.fenAfterPlayed, isNot(equals(result.fenAfterTarget)));
    });
  });

  group('ChessMoveValidator - Pawns', () {
    const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

    test('single pawn push SAN e4 vs UCI e2e4 is exact match', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: 'e4',
        targetInput: 'e2e4',
      );
      expect(result.isExactMatch, isTrue);
      expect(result.playedUci, equals('e2e4'));
    });

    test('pawn push e4 vs e3 are different moves', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: 'e4',
        targetInput: 'e2e3',
      );
      expect(result.status, equals(MoveMatchStatus.differentMoves));
    });

    test('pawn capture exd5 vs e4d5 is exact match', () {
      const fen = 'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'exd5',
        targetInput: 'e4d5',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('en passant capture', () {
      const fen = 'rnbqkbnr/ppp1p1pp/8/3pPp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'exf6',
        targetInput: 'e5f6',
      );
      expect(result.isExactMatch, isTrue);
    });
  });

  group('ChessMoveValidator - Knights & Disambiguation', () {
    const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

    test('knight move Nf3 vs g1f3 is exact match', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: 'Nf3',
        targetInput: 'g1f3',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('disambiguated knight Nbd7 vs b8d7 is exact match', () {
      const fen = 'rnbqkb1r/ppp2ppp/5n2/3p4/2PP4/2N2N2/PP3PPP/R1BQKB1R b KQkq - 1 5';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'Nbd7',
        targetInput: 'b8d7',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('disambiguated knight Nbd7 vs Nfd7 (b8d7 vs f6d7) are different', () {
      const fen = 'rnbqkb1r/ppp2ppp/5n2/3p4/2PP4/2N2N2/PP3PPP/R1BQKB1R b KQkq - 1 5';
      final result1 = validator.validate(
        fenBefore: fen,
        playedInput: 'Nbd7',
        targetInput: 'b8d7',
      );
      final result2 = validator.validate(
        fenBefore: fen,
        playedInput: 'Nfd7',
        targetInput: 'f6d7',
      );

      expect(result1.isExactMatch, isTrue);
      expect(result2.isExactMatch, isTrue);

      final crossCheck = validator.validate(
        fenBefore: fen,
        playedInput: 'Nbd7',
        targetInput: 'f6d7',
      );
      expect(crossCheck.status, equals(MoveMatchStatus.differentMoves));
    });

    test('ambiguous Nd7 without file/rank disambiguation is rejected as invalid move', () {
      const fen = 'rnbqkb1r/ppp2ppp/5n2/3p4/2PP4/2N2N2/PP3PPP/R1BQKB1R b KQkq - 1 5';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'Nd7', // Ambiguous! Two knights can move to d7
        targetInput: 'b8d7',
      );

      expect(result.status, equals(MoveMatchStatus.invalidMove));
      expect(result.isValid, isFalse);
    });
  });

  group('ChessMoveValidator - Rooks & Rank/File Disambiguation', () {
    test('rook rank disambiguation R2e4 vs R5e4 are different', () {
      const fen = '4r1k1/4p3/8/4R3/8/8/4R3/4K3 w - - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'R2e4',
        targetInput: 'R5e4',
      );
      expect(result.status, equals(MoveMatchStatus.differentMoves));
    });

    test('rook R2e4 vs e2e4 is exact match', () {
      const fen = '4r1k1/4p3/8/4R3/8/8/4R3/4K3 w - - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'R2e4',
        targetInput: 'e2e4',
      );
      expect(result.isExactMatch, isTrue);
    });
  });

  group('ChessMoveValidator - Castling', () {
    test('White kingside castle O-O vs e1g1', () {
      const fen = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'O-O',
        targetInput: 'e1g1',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('White queenside castle O-O-O vs e1c1', () {
      const fen = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'O-O-O',
        targetInput: 'e1c1',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('Black kingside castle O-O vs e8g8', () {
      const fen = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R b KQkq - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'O-O',
        targetInput: 'e8g8',
      );
      expect(result.isExactMatch, isTrue);
    });

    test('O-O vs O-O-O are different moves', () {
      const fen = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1';
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'O-O',
        targetInput: 'O-O-O',
      );
      expect(result.status, equals(MoveMatchStatus.differentMoves));
    });

    test('castling O-O when path is blocked or king has moved is rejected as invalid move', () {
      const fen = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/RN2K2R w KQkq - 0 1'; // Nb1 blocks e1c1
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'O-O-O',
        targetInput: 'e1c1',
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
    });
  });

  group('ChessMoveValidator - Promotions', () {
    const fen = 'k7/3P4/8/8/8/8/8/4K3 w - - 0 1';

    test('queen promotion d8=Q vs d7d8q is exact match', () {
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'd8=Q',
        targetInput: 'd7d8q',
      );
      expect(result.isExactMatch, isTrue);
      expect(result.playedUci, equals('d7d8q'));
      expect(result.targetUci, equals('d7d8q'));
    });

    test('queen promotion vs rook promotion (d7d8q vs d7d8r) are different', () {
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'd7d8q',
        targetInput: 'd7d8r',
      );
      expect(result.status, equals(MoveMatchStatus.differentMoves));
    });

    test('malformed promotion d8=K or d8=Z returns invalidMove', () {
      final result = validator.validate(
        fenBefore: fen,
        playedInput: 'd8=K', // King promotion is illegal
        targetInput: 'd7d8q',
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
    });
  });

  group('ChessMoveValidator - Invalid & Illegal Input Error Handling', () {
    const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

    test('invalid FEN returns invalidFen status', () {
      final result = validator.validate(
        fenBefore: 'invalid_fen_string',
        playedInput: 'e4',
        targetInput: 'e2e4',
      );
      expect(result.status, equals(MoveMatchStatus.invalidFen));
      expect(result.isValid, isFalse);
    });

    test('illegal played move returns invalidMove status', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: 'e5', // Illegal for White on move 1
        targetInput: 'e2e4',
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
      expect(result.isValid, isFalse);
    });

    test('illegal target move returns invalidMove status', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: 'e4',
        targetInput: 'e7e5', // Illegal for White on move 1
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
      expect(result.isValid, isFalse);
    });

    test('empty move input returns invalidMove status', () {
      final result = validator.validate(
        fenBefore: startFen,
        playedInput: '',
        targetInput: 'e2e4',
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
      expect(result.isValid, isFalse);
    });

    test('playing e4 when e4 has already been played in FEN returns invalidMove', () {
      const fenAfterE4 = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1';
      final result = validator.validate(
        fenBefore: fenAfterE4,
        playedInput: 'e4', // Pawn is on e4 already
        targetInput: 'e7e5',
      );
      expect(result.status, equals(MoveMatchStatus.invalidMove));
    });
  });
}
