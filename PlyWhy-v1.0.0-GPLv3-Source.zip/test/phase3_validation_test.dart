@Tags(['stress'])
@Timeout(Duration(minutes: 30))
library;

import 'package:chess_sense/chess_move_validator.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/chess_fixture_validator.dart';
import 'helpers/phase3_position_generator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const fixtureValidator = ChessFixtureValidator();

  group('Phase 3 - Large-Scale Independent Validation (Gates A, B, C)', () {
    // Generate 10,000 positions deterministically
    late final List<ValidationPosition> positions10k;

    setUpAll(() {
      positions10k = Phase3PositionGenerator.generatePositions(10000);
      expect(positions10k.length, equals(10000));
    });

    void runGateValidation(String gateName, int count) {
      var passedCount = 0;
      var failedCount = 0;
      var skippedCount = 0;
      var inconclusiveCount = 0;

      final categoryCounts = <String, int>{};
      final categoryPasses = <String, int>{};

      final gatePositions = positions10k.take(count).toList(growable: false);

      for (final pos in gatePositions) {
        final recommendation = const ChessMoveValidator().validate(
          fenBefore: pos.fenBefore,
          playedInput: pos.playedSan,
          targetInput: pos.bestMoveUci,
        );
        expect(recommendation.isValid, isTrue,
            reason: 'Position ${pos.id}: ${recommendation.detail}');
        categoryCounts[pos.category] = (categoryCounts[pos.category] ?? 0) + 1;

        // 1. Verify FEN and Move Legality via ChessFixtureValidator
        final val = fixtureValidator.validate(
          fenBefore: pos.fenBefore,
          sanPlayed: pos.playedSan,
          fenAfter: pos.fenAfter,
          opponentReplyUci: pos.opponentReplyUci,
        );

        if (!val.isValid) {
          failedCount++;
          fail('Gate $gateName - Position #${pos.id} FEN/Move Validation Failed: ${val.error}');
        }

        // 2. Build Engine Move Result and Personal Game Move
        final moveContext = PersonalGameMove(
          plyIndex: pos.id,
          moveNumber: (pos.id ~/ 2) + 1,
          isWhiteMove: pos.isWhiteMove,
          san: pos.playedSan,
          fenBefore: pos.fenBefore,
          fenAfter: pos.fenAfter,
          annotation: '',
        );

        final quality = switch (pos.qualityString) {
          'best' => EngineMoveQuality.best,
          'excellent' => EngineMoveQuality.excellent,
          'good' => EngineMoveQuality.good,
          'inaccuracy' => EngineMoveQuality.inaccuracy,
          'mistake' => EngineMoveQuality.mistake,
          'blunder' => EngineMoveQuality.blunder,
          _ => EngineMoveQuality.unknown,
        };

        final moveResult = EngineMoveResult(
          plyIndex: pos.id,
          san: pos.playedSan,
          bestMoveUci: pos.bestMoveUci,
          bestMoveSan: pos.bestMoveSan,
          evalBeforeCp: pos.evalBeforeCp,
          evalAfterCp: pos.evalAfterCp,
          lossCp: pos.lossCp,
          quality: quality,
          opponentBestReplyUci: pos.opponentReplyUci,
          opponentPunishmentLineUci: pos.punishmentLineUci,
          structuredEvalBefore: StructuredEvaluation.centipawns(pos.evalBeforeCp),
          structuredEvalAfter: StructuredEvaluation.centipawns(pos.evalAfterCp),
        );

        // 3. Generate Engine Explanation
        final explanation = buildEngineMoveExplanation(moveResult, moveContext);

        // 4. Pedagogical Consistency Checks
        expect(explanation.whatFailed, isNotEmpty);
        expect(explanation.betterChoice, isNotEmpty);
        expect(explanation.whyItWorks, isNotEmpty);
        expect(explanation.consequence, isNotEmpty);

        // Verify NO unproven claims
        expect(explanation.whyItWorks, isNot(contains('increased opponent mobility')));
        expect(explanation.consequence, isNot(contains('forces a concession')));

        final isExactMatch = const ChessMoveValidator().validate(
          fenBefore: pos.fenBefore,
          playedInput: pos.playedSan,
          targetInput: pos.bestMoveUci,
        ).isExactMatch;

        if (isExactMatch && pos.qualityString != 'blunder' && pos.qualityString != 'mistake' && pos.qualityString != 'inaccuracy') {
          expect(explanation.whatFailed, contains('top recommended move'));
        } else if (quality == EngineMoveQuality.excellent || quality == EngineMoveQuality.good) {
          expect(explanation.whatFailed, isNot(contains('top recommended move')));
        }

        // 5. Pattern Card Generation Check
        final analysis = PersonalGameAnalysis(
          game: ParsedPgnGame(
            headers: {
              'White': pos.isWhiteMove ? 'Player' : 'Opponent',
              'Black': pos.isWhiteMove ? 'Opponent' : 'Player',
              'Date': '2026.10.15',
            },
            sanMoves: [pos.playedSan],
            result: '1-0',
          ),
          moves: [moveContext],
        );

        final engineGameResult = EngineGameResult.fromJson({
          'moves': [
            {
              'plyIndex': pos.id,
              'san': pos.playedSan,
              'bestMoveUci': pos.bestMoveUci,
              'evalBeforeKind': 'cp',
              'evalBeforeCp': pos.evalBeforeCp,
              'evalAfterKind': 'cp',
              'evalAfterCp': pos.evalAfterCp,
              'lossCp': pos.lossCp,
              'quality': pos.qualityString,
              'opponentBestReplyUci': pos.opponentReplyUci,
            }
          ]
        });

        final cards = const PatternCardBuilder().fromGame(
          analysis: analysis,
          result: engineGameResult,
          playerIsWhite: pos.isWhiteMove,
        );

        if (pos.qualityString == 'best' || isExactMatch) {
          expect(cards, isEmpty, reason: 'Best moves or exact matches must generate 0 Pattern Cards');
        } else if ((pos.qualityString == 'blunder' || pos.qualityString == 'mistake' || pos.qualityString == 'inaccuracy') && pos.lossCp > 15) {
          expect(cards, hasLength(1), reason: 'Demonstrated errors with lossCp > 15 must generate 1 Pattern Card');
        }

        passedCount++;
        categoryPasses[pos.category] = (categoryPasses[pos.category] ?? 0) + 1;
      }

      expect(passedCount, equals(count));
      expect(failedCount, equals(0));
      expect(skippedCount, equals(0));
      expect(inconclusiveCount, equals(0));
    }

    test('Gate A: 100 Positions Large-Scale Validation', () {
      runGateValidation('A', 100);
    });

    test('Gate B: 1,000 Positions Large-Scale Validation', () {
      runGateValidation('B', 1000);
    });

    test('Gate C: 10,000 Positions Large-Scale Validation', () {
      runGateValidation('C', 10000);
    });
  });
}
