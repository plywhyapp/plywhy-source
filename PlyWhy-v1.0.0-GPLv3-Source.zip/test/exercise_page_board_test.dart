import 'package:chess_sense/models.dart';
import 'package:chess_sense/widgets/exercise_page.dart';
import 'package:chess_sense/widgets/interactive_chessboard.dart';
import 'package:chess_sense/widgets/staunton_piece.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('ExercisePage uses the shared Staunton chessboard renderer',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(900, 1400));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    const exercise = Exercise(
      id: 'board-style-test',
      skill: Skill.threatAwareness,
      subtitle: 'Board renderer test',
      fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      question: 'Test?',
      answers: ['A', 'B'],
      correctIndex: 0,
      explanation: 'Test',
    );

    await tester.pumpWidget(
      MaterialApp(
        home: ExercisePage(
          title: 'Assessment',
          currentNumber: 1,
          totalNumber: 1,
          exercise: exercise,
          selected: null,
          onSelect: (_) {},
          onNext: () {},
          finalButton: 'Finish',
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType(InteractiveChessBoard), findsOneWidget);
    expect(find.byType(StauntonPiece), findsNWidgets(32));

    // The assessment must not fall back to Unicode chess glyph Text widgets.
    expect(find.text('♔'), findsNothing);
    expect(find.text('♚'), findsNothing);
  });
}
