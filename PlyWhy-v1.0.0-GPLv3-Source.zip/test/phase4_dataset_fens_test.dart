import 'dart:io';

import 'package:chess/chess.dart' as chess;
import 'package:chess_sense/content_repository.dart';
import 'package:chess_sense/pattern_transfer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('TASK 1 & CHESS CORRECTNESS: Dataset FEN and Legal Moves Verification', () async {
    final file = File('assets/content/lichess_puzzles_5000.json');
    final jsonText = file.readAsStringSync();
    final pack = ContentPack.parse(jsonText);

    expect(pack.puzzles.length, equals(5000));

    // Select 2 puzzles for 'Board Change Awareness'
    final selected = selectPatternTransferPuzzles(
      pack.puzzles,
      lessonTitle: 'Board Change Awareness',
      count: 2,
    );

    expect(selected.length, equals(2));

    final p1 = selected[0];
    final p2 = selected[1];

    // Verify FEN 1
    final b1 = chess.Chess.fromFEN(p1.fen);
    expect(chess.Chess.validate_fen(p1.fen)['valid'], isTrue);

    final p1OppMove = p1.moveList[0];
    final p1UserMove = p1.moveList[1];

    final p1MovedOpp = b1.move({'from': p1OppMove.substring(0, 2), 'to': p1OppMove.substring(2, 4), if (p1OppMove.length == 5) 'promotion': p1OppMove[4]});
    expect(p1MovedOpp, isTrue);
    final fen1AfterOpp = b1.fen;

    final p1MovedUser = b1.move({'from': p1UserMove.substring(0, 2), 'to': p1UserMove.substring(2, 4), if (p1UserMove.length == 5) 'promotion': p1UserMove[4]});
    expect(p1MovedUser, isTrue);

    // Verify FEN 2
    final b2 = chess.Chess.fromFEN(p2.fen);
    expect(chess.Chess.validate_fen(p2.fen)['valid'], isTrue);

    final p2OppMove = p2.moveList[0];
    final p2UserMove = p2.moveList[1];

    final p2MovedOpp = b2.move({'from': p2OppMove.substring(0, 2), 'to': p2OppMove.substring(2, 4), if (p2OppMove.length == 5) 'promotion': p2OppMove[4]});
    expect(p2MovedOpp, isTrue);
    final fen2AfterOpp = b2.fen;

    final p2MovedUser = b2.move({'from': p2UserMove.substring(0, 2), 'to': p2UserMove.substring(2, 4), if (p2UserMove.length == 5) 'promotion': p2UserMove[4]});
    expect(p2MovedUser, isTrue);

    // Assertions
    expect(p1.fen, isNot(equals(p2.fen)));
    expect(fen1AfterOpp, isNot(equals(fen2AfterOpp)));

    // Specific check for case sensitivity in dataset:
    final puzzle0009B = pack.puzzles.firstWhere((p) => p.id == '0009B');
    expect(puzzle0009B.fen.contains('B2P2Pb'), isTrue);
  });
}
