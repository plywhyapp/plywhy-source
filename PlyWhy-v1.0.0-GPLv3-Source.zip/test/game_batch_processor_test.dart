import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/game_batch_processor.dart';

void main() {
  const mateGame = '''
[Event "Endgame"]
[White "Ada"]
[Black "Ben"]
[Result "0-1"]

1. f3 e5 2. g4 Qh4# 0-1
''';

  test('background import reconstructs positions including checkmate', () async {
    final result = await reconstructPgnOffMainThread(mateGame);
    expect(result, hasLength(1));
    expect(result.single.isValid, isTrue);
    expect(result.single.moves, hasLength(4));
    expect(result.single.moves.last.san, 'Qh4#');
    expect(result.single.moves.last.fenAfter, contains(' w '));
  });

  test('background import preserves recent batch order and move positions', () async {
    final batch = List.generate(
      20,
      (i) => mateGame.replaceFirst('"Endgame"', '"Endgame $i"'),
    ).join('\n\n');

    var ticked = false;
    final pending = reconstructPgnOffMainThread(batch);
    // The event loop must remain able to run while chess reconstruction is
    // performed on another isolate rather than occupying the UI thread.
    await Future<void>.delayed(const Duration(milliseconds: 5), () {
      ticked = true;
    });
    expect(ticked, isTrue);

    final result = await pending;
    expect(result, hasLength(20));
    expect(result.first.game.event, 'Endgame 0');
    expect(result.last.game.event, 'Endgame 19');
    expect(result.every((game) => game.moves.length == 4 && game.isValid), isTrue);
  });

  test('background import reports invalid SAN without blocking next games', () async {
    const batch = '''
[Event "Invalid"]
[Result "*"]

1. e4 e5 2. NotAMove *

[Event "Valid"]
[Result "*"]

1. d4 d5 *
''';
    final result = await reconstructPgnOffMainThread(batch);
    expect(result, hasLength(2));
    expect(result.first.isValid, isFalse);
    expect(result.first.invalidSan, 'NotAMove');
    expect(result.last.isValid, isTrue);
  });
}
