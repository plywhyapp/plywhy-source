import 'package:chess_sense/widgets/interactive_chessboard.dart';
import 'package:chess_sense/widgets/rating_sparkline.dart';
import 'package:chess_sense/widgets/skill_bar.dart';
import 'package:chess_sense/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Board uses correct top-left square in either orientation', (tester) async {
    await tester.binding.setSurfaceSize(const Size(450, 550));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    String? tapped;
    Future<void> showBoard({required bool flipped}) async {
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 400,
              child: InteractiveChessBoard(
                board: const {},
                flipped: flipped,
                onSquareTap: (square) => tapped = square,
              ),
            ),
          ),
        ),
      ));
    }

    await showBoard(flipped: false);
    var rect = tester.getRect(find.byType(InteractiveChessBoard));
    await tester.tapAt(rect.topLeft + const Offset(20, 20));
    expect(tapped, 'a8');

    tapped = null;
    await showBoard(flipped: true);
    rect = tester.getRect(find.byType(InteractiveChessBoard));
    await tester.tapAt(rect.topLeft + const Offset(20, 20));
    expect(tapped, 'h1');
  });

  testWidgets('Premium rating chart supports rising and flat trends', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: Column(
          children: [
            RatingSparkline(values: [560, 590, 610]),
            RatingSparkline(values: [600, 600, 600]),
          ],
        ),
      ),
    ));

    expect(find.text('610'), findsOneWidget);
    expect(find.text('+50 over 3 records'), findsOneWidget);
    expect(find.text('0 over 3 records'), findsOneWidget);
  });

  testWidgets('Skill scores are clamped to display range', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: SkillBar(skill: Skill.moveSafety, score: 140)),
    ));
    expect(find.text('100'), findsOneWidget);
  });
}
