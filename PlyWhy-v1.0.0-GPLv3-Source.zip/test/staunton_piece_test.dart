import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/widgets/staunton_piece.dart';

void main() {
  test('all twelve chess symbols map to Chessnut SVG assets', () {
    const symbols = ['♔', '♕', '♖', '♗', '♘', '♙', '♚', '♛', '♜', '♝', '♞', '♟'];
    for (final symbol in symbols) {
      final spec = stauntonSpecForSymbol(symbol);
      expect(spec, isNotNull, reason: 'No piece mapped for $symbol');
      expect(spec!.assetPath, startsWith('assets/pieces/chessnut/'));
      expect(spec.assetPath, endsWith('.svg'));
    }
  });

  test('white and black pieces preserve color identity', () {
    expect(stauntonSpecForSymbol('♔')!.isWhite, isTrue);
    expect(stauntonSpecForSymbol('♙')!.isWhite, isTrue);
    expect(stauntonSpecForSymbol('♚')!.isWhite, isFalse);
    expect(stauntonSpecForSymbol('♟')!.isWhite, isFalse);
  });

  test('unknown symbols are ignored', () {
    expect(stauntonSpecForSymbol(null), isNull);
    expect(stauntonSpecForSymbol('x'), isNull);
  });
}
