import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:chess_sense/content_repository.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/pattern_transfer.dart';
import 'package:chess_sense/screens/pattern_transfer_screen.dart';
import 'package:chess_sense/widgets/interactive_chessboard.dart';

class _TestHttpOverrides extends HttpOverrides {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = _TestHttpOverrides();

  group('Phase 4 - Pattern Transfer Implementation', () {
    Process? serverProcess;
    late ContentPack pack;
    late EngineApiClient apiClient;

    setUpAll(() async {
      final repo = PuzzleContentRepository();
      pack = await repo.loadPack();
      
      apiClient = EngineApiClient.forBaseUrl('http://127.0.0.1:8787');

      try {
        final client = HttpClient();
        final req = await client.getUrl(Uri.parse('http://127.0.0.1:8787')).timeout(const Duration(seconds: 1));
        final res = await req.close();
        if (res.statusCode > 0) return;
      } catch (_) {}

      try {
        const dartExe = 'C:\\src\\flutter\\bin\\cache\\dart-sdk\\bin\\dart.exe';
        serverProcess = await Process.start(
          dartExe,
          ['tools/engine_server.dart'],
        );

        final readyCompleter = Completer<void>();
        serverProcess!.stdout.transform(utf8.decoder).transform(const LineSplitter()).listen((line) {
          if (line.contains('Listening on')) {
            if (!readyCompleter.isCompleted) readyCompleter.complete();
          }
        });

        await readyCompleter.future.timeout(const Duration(seconds: 5));
      } catch (_) {}
    });

    tearDownAll(() {
      serverProcess?.kill();
    });

    test('1. Validates Pattern Transfer selects matching 2-3 NEW chess positions', () {
      final puzzles = selectPatternTransferPuzzles(
        pack.puzzles,
        lessonTitle: 'Loose Piece Detection',
        count: 2,
      );

      expect(puzzles, hasLength(2));
      for (final p in puzzles) {
        expect(p.themes.any((t) => ['hangingPiece', 'fork', 'discoveredAttack'].contains(t)), isTrue);
      }
    });

    test('2. Validates Pattern Transfer handles empty results when no puzzles match gracefully', () {
      final puzzles = selectPatternTransferPuzzles(
        pack.puzzles,
        lessonTitle: 'Nonexistent Category That Should Match Nothing',
        count: 2,
      );

      expect(puzzles, isEmpty);
    });

    test('3. Validates updating card transfer stats via graded() and withTransferResults() and SharedPreferences Persistence', () async {
      SharedPreferences.setMockInitialValues({});
      final store = PatternCardStore();

      final card = PatternCard(
        id: 'test_card_transfer_1',
        sourceGame: 'Game',
        moveLabel: '1. e4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        wrongMove: 'e4',
        correctMoveUci: 'd2d4',
        opponentReplyUci: 'd7d5',
        lessonTitle: 'Opening',
        whatFailed: 'fail',
        punishment: 'punish',
        whyItWorks: 'why',
        consequence: 'cons',
        betterChoice: 'better',
        lessonText: 'lesson',
        flipped: false,
        repetitions: 0,
        intervalDays: 0,
        dueAtMs: 0,
        transferAttempts: 0,
        transferSuccesses: 0,
      );

      await store.upsertAll([card]);

      final updated = card.graded(PatternGrade.good, DateTime.now()).withTransferResults(1, 2);
      await store.saveGrade(updated);

      final freshStore = PatternCardStore();
      final loaded = await freshStore.loadAll();
      expect(loaded, hasLength(1));
      
      final reloadedCard = loaded.first;
      expect(reloadedCard.transferAttempts, equals(2));
      expect(reloadedCard.transferSuccesses, equals(1));
      expect(reloadedCard.intervalDays, greaterThanOrEqualTo(3)); // Spaced repetition advanced via good grade
    });

    testWidgets('4. End-to-End Flutter UI rendering and evaluation flow of Pattern Transfer Screen', (WidgetTester tester) async {
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);

      int receivedSuccesses = -1;
      int receivedAttempts = -1;
      bool completedCalled = false;

      // Construct a very simple 1-puzzle pack for testing the UI
      final customPack = ContentPack([
        const ContentPuzzle(
          id: 'test01',
          fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          moves: 'e2e4 e7e5',
          rating: 1000,
          ratingDeviation: 50,
          popularity: 90,
          plays: 100,
          themes: ['crushing'],
        )
      ]);

      final card = PatternCard(
        id: 'c1',
        sourceGame: 'Game',
        moveLabel: '1',
        fenBefore: 'x',
        wrongMove: 'x',
        correctMoveUci: 'x',
        opponentReplyUci: 'x',
        lessonTitle: 'Move Safety', // Matches 'crushing'
        whatFailed: '',
        punishment: '',
        whyItWorks: '',
        consequence: '',
        betterChoice: '',
        lessonText: '',
        flipped: false,
      );

      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(tester.view.resetPhysicalSize);

      await tester.pumpWidget(
        MaterialApp(
          home: PatternTransferScreen(
            card: card,
            pack: customPack, // Forces this puzzle to be selected
            apiClient: apiClient,
            onCompleted: () {
              completedCalled = true;
            },
            onResults: (s, a) {
              receivedSuccesses = s;
              receivedAttempts = a;
            },
          ),
        ),
      );

      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      
      expect(find.text('Apply: Move Safety'), findsOneWidget);
      expect(find.textContaining('Position 1 of 1'), findsOneWidget);
      expect(find.byType(InteractiveChessBoard), findsOneWidget);

      final e7Finder = find.byKey(const ValueKey('square_e7'));
      expect(e7Finder, findsOneWidget);

      await tester.runAsync(() async {
        await tester.tap(e7Finder);
        await tester.pump();
        await tester.tap(find.byKey(const ValueKey('square_e5')));
        await tester.pump();
        await Future.delayed(const Duration(seconds: 12));
      });

      await tester.pumpAndSettle();

      expect(find.textContaining('Excellent move!'), findsOneWidget);

      await tester.tap(find.text('Continue'));
      await tester.pumpAndSettle();

      expect(completedCalled, isTrue);
      expect(receivedAttempts, equals(1));
      expect(receivedSuccesses, equals(1));
    });

    testWidgets('5. Negative UI test: Engine unavailability displays error message in Pattern Transfer Screen', (WidgetTester tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(tester.view.resetPhysicalSize);
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);

      final customPack = ContentPack([
        const ContentPuzzle(
          id: 'test01',
          fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          moves: 'e2e4 e7e5',
          rating: 1000,
          ratingDeviation: 50,
          popularity: 90,
          plays: 100,
          themes: ['crushing'],
        )
      ]);

      final card = PatternCard(
        id: 'c1',
        sourceGame: 'Game',
        moveLabel: '1',
        fenBefore: 'x',
        wrongMove: 'x',
        correctMoveUci: 'x',
        opponentReplyUci: 'x',
        lessonTitle: 'Move Safety',
        whatFailed: '',
        punishment: '',
        whyItWorks: '',
        consequence: '',
        betterChoice: '',
        lessonText: '',
        flipped: false,
      );

      // Fake client pointing to a dead port
      final brokenClient = EngineApiClient.forBaseUrl('http://127.0.0.1:9999');

      await tester.pumpWidget(
        MaterialApp(
          home: PatternTransferScreen(
            card: card,
            pack: customPack,
            apiClient: brokenClient,
            onCompleted: () {},
            onResults: (s, a) {},
          ),
        ),
      );

      await tester.pumpAndSettle();
      
      await tester.runAsync(() async {
        await tester.tap(find.byKey(const ValueKey('square_e7')));
        await tester.pump();
        await tester.tap(find.byKey(const ValueKey('square_e5')));
        await tester.pump();
        await Future.delayed(const Duration(seconds: 4));
      });

      await tester.pumpAndSettle();

      expect(find.textContaining('Engine error:'), findsOneWidget);
    });
  });
}
