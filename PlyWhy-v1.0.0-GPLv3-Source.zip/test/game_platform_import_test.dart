import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';

import 'package:chess_sense/game_platform_import.dart';

class _FakeTransport implements GamePlatformTransport {
  final Map<String, GamePlatformHttpResponse> responses;
  final List<Uri> requested = [];

  _FakeTransport(this.responses);

  @override
  Future<GamePlatformHttpResponse> get(
    Uri uri, {
    Map<String, String> headers = const {},
  }) async {
    requested.add(uri);
    return responses[uri.toString()] ??
        const GamePlatformHttpResponse(statusCode: 404, body: 'missing');
  }
}

void main() {
  const pgn1 = '[Event "One"]\n[White "A"]\n[Black "B"]\n[Result "1-0"]\n\n1. e4 e5 2. Nf3 Nc6 1-0';
  const pgn2 = '[Event "Two"]\n[White "C"]\n[Black "D"]\n[Result "0-1"]\n\n1. d4 d5 2. c4 e6 0-1';

  test('Lichess import returns PGN from public export endpoint', () async {
    final uri = Uri.https(
      'lichess.org',
      '/api/games/user/tester',
      {
        'max': '20',
        'moves': 'true',
        'clocks': 'false',
        'evals': 'false',
        'opening': 'false',
      },
    );
    final transport = _FakeTransport({
      uri.toString(): const GamePlatformHttpResponse(
        statusCode: 200,
        body: pgn1,
      ),
    });
    final service = OnlineGameImportService(transport: transport);

    final result = await service.fetchLichessPgn('tester');

    expect(result, contains('[Event "One"]'));
    expect(transport.requested, hasLength(1));
  });

  test('Lichess import falls back to games export route', () async {
    final primary = Uri.https(
      'lichess.org',
      '/api/games/user/tester',
      {
        'max': '20',
        'moves': 'true',
        'clocks': 'false',
        'evals': 'false',
        'opening': 'false',
      },
    );
    final fallback = Uri.https(
      'lichess.org',
      '/games/export/tester',
      {'max': '20'},
    );
    final transport = _FakeTransport({
      primary.toString(): const GamePlatformHttpResponse(
        statusCode: 404,
        body: 'not found',
      ),
      fallback.toString(): const GamePlatformHttpResponse(
        statusCode: 200,
        body: pgn1,
      ),
    });
    final service = OnlineGameImportService(transport: transport);

    final result = await service.fetchLichessPgn('tester');

    expect(result, contains('[Event "One"]'));
    expect(transport.requested, hasLength(2));
  });

  test('Chess.com import reads newest monthly archive first', () async {
    final archives = Uri.parse(
      'https://api.chess.com/pub/player/tester/games/archives',
    );
    final september = Uri.parse(
      'https://api.chess.com/pub/player/tester/games/2026/09',
    );
    final october = Uri.parse(
      'https://api.chess.com/pub/player/tester/games/2026/10',
    );
    final transport = _FakeTransport({
      archives.toString(): GamePlatformHttpResponse(
        statusCode: 200,
        body: jsonEncode({
          'archives': [
            'https://api.chess.com/pub/player/tester/games/2026/09',
            'https://api.chess.com/pub/player/tester/games/2026/10',
          ],
        }),
      ),
      october.toString(): GamePlatformHttpResponse(
        statusCode: 200,
        body: jsonEncode({
          'games': [
            {'pgn': pgn1},
            {'pgn': pgn2},
          ],
        }),
      ),
      september.toString(): GamePlatformHttpResponse(
        statusCode: 200,
        body: jsonEncode({'games': []}),
      ),
    });
    final service = OnlineGameImportService(transport: transport);

    final result = await service.fetchChessComPgn('Tester', maxGames: 1);

    expect(result, contains('[Event "Two"]'));
    expect(result, isNot(contains('[Event "One"]')));
    expect(transport.requested, [archives, october]);
  });
}
