import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/models.dart';
import 'package:chess_sense/profile_logic.dart';

void main() {
  test('weighted overall score and rating are stable', () {
    final scores = <Skill, int>{
      Skill.threatAwareness: 75,
      Skill.opponentResponse: 50,
      Skill.loosePieceDetection: 100,
      Skill.moveSafety: 75,
      Skill.boardChangeAwareness: 50,
    };

    expect(calculateOverallScore(scores), 69);
    expect(calculateChessSenseRating(scores), 1566);
  });

  test('weakest skill returns the lowest score', () {
    final scores = <Skill, int>{
      Skill.threatAwareness: 75,
      Skill.opponentResponse: 40,
      Skill.loosePieceDetection: 100,
      Skill.moveSafety: 75,
      Skill.boardChangeAwareness: 50,
    };

    expect(calculateWeakestSkill(scores), Skill.opponentResponse);
  });

  test('skill ranking is deterministic when scores tie', () {
    final scores = <Skill, int>{for (final skill in Skill.values) skill: 50};
    expect(rankSkillsWeakestFirst(scores), Skill.values);
  });

  test('training updates only skills present in the session', () {
    final previous = <Skill, int>{for (final skill in Skill.values) skill: 50};

    final result = TrainingResult(
      correct: 3,
      total: 4,
      correctBySkill: {
        Skill.opponentResponse: 2,
        Skill.moveSafety: 1,
      },
      totalBySkill: {
        Skill.opponentResponse: 2,
        Skill.moveSafety: 2,
      },
    );

    final updated = updateSkillScores(previousScores: previous, result: result);

    expect(updated[Skill.opponentResponse], 60);
    expect(updated[Skill.moveSafety], 50);
    expect(updated[Skill.threatAwareness], 50);
  });

  test('streak increments only on consecutive days', () {
    expect(
      calculateNextStreak(
        currentStreak: 3,
        lastTrainingDate: '2026-10-04',
        today: '2026-10-05',
      ),
      4,
    );

    expect(
      calculateNextStreak(
        currentStreak: 3,
        lastTrainingDate: '2026-10-03',
        today: '2026-10-05',
      ),
      1,
    );

    expect(
      calculateNextStreak(
        currentStreak: 3,
        lastTrainingDate: '2026-10-05',
        today: '2026-10-05',
      ),
      3,
    );
  });
}
