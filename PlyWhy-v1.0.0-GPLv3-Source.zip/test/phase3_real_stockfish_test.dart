@Tags(['stress'])
@Timeout(Duration(minutes: 10))
library;

import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'helpers/phase3_position_generator.dart';
import 'helpers/real_stockfish_validator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Phase 3 - Real Stockfish Engine-Grounded Validation (Awaited Sequential Gates)', () {
    late List<ValidationPosition> basePositions;

    setUpAll(() {
      basePositions = Phase3PositionGenerator.generatePositions(10000);
    });

    Future<void> runRealEngineGateValidation(String gateName, int count) async {
      final exe = RealStockfishService.findExecutable();
      if (exe == null || !exe.existsSync()) {
        fail('Gate $gateName - Stockfish executable was not found at ${exe?.path}');
      }

      final sfService = RealStockfishService();
      final started = await sfService.start();
      if (!started) {
        sfService.stop();
        fail('Gate $gateName - Failed to start Stockfish process or complete uciok/readyok handshake');
      }

      final validator = const RealPositionValidator();
      var passedCount = 0;
      var failedCount = 0;
      var inconclusiveCount = 0;

      final results = <RealPositionValidationResult>[];
      final targetPositions = basePositions.take(count).toList(growable: false);

      try {
        for (final pos in targetPositions) {
          try {
            // 1. Obtain REAL Stockfish evaluation for fenBefore
            final evalBefore = await sfService.evaluatePosition(pos.fenBefore, movetimeMs: 5);

            // 2. Obtain REAL Stockfish evaluation for fenAfter
            final evalAfter = await sfService.evaluatePosition(pos.fenAfter, movetimeMs: 5);

            // 3. Validate against real Stockfish results
            final res = validator.validatePosition(
              id: pos.id,
              fenBefore: pos.fenBefore,
              playedSan: pos.playedSan,
              evalBefore: evalBefore,
              evalAfter: evalAfter,
            );

            results.add(res);

            if (res.outcome == 'PASSED') {
              passedCount++;
            } else if (res.outcome == 'FAILED') {
              failedCount++;
              fail('Gate $gateName - Real Engine Position #${pos.id} Failed: ${res.failureReason}');
            } else {
              inconclusiveCount++;
            }
          } on Exception catch (e) {
            if (e is TestFailure) rethrow;
            inconclusiveCount++;
          }
        }
      } finally {
        sfService.stop();
      }

      // Write persistent checkpoint JSON
      final checkpointFile = File('test/helpers/phase3_real_checkpoint_gate_$gateName.json');
      checkpointFile.writeAsStringSync(jsonEncode(results.map((r) => r.toJson()).toList()));

      // Independently inspect checkpoint file record count
      final readBackJson = jsonDecode(checkpointFile.readAsStringSync()) as List<dynamic>;
      expect(readBackJson.length, equals(count), reason: 'Checkpoint JSON record count must equal $count');

      expect(failedCount, equals(0), reason: 'Zero positions failed');
      expect(inconclusiveCount, equals(0), reason: 'Inconclusive positions are not verified evidence');
      expect(passedCount, equals(count), reason: 'All $count positions must pass real engine validation');
    }

    test('Gate A: 100 Real Stockfish Engine-Grounded Positions', () async {
      await runRealEngineGateValidation('A', 100);
    });

    test('Gate B: 1,000 Real Stockfish Engine-Grounded Positions', () async {
      await runRealEngineGateValidation('B', 1000);
    });

    test('Gate C: 10,000 Real Stockfish Engine-Grounded Positions', () async {
      await runRealEngineGateValidation('C', 10000);
    });
  });
}
