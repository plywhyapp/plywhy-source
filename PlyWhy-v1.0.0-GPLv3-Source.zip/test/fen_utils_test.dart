import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/fen_utils.dart';

void main() {
  test('rejects malformed or incomplete FEN strings', () {
    expect(isFenStructurallyValid('8/8/8/8/8/8/8/8'), isFalse);
    expect(
      isFenStructurallyValid('8/8/8/8/8/8/8/K6k x - - 0 1'),
      isFalse,
    );
    expect(
      isFenStructurallyValid('8/8/8/8/8/8/8/K6k w - z9 0 1'),
      isFalse,
    );
  });

  test('requires exactly one king per side and non-adjacent kings', () {
    expect(
      isFenStructurallyValid('8/8/8/8/8/8/8/K7 w - - 0 1'),
      isFalse,
    );
    expect(
      isFenStructurallyValid('8/8/8/8/8/8/8/Kk6 w - - 0 1'),
      isFalse,
    );
    expect(
      isFenStructurallyValid('7k/8/8/8/8/8/8/K7 w - - 0 1'),
      isTrue,
    );
  });

  test('applies castling rook movement to the visual board', () {
    final board = parseFenBoard('4k3/8/8/8/8/8/8/4K2R w K - 0 1');
    final moved = applyUciMoveToBoard(board, 'e1g1');

    expect(moved['e1'], isNull);
    expect(moved['h1'], isNull);
    expect(moved['g1'], '♔');
    expect(moved['f1'], '♖');
  });

  test('applies en passant capture to the visual board', () {
    final board = parseFenBoard('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1');
    final moved = applyUciMoveToBoard(board, 'e5d6');

    expect(moved['e5'], isNull);
    expect(moved['d5'], isNull);
    expect(moved['d6'], '♙');
  });

  test('applies UCI promotion to the visual board', () {
    final board = parseFenBoard('7k/P7/8/8/8/8/8/7K w - - 0 1');
    final moved = applyUciMoveToBoard(board, 'a7a8q');

    expect(moved['a7'], isNull);
    expect(moved['a8'], '♕');
  });

  test('tracks side to move after setup moves', () {
    const whiteToMove = '7k/8/8/8/8/8/8/K7 w - - 0 1';
    const blackToMove = '7k/8/8/8/8/8/8/K7 b - - 0 1';

    expect(sideToMoveAfterUciMoves(whiteToMove, 0), 'w');
    expect(sideToMoveAfterUciMoves(whiteToMove, 1), 'b');
    expect(isBlackToMoveAfterUciMoves(blackToMove, 0), isTrue);
    expect(isBlackToMoveAfterUciMoves(blackToMove, 1), isFalse);
  });
}
