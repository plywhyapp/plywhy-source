import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/real_stockfish_validator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const validator = RealPositionValidator();

  group('Phase 3 - Targeted Acceptance & Regression Tests', () {
    test('1. Move 1.d4 is NOT classified as Captures & Recaptures (Positional Strategy)', () {
      const evalBefore = RealEngineEval(
        scoreCp: 19,
        bestMoveUci: 'd2d4',
        bestMoveSan: 'd4',
        pvUci: ['d2d4', 'd7d5', 'c2c4'],
      );
      const evalAfter = RealEngineEval(
        scoreCp: 8,
        bestMoveUci: 'd7d5',
        bestMoveSan: 'd5',
        pvUci: ['d7d5', 'c2c4'],
      );

      final res = validator.validatePosition(
        id: 0,
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        playedSan: 'd4',
        evalBefore: evalBefore,
        evalAfter: evalAfter,
      );

      expect(res.category, isNot(equals('Captures & Recaptures')));
      expect(res.category, equals('Positional Strategy'));
    });

    test('2. Actual verified capture (Qxd1+) IS correctly classified as Captures & Recaptures', () {
      const evalBefore = RealEngineEval(
        scoreCp: 0,
        bestMoveUci: 'b8c6',
        bestMoveSan: 'Nc6',
        pvUci: ['b8c6', 'g1f3'],
      );
      const evalAfter = RealEngineEval(
        scoreCp: 50,
        bestMoveUci: 'e1d1',
        bestMoveSan: 'Kxd1',
        pvUci: ['e1d1', 'b8c6'],
      );

      final res = validator.validatePosition(
        id: 7,
        fenBefore: 'rnbqkbnr/ppp2ppp/8/4P3/2p1P3/8/PP3PPP/RNBQKBNR b KQkq - 0 4',
        playedSan: 'Qxd1+',
        evalBefore: evalBefore,
        evalAfter: evalAfter,
      );

      expect(res.category, equals('Captures & Recaptures'));
    });

    test('3. Mate scores are preserved without silent replacement by 0 cp', () {
      const evalBeforeMate = RealEngineEval(
        mateInMoves: 3,
        bestMoveUci: 'h5f7',
        bestMoveSan: 'Qxf7#',
        pvUci: ['h5f7'],
      );
      const evalAfterMate = RealEngineEval(
        mateInMoves: 2,
        bestMoveUci: 'e8e7',
        bestMoveSan: 'Ke7',
        pvUci: ['e8e7'],
      );

      final res = validator.validatePosition(
        id: 1,
        fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 2 3',
        playedSan: 'Qxf7#',
        evalBefore: evalBeforeMate,
        evalAfter: evalAfterMate,
      );

      expect(res.evalBeforeKind, equals('mate'));
      expect(res.evalBeforeValue, equals(3));
      expect(res.evalAfterKind, equals('mate'));
      expect(res.evalAfterValue, equals(2));
      expect(res.outcome, equals('PASSED'));
    });

    test('3b. Losing a forced mate win is classified as BLUNDER and generates 1 Pattern Card', () {
      const evalBeforeMate = RealEngineEval(
        mateInMoves: 3,
        bestMoveUci: 'h5f7',
        bestMoveSan: 'Qxf7#',
        pvUci: ['h5f7'],
      );
      const evalAfterLostMate = RealEngineEval(
        scoreCp: 100, // Player blew forced mate and got only +1.0 cp!
        bestMoveUci: 'c6d4',
        bestMoveSan: 'Nxd4',
        pvUci: ['c6d4'],
      );

      final res = validator.validatePosition(
        id: 1,
        fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 2 3',
        playedSan: 'a3', // Suboptimal move losing forced mate
        evalBefore: evalBeforeMate,
        evalAfter: evalAfterLostMate,
      );

      expect(res.quality, equals('blunder'), reason: 'Blowing a forced mate MUST be classified as blunder, NOT excellent!');
      expect(res.outcome, equals('PASSED'));
    });

    test('3c. Allowing opponent forced mate from centipawns is classified as BLUNDER', () {
      const evalBeforeCp = RealEngineEval(
        scoreCp: 20,
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        pvUci: ['e2e4'],
      );
      const evalAfterAllowedMate = RealEngineEval(
        mateInMoves: -2, // Opponent now has forced mate in 2!
        bestMoveUci: 'd8h4',
        bestMoveSan: 'Qh4#',
        pvUci: ['d8h4'],
      );

      final res = validator.validatePosition(
        id: 2,
        fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/5P2/8/PPPPP1PP/RNBQKBNR w KQkq - 0 2',
        playedSan: 'g4', // Blunder allowing Qh4# mate
        evalBefore: evalBeforeCp,
        evalAfter: evalAfterAllowedMate,
      );

      expect(res.quality, equals('blunder'), reason: 'Allowing opponent forced mate MUST be classified as blunder!');
      expect(res.outcome, equals('PASSED'));
    });

    test('4. Missing score (both cp and mate null) is marked INCONCLUSIVE', () {
      const evalBeforeMissing = RealEngineEval(
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        pvUci: [],
      );
      const evalAfterMissing = RealEngineEval(
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        pvUci: [],
      );

      final res = validator.validatePosition(
        id: 2,
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        playedSan: 'e4',
        evalBefore: evalBeforeMissing,
        evalAfter: evalAfterMissing,
      );

      expect(res.outcome, equals('INCONCLUSIVE'));
      expect(res.failureReason, contains('Missing engine score'));
    });

    test('5. Terminal positions with (none) reply are recognized without inventing replies', () {
      const evalBeforeTerm = RealEngineEval(
        scoreCp: 1000,
        bestMoveUci: 'h5f7',
        bestMoveSan: 'Qxf7#',
        pvUci: ['h5f7'],
      );
      const evalAfterTerm = RealEngineEval(
        scoreCp: 1000,
        bestMoveUci: '(none)',
        bestMoveSan: '(none)',
        pvUci: [],
      );

      final res = validator.validatePosition(
        id: 3,
        fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 2 3',
        playedSan: 'Qxf7#',
        evalBefore: evalBeforeTerm,
        evalAfter: evalAfterTerm,
      );

      expect(res.outcome, equals('PASSED'));
    });

    test('6. Demonstrated Pattern Card errors are validated, best moves produce 0 cards', () {
      const fenBefore = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';
      const moveKb5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kb5',
        fenBefore: fenBefore,
        fenAfter: '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45',
        annotation: '',
      );

      final analysisKb5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'A', 'Black': 'B', 'Date': '2026.10.15'},
          sanMoves: ['Kb5'],
          result: '0-1',
        ),
        moves: [moveKb5],
      );

      final resKb5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kb5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -2140,
            'evalAfterKind': 'cp',
            'evalAfterCp': -2140,
            'lossCp': 0,
            'quality': 'best',
            'opponentBestReplyUci': 'b3a2',
          }
        ]
      });

      final cardsKb5 = const PatternCardBuilder().fromGame(
        analysis: analysisKb5,
        result: resKb5,
        playerIsWhite: false,
      );
      expect(cardsKb5, isEmpty, reason: 'Best move MUST generate 0 Pattern Cards');

      // Kd5 blunder
      const moveKd5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kd5',
        fenBefore: fenBefore,
        fenAfter: '8/8/8/p2k1p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45',
        annotation: '',
      );

      final analysisKd5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'A', 'Black': 'B', 'Date': '2026.10.15'},
          sanMoves: ['Kd5'],
          result: '0-1',
        ),
        moves: [moveKd5],
      );

      final resKd5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kd5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -4865,
            'evalAfterKind': 'cp',
            'evalAfterCp': -3097,
            'lossCp': 1768,
            'quality': 'blunder',
            'opponentBestReplyUci': 'b3a4',
          }
        ]
      });

      final cardsKd5 = const PatternCardBuilder().fromGame(
        analysis: analysisKd5,
        result: resKd5,
        playerIsWhite: false,
      );
      expect(cardsKd5, hasLength(1), reason: 'Demonstrated blunder MUST generate 1 Pattern Card');
    });

    test('7. Checkpoint records contain complete engine evidence & serialization fields', () {
      const res = RealPositionValidationResult(
        id: 42,
        fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        playedSan: 'd4',
        category: 'Positional Strategy',
        isWhite: true,
        engineVersion: 'Stockfish 19',
        engineSettings: 'movetime 5ms',
        evalBeforeKind: 'cp',
        evalBeforeValue: 19,
        evalAfterKind: 'cp',
        evalAfterValue: 8,
        lossCp: 11,
        quality: 'excellent',
        bestMoveUci: 'd2d4',
        bestMoveSan: 'd4',
        pvUci: ['d2d4', 'd7d5'],
        explanationWhatFailed: 'You chose Stockfish\'s top recommended move in this position.',
        explanationBetterChoice: 'Stockfish confirmed d4 as the best move in this position.',
        explanationWhyItWorks: 'Playing d4 maintains your position.',
        explanationConsequence: 'Stockfish verifies that this move maintains your advantage.',
        outcome: 'PASSED',
      );

      final json = res.toJson();
      expect(json['engineVersion'], equals('Stockfish 19'));
      expect(json['engineSettings'], equals('movetime 5ms'));
      expect(json['bestMoveUci'], equals('d2d4'));
      expect(json['pvUci'], equals(['d2d4', 'd7d5']));
      expect(json['explanationWhatFailed'], contains('top recommended move'));

      final readBack = RealPositionValidationResult.fromJson(json);
      expect(readBack.id, equals(42));
      expect(readBack.engineVersion, equals('Stockfish 19'));
      expect(readBack.pvUci, equals(['d2d4', 'd7d5']));
    });
  });
}
