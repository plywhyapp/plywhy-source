import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/chess_fixture_validator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const fixtureValidator = ChessFixtureValidator();

  group('Phase 2B - 5 Verified Pedagogical Regressions with ChessFixtureValidator', () {
    test('1a. isSame = true with quality = blunder produces unconfirmed explanation (NOT praise)', () {
      const moveBlunder = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'e4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
        annotation: '??',
      );

      final resBlunder = EngineMoveResult(
        plyIndex: 0,
        san: 'e4',
        bestMoveUci: 'e2e4', // isSame is true
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: -500,
        lossCp: 520,
        quality: EngineMoveQuality.blunder, // Contradictory: quality is BLUNDER!
        opponentBestReplyUci: 'e7e5',
      );

      final explanation = buildEngineMoveExplanation(resBlunder, moveBlunder);

      // Must NOT receive praise or recommend identical move as better!
      expect(explanation.whatFailed, isNot(contains('top recommended move')));
      expect(explanation.betterChoice, isNot(contains('Stockfish confirmed e4 as the best move')));
      expect(explanation.whatFailed, contains('unconfirmed due to conflicting or incomplete classification data'));
      expect(explanation.opponentPunishment, contains('this response remains unconfirmed'));
    });

    test('1b. isSame = true with quality = mistake produces unconfirmed explanation', () {
      const moveMistake = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'e4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
        annotation: '?',
      );

      final resMistake = EngineMoveResult(
        plyIndex: 0,
        san: 'e4',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: -200,
        lossCp: 220,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'e7e5',
      );

      final explanation = buildEngineMoveExplanation(resMistake, moveMistake);
      expect(explanation.whatFailed, contains('unconfirmed due to conflicting or incomplete classification data'));
      expect(explanation.opponentPunishment, contains('this response remains unconfirmed'));
    });

    test('1c. isSame = true with quality = inaccuracy produces unconfirmed explanation', () {
      const moveInaccuracy = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'e4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
        annotation: '?!',
      );

      final resInaccuracy = EngineMoveResult(
        plyIndex: 0,
        san: 'e4',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: -30,
        lossCp: 50,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'e7e5',
      );

      final explanation = buildEngineMoveExplanation(resInaccuracy, moveInaccuracy);
      expect(explanation.whatFailed, contains('unconfirmed due to conflicting or incomplete classification data'));
      expect(explanation.opponentPunishment, contains('this response remains unconfirmed'));
    });

    test('2. isSame = true with quality = unknown produces unconfirmed analysis', () {
      const moveUnknown = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'e4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
        annotation: '',
      );

      final resUnknown = EngineMoveResult(
        plyIndex: 0,
        san: 'e4',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: null,
        evalAfterCp: null,
        lossCp: 0,
        quality: EngineMoveQuality.unknown, // Quality UNKNOWN
        opponentBestReplyUci: null,
      );

      final explanation = buildEngineMoveExplanation(resUnknown, moveUnknown);

      expect(explanation.whatFailed, contains('unconfirmed'));
      expect(explanation.betterChoice, contains('unconfirmed'));
    });

    test('3. King move leaving central square does NOT claim increased opponent mobility', () {
      const fenBefore = '8/8/8/3k4/8/8/8/4K3 b - - 0 1'; // King on d5 (central square)
      const fenAfter = '8/8/3k4/8/8/8/8/4K3 w - - 1 2';   // King moves to d6

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kd6',
        fenAfter: fenAfter,
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveKing = PersonalGameMove(
        plyIndex: 1,
        moveNumber: 1,
        isWhiteMove: false,
        san: 'Kd6',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '',
      );

      final resKing = EngineMoveResult(
        plyIndex: 1,
        san: 'Kd6',
        bestMoveUci: 'd5c4',
        bestMoveSan: 'Kc4',
        evalBeforeCp: 0,
        evalAfterCp: -100,
        lossCp: 100,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: null,
      );

      final explanation = buildEngineMoveExplanation(resKing, moveKing);

      // Must NOT claim "increased opponent mobility" or "relieved pressure"
      expect(explanation.whatFailed, contains('stepping away from central control squares'));
      expect(explanation.whyItWorks, isNot(contains('increased opponent mobility')));
      expect(explanation.whyItWorks, isNot(contains('relieved pressure')));
    });

    test('4a. Genuine capture and immediate legal king recapture does NOT claim net material gain', () {
      const fenBefore = 'rnbqkbnr/ppp2ppp/8/4P3/2p1P3/8/PP3PPP/RNBQKBNR b KQkq - 0 4';
      const fenAfter = 'rnb1kbnr/ppp2ppp/8/4P3/2p1P3/8/PP3PPP/RNBqKBNR w KQkq - 0 5';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Qxd1+',
        fenAfter: fenAfter,
        opponentReplyUci: 'e1d1', // Qxd1+ White King recaptures Black Queen on d1!
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveCapture = PersonalGameMove(
        plyIndex: 7,
        moveNumber: 4,
        isWhiteMove: false,
        san: 'Qxd1+',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?!',
      );

      final resCapture = EngineMoveResult(
        plyIndex: 7,
        san: 'Qxd1+',
        bestMoveUci: 'b8c6',
        bestMoveSan: 'Nc6',
        evalBeforeCp: 0,
        evalAfterCp: 50,
        lossCp: 50,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'e1d1', // Qxd1+ followed by e1d1 (Kxd1)
        opponentPunishmentLineUci: ['e1d1', 'b8c6'], // Sequence with recapture move!
      );

      final explanation = buildEngineMoveExplanation(resCapture, moveCapture);

      // Must NOT claim "net material gain", MUST recognize piece exchange starting with queen capture!
      expect(explanation.whatFailed, isNot(contains('net material gain')));
      expect(explanation.whatFailed, contains('allowed a piece exchange starting with the capture of your queen on d1'));
      expect(explanation.opponentPunishment, contains('capture on d1 with the king from e1'));
      expect(explanation.consequence, contains('The exchange begins with the capture of your queen'));
    });

    test('4b. Uncompensated capture without recapture is correctly distinguished as immediate capture', () {
      const fenBefore = 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3';
      const fenAfter = 'r1bqkbnr/pppp1ppp/8/n3p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Na5',
        fenAfter: fenAfter,
        opponentReplyUci: 'f3e5', // Nxe5 captures e5 pawn without immediate recapture in 2-ply
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveUncompensated = PersonalGameMove(
        plyIndex: 6,
        moveNumber: 4,
        isWhiteMove: false,
        san: 'Na5',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?',
      );

      final resUncompensated = EngineMoveResult(
        plyIndex: 6,
        san: 'Na5',
        bestMoveUci: 'g8f6',
        bestMoveSan: 'Nf6',
        evalBeforeCp: 0,
        evalAfterCp: -150,
        lossCp: 150,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'f3e5',
        opponentPunishmentLineUci: ['f3e5'], // No immediate recapture move!
      );

      final explanation = buildEngineMoveExplanation(resUncompensated, moveUncompensated);

      expect(explanation.whatFailed, contains('allowed an immediate capture of your pawn on e5'));
      expect(explanation.consequence, contains('The punishment starts with the loss of your pawn'));
    });

    test('4c. Defensible fork on candidate position (4k3/8/8/1n6/8/P7/1P6/1R1QK3 b - - 0 1) executes double-attack branch and identifies queen on d1 and rook on b1', () {
      const fenBefore = '4k3/8/8/1n6/8/8/PP6/1R1QK3 w - - 0 1';
      const fenAfter = '4k3/8/8/1n6/8/P7/1P6/1R1QK3 b - - 0 1';

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'a3',
        fenAfter: fenAfter,
        opponentReplyUci: 'b5c3', // 1... Nc3 attacks Queen d1 (9 pts) and Rook b1 (5 pts)!
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveFork = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'a3',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?!',
      );

      final resFork = EngineMoveResult(
        plyIndex: 0,
        san: 'a3',
        bestMoveUci: 'd1e2',
        bestMoveSan: 'Qe2',
        evalBeforeCp: 20,
        evalAfterCp: -200,
        lossCp: 220,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'b5c3', // Nc3 attacks queen on d1 and rook on b1!
        opponentPunishmentLineUci: ['b5c3', 'b2c3'], // White plays 2. bxc3 capturing knight!
      );

      final explanation = buildEngineMoveExplanation(resFork, moveFork);

      // Verify double attack branch executes, identifies queen on d1 and rook on b1
      expect(explanation.whatFailed, contains('allowed a double attack on two pieces simultaneously'));
      expect(explanation.whyItWorks, contains('queen on d1'));
      expect(explanation.whyItWorks, contains('rook on b1'));

      // Must NOT claim "forces a concession" or "forces material loss"
      expect(explanation.consequence, isNot(contains('forces a concession')));
      expect(explanation.consequence, isNot(contains('forces material loss')));
    });

    test('4d. Unrelated counter-capture (player captured on S1, opponent captured on S3 != S1) is correctly classified', () {
      // White plays 4. Qxd4 capturing pawn on d4 (S1 = d4). Black replies 4... Nxe4 capturing pawn on e4 (S3 = e4 != d4)
      const fenBefore = 'r1bq1rk1/pppp1ppp/5n2/4p3/3bP3/2N2N2/PPP2PPP/R1BQKB1R w KQ - 0 4'; // Castling rights KQ (Black has castled)
      const fenAfter = 'r1bq1rk1/pppp1ppp/5n2/4p3/3QP3/2N2N2/PPP2PPP/R1B1KB1R b KQ - 0 4'; // Qxd4

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Qxd4',
        fenAfter: fenAfter,
        opponentReplyUci: 'f6e4', // Nxe4 captures e4 pawn (unrelated square S3 = e4 != d4)!
      );
      expect(val.isValid, isTrue, reason: val.error);

      const moveDesperado = PersonalGameMove(
        plyIndex: 6,
        moveNumber: 4,
        isWhiteMove: true,
        san: 'Qxd4',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '?!',
      );

      final resDesperado = EngineMoveResult(
        plyIndex: 6,
        san: 'Qxd4',
        bestMoveUci: 'f3d4',
        bestMoveSan: 'Nxd4',
        evalBeforeCp: 20,
        evalAfterCp: -100,
        lossCp: 120,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'f6e4',
      );

      final explanation = buildEngineMoveExplanation(resDesperado, moveDesperado);

      expect(explanation.whatFailed, contains('counter-capture'));
      expect(explanation.consequence, contains('unrelated counter-capture'));
    });

    test('4e. Pinned piece cannot legally recapture even when movement pattern attacks destination square', () {
      const fenBefore = '4r1k1/ppp2ppp/8/3n4/8/2P5/PP2NPPP/R3K2R w KQ - 0 1'; // White Knight on e2 is pinned against King on e1 by Black Rook on e8
      const fenAfter = '4r1k1/ppp2ppp/8/3n4/8/P1P5/1P2NPPP/R3K2R b KQ - 0 1';   // White played 1. a3

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'a3',
        fenAfter: fenAfter,
        opponentReplyUci: 'd5c3', // 1... Nxc3 Black Knight captures c3 pawn
      );
      expect(val.isValid, isTrue, reason: val.error);

      const movePinned = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'a3',
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        annotation: '??',
      );

      final resPinned = EngineMoveResult(
        plyIndex: 0,
        san: 'a3',
        bestMoveUci: 'e1d1',
        bestMoveSan: 'Kd1',
        evalBeforeCp: 0,
        evalAfterCp: -500,
        lossCp: 500,
        quality: EngineMoveQuality.blunder,
        opponentBestReplyUci: 'd5c3', // 1... Nxc3
        opponentPunishmentLineUci: ['d5c3', 'e2c3'], // e2c3 is geometrically valid but ILLEGAL due to pin on e-file!
      );

      final explanation = buildEngineMoveExplanation(resPinned, movePinned);

      // Must NOT classify as a legal piece exchange because knight on e2 is pinned against king on e1!
      expect(explanation.whatFailed, isNot(contains('piece exchange')));
      expect(explanation.whatFailed, contains('allowed an immediate capture of your pawn on c3'));
    });

    test('5. Missing opponent response says no reply provided without claiming no forcing counterplay', () {
      const moveNoReply = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'a3',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/8/P7/1PPPPPPP/RNBQKBNR b KQkq - 0 1',
        annotation: '?!',
      );

      final resNoReply = EngineMoveResult(
        plyIndex: 0,
        san: 'a3',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: 0,
        lossCp: 20,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: null, // Reply is NULL
      );

      final explanation = buildEngineMoveExplanation(resNoReply, moveNoReply);

      expect(explanation.opponentPunishment, equals('Stockfish did not return a concrete opponent reply for this position.'));
      expect(explanation.opponentPunishment, isNot(contains('no forcing counterplay')));
    });

    test('6. White and Black CP sign interpretation in _consequenceText for both +350 and -350', () {
      const moveWhite = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true, // White player
        san: 'h3',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/8/7P/PPPPPPP1/RNBQKBNR b KQkq - 0 1',
        annotation: '?!',
      );

      // White evalAfterCp = +350 (White is +3.5 pawns better)
      final resWhiteWin = EngineMoveResult(
        plyIndex: 0,
        san: 'h3',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 400,
        evalAfterCp: 350,
        lossCp: 50,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'e7e5',
      );

      final expWhiteWin = buildEngineMoveExplanation(resWhiteWin, moveWhite);
      expect(expWhiteWin.consequence, contains('You still remain about 3.5 pawns better'));

      // White evalAfterCp = -350 (White is -3.5 pawns worse / Black is +3.5)
      final resWhiteLoss = EngineMoveResult(
        plyIndex: 0,
        san: 'h3',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: -50,
        evalAfterCp: -350,
        lossCp: 300,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'e7e5',
      );

      final expWhiteLoss = buildEngineMoveExplanation(resWhiteLoss, moveWhite);
      expect(expWhiteLoss.consequence, contains('the opponent is about 3.5 pawns better'));

      const moveBlack = PersonalGameMove(
        plyIndex: 1,
        moveNumber: 1,
        isWhiteMove: false, // Black player
        san: 'h6',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
        fenAfter: 'rnbqkbnr/ppppppp1/7p/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2',
        annotation: '?!',
      );

      // Black evalAfterCp = -350 (Black is +3.5 pawns better)
      final resBlackWin = EngineMoveResult(
        plyIndex: 1,
        san: 'h6',
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        evalBeforeCp: -400,
        evalAfterCp: -350,
        lossCp: 50,
        quality: EngineMoveQuality.inaccuracy,
        opponentBestReplyUci: 'd2d4',
      );

      final expBlackWin = buildEngineMoveExplanation(resBlackWin, moveBlack);
      expect(expBlackWin.consequence, contains('You still remain about 3.5 pawns better'));

      // Black evalAfterCp = +350 (White +3.5, so Black is -3.5 pawns worse)
      final resBlackLoss = EngineMoveResult(
        plyIndex: 1,
        san: 'h6',
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        evalBeforeCp: 50,
        evalAfterCp: 350,
        lossCp: 300,
        quality: EngineMoveQuality.mistake,
        opponentBestReplyUci: 'd2d4',
      );

      final expBlackLoss = buildEngineMoveExplanation(resBlackLoss, moveBlack);
      expect(expBlackLoss.consequence, contains('the opponent is about 3.5 pawns better'));
    });

    test('7. Large CP value (12.0 pawns) in consequence path without explicit mate evaluation does NOT claim forced checkmate', () {
      const moveLargeCp = PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'a3',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/8/P7/1PPPPPPP/RNBQKBNR b KQkq - 0 1',
        annotation: '??',
      );

      final resLargeCp = EngineMoveResult(
        plyIndex: 0,
        san: 'a3',
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        evalBeforeCp: 20,
        evalAfterCp: -1200, // -12.0 centipawns for White in blunder path
        lossCp: 1220,
        quality: EngineMoveQuality.blunder,
        opponentBestReplyUci: 'e7e5',
        structuredEvalBefore: const StructuredEvaluation.centipawns(20),
        structuredEvalAfter: const StructuredEvaluation.centipawns(-1200),
      );

      final expLargeCp = buildEngineMoveExplanation(resLargeCp, moveLargeCp);

      // Must NOT claim forced checkmate when kind is centipawns!
      expect(expLargeCp.consequence, isNot(contains('forced checkmate')));
      expect(expLargeCp.consequence, contains('decisive evaluation swing'));
    });

    test('8. Full Authentic Regression for 44... Kb5 and 44... Kd5', () {
      const fenBefore = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';
      const fenAfterKb5 = '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';

      final valKb5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kb5',
        fenAfter: fenAfterKb5,
        opponentReplyUci: 'b3a2',
      );
      expect(valKb5.isValid, isTrue);

      const move44Kb5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kb5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKb5,
        annotation: '',
      );

      final analysisKb5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'richard63', 'Black': 'ajb009', 'Date': '2026.10.13'},
          sanMoves: ['Kb5'],
          result: '0-1',
        ),
        moves: [move44Kb5],
      );

      final resKb5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kb5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -2140,
            'evalAfterKind': 'mate',
            'evalAfterValue': -13,
            'evalAfterWinner': 'black',
            'evalAfterCp': null,
            'lossCp': 0,
            'quality': 'best',
            'opponentBestReplyUci': 'b3a2',
          }
        ]
      });

      final cardsKb5 = const PatternCardBuilder().fromGame(
        analysis: analysisKb5,
        result: resKb5,
        playerIsWhite: false,
      );
      expect(cardsKb5, isEmpty);

      // Kd5 blunder
      const fenAfterKd5 = '8/8/8/p2k1p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45';
      final valKd5 = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'Kd5',
        fenAfter: fenAfterKd5,
        opponentReplyUci: 'b3a4',
      );
      expect(valKd5.isValid, isTrue);

      const move44Kd5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kd5',
        fenBefore: fenBefore,
        fenAfter: fenAfterKd5,
        annotation: '',
      );

      final analysisKd5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {'White': 'richard63', 'Black': 'ajb009', 'Date': '2026.10.13'},
          sanMoves: ['Kd5'],
          result: '0-1',
        ),
        moves: [move44Kd5],
      );

      final resKd5 = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kd5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -4865,
            'evalAfterKind': 'cp',
            'evalAfterCp': -3097,
            'lossCp': 1768,
            'quality': 'blunder',
            'opponentBestReplyUci': 'b3a4',
          }
        ]
      });

      final cardsKd5 = const PatternCardBuilder().fromGame(
        analysis: analysisKd5,
        result: resKd5,
        playerIsWhite: false,
      );
      expect(cardsKd5, hasLength(1));
      expect(cardsKd5.first.wrongMove, equals('Kd5'));
    });
  });
}
