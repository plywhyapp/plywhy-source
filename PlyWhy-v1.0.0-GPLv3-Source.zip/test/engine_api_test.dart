import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeTransport implements EngineTransport {
  Map<String, dynamic>? lastBody;
  String? lastPath;
  final Map<String, dynamic> response;

  _FakeTransport(this.response);

  @override
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body,
  ) async {
    lastPath = path;
    lastBody = body;
    return response;
  }
}

PersonalGameAnalysis _sampleAnalysis() {
  final parser = PgnParser();
  final game = parser.parse('''
[White "Ada"]
[Black "Grace"]
[Result "*"]

1. e4 e5 2. Nf3 Nc6 *
''').single;
  return const PersonalGameAnalyzer().analyze(game);
}

void main() {
  test('engine move rejects malformed ply indices without truncating them', () {
    for (final value in <Object?>[
      null, '0', true, -1, -0.5, 0.5, double.nan, double.infinity,
    ]) {
      expect(
        () => EngineMoveResult.fromJson({'plyIndex': value, 'san': 'e4'}),
        throwsA(isA<EngineApiException>()),
        reason: 'Invalid plyIndex: $value',
      );
    }
  });

  test('full-game network timeout accommodates the verified end-to-end engine QA', () {
    final transport = IoEngineTransport(baseUrl: 'http://127.0.0.1:8787/');
    try {
      expect(transport.timeout, const Duration(seconds: 180));
    } finally {
      transport.close();
    }
  });


  test('engine API sends reconstructed positions instead of raw assumptions', () async {
    final transport = _FakeTransport({'moves': <Map<String, dynamic>>[]});
    final client = EngineApiClient(transport: transport);

    await client.analyzeGame(_sampleAnalysis());

    expect(transport.lastPath, '/v1/analyze-game');
    expect(transport.lastBody!['schemaVersion'], 1);
    final moves = transport.lastBody!['moves'] as List<dynamic>;
    expect(moves, hasLength(4));
    expect((moves.first as Map)['san'], 'e4');
    expect((moves.first as Map)['fenBefore'], isNotEmpty);
    expect((moves.first as Map)['fenAfter'], isNotEmpty);
  });

  test('engine response parses move quality and summary counts', () async {
    final transport = _FakeTransport({
      'moves': [
        {
          'plyIndex': 0,
          'san': 'e4',
          'bestMoveUci': 'e2e4',
          'bestMoveSan': 'e4',
          'evalBeforeCp': 20,
          'evalAfterCp': 18,
          'lossCp': 2,
          'quality': 'best',
          'opponentBestReplyUci': 'e7e5',
        },
        {
          'plyIndex': 1,
          'san': 'e5',
          'bestMoveUci': 'c7c5',
          'bestMoveSan': 'c5',
          'evalBeforeCp': -18,
          'evalAfterCp': 95,
          'lossCp': 113,
          'quality': 'mistake',
          'opponentBestReplyUci': 'g1f3',
          'evalAfterReplyCp': -120,
          'opponentPunishmentLineUci': ['g1f3', 'b8c6', 'f1b5'],
          'bestLineUci': ['c7c5', 'g1f3'],
        },
        {
          'plyIndex': 2,
          'san': 'Nf3',
          'bestMoveUci': 'd1h5',
          'bestMoveSan': 'Qh5',
          'evalBeforeCp': -95,
          'evalAfterCp': -410,
          'lossCp': 315,
          'quality': 'blunder',
          'opponentBestReplyUci': 'd8h4',
        },
      ],
    });

    final result = await EngineApiClient(transport: transport)
        .analyzeGame(_sampleAnalysis());

    expect(result.moves, hasLength(3));
    expect(result.mistakes, 1);
    expect(result.blunders, 1);
    expect(result.inaccuracies, 0);
    expect(result.worstMove!.san, 'Nf3');
    expect(result.worstMove!.lossCp, 315);
    expect(result.moves[1].opponentBestReplyUci, 'g1f3');
    expect(result.moves[1].evalAfterReplyCp, -120);
    expect(result.moves[1].opponentPunishmentLineUci, ['g1f3', 'b8c6', 'f1b5']);
    expect(result.moves[1].bestLineUci, ['c7c5', 'g1f3']);
  });

  test('invalid reconstructed games are never sent to the engine', () async {
    final parser = PgnParser();
    final game = parser.parse('1. e4 e5 2. ThisIsNotLegal *').single;
    final analysis = const PersonalGameAnalyzer().analyze(game);
    final transport = _FakeTransport({'moves': <Map<String, dynamic>>[]});

    expect(analysis.isValid, isFalse);
    await expectLater(
      EngineApiClient(transport: transport).analyzeGame(analysis),
      throwsA(isA<EngineApiException>()),
    );
    expect(transport.lastBody, isNull);
  });

  test('missing moves list is rejected instead of invented', () async {
    final transport = _FakeTransport({'status': 'ok'});

    await expectLater(
      EngineApiClient(transport: transport).analyzeGame(_sampleAnalysis()),
      throwsA(isA<EngineApiException>()),
    );
  });
}
