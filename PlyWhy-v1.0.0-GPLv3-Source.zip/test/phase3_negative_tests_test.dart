import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';

import 'helpers/chess_fixture_validator.dart';
import 'helpers/real_stockfish_validator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const fixtureValidator = ChessFixtureValidator();
  const positionValidator = RealPositionValidator();

  group('Phase 3 - Production Negative Testing Suite (Rejecting Defective Evidence)', () {
    test('1. Rejects illegal move in FEN position', () {
      const fenBefore = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const illegalSan = 'Qxh7'; // Queen cannot reach h7 on move 1

      final val = fixtureValidator.validate(
        fenBefore: fenBefore,
        sanPlayed: illegalSan,
        fenAfter: fenBefore,
      );

      expect(val.isValid, isFalse);
      expect(val.error, contains('illegal or invalid'));
    });

    test('2. Rejects incorrect move numbering that ignores FEN fullmove field', () {
      const pgnKd5 = ParsedPgnGame(
        headers: {'FEN': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44'},
        sanMoves: ['Kd5'],
        result: '0-1',
      );

      final analysis = const PersonalGameAnalyzer().analyze(pgnKd5);
      final move = analysis.moves.first;

      // Must NOT compute moveNumber as 1 for fullmove 44 FEN!
      expect(move.moveNumber, equals(44));
      expect(move.moveLabel, equals('44... Kd5'));
      expect(move.moveLabel, isNot(equals('1... Kd5')));
    });

    test('3. Rejects position with missing Stockfish evaluation as INCONCLUSIVE', () {
      const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const evalBeforeMissing = RealEngineEval(
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        pvUci: [],
      );
      const evalAfterMissing = RealEngineEval(
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        pvUci: [],
      );

      final res = positionValidator.validatePosition(
        id: 1,
        fenBefore: fen,
        playedSan: 'e4',
        evalBefore: evalBeforeMissing,
        evalAfter: evalAfterMissing,
      );

      expect(res.outcome, equals('INCONCLUSIVE'));
      expect(res.failureReason, contains('Missing engine score'));
    });

    test('4. Rejects explanations containing unproven tactical claims', () {
      const fenBefore = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const evalBefore = RealEngineEval(
        scoreCp: 20,
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        pvUci: ['e2e4', 'e7e5'],
      );
      const evalAfter = RealEngineEval(
        scoreCp: 20,
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        pvUci: ['e7e5'],
      );

      final res = positionValidator.validatePosition(
        id: 1,
        fenBefore: fenBefore,
        playedSan: 'e4',
        evalBefore: evalBefore,
        evalAfter: evalAfter,
      );

      // Verify no unproven claims exist in explanation
      expect(res.explanationWhyItWorks, isNot(contains('increased opponent mobility')));
      expect(res.explanationConsequence, isNot(contains('forces a concession')));
      expect(res.outcome, equals('PASSED'));
    });

    test('5. Rejects best move generating Pattern Cards', () {
      const fenBefore = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const evalBefore = RealEngineEval(
        scoreCp: 20,
        bestMoveUci: 'e2e4',
        bestMoveSan: 'e4',
        pvUci: ['e2e4', 'e7e5'],
      );
      const evalAfter = RealEngineEval(
        scoreCp: 20,
        bestMoveUci: 'e7e5',
        bestMoveSan: 'e5',
        pvUci: ['e7e5'],
      );

      final res = positionValidator.validatePosition(
        id: 1,
        fenBefore: fenBefore,
        playedSan: 'e4',
        evalBefore: evalBefore,
        evalAfter: evalAfter,
      );

      // Best move MUST equal 'best' quality and produce 0 cards (outcome PASSED)
      expect(res.quality, equals('best'));
      expect(res.outcome, equals('PASSED'));
    });

    test('6. Rejects corrupt persisted Pattern Cards payload', () async {
      SharedPreferences.setMockInitialValues({
        PatternCardStore.key: 'invalid json string payload',
      });

      final store = PatternCardStore();
      expect(() => store.loadAll(), throwsStateError);
    });

    test('7. Rejects EngineGameResult.fromJson with missing or duplicate plyIndex', () {
      expect(
        () => EngineGameResult.fromJson({'invalidKey': []}),
        throwsA(isA<EngineApiException>()),
      );

      expect(
        () => EngineGameResult.fromJson({
          'moves': [
            {'plyIndex': 0, 'san': 'e4'},
            {'plyIndex': 0, 'san': 'e5'}, // Duplicate plyIndex 0
          ]
        }),
        throwsA(isA<EngineApiException>()),
      );
    });

    test('8. Black-to-move custom FEN filtering creates card for playerIsWhite: false, 0 cards for playerIsWhite: true', () {
      const pgnGame = ParsedPgnGame(
        headers: {'FEN': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44', 'White': 'PlayerA', 'Black': 'PlayerB', 'Date': '2026.10.16'},
        sanMoves: ['Kd5'],
        result: '0-1',
      );

      final analysis = const PersonalGameAnalyzer().analyze(pgnGame);
      final engineResult = EngineGameResult.fromJson({
        'moves': [
          {
            'plyIndex': 0,
            'san': 'Kd5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -4865,
            'evalAfterKind': 'cp',
            'evalAfterCp': -3097,
            'lossCp': 1768,
            'quality': 'blunder',
            'opponentBestReplyUci': 'b3a4',
          }
        ]
      });

      // When playerIsWhite is false (Player is Black): card IS generated
      final blackCards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: false,
      );
      expect(blackCards, hasLength(1));

      // When playerIsWhite is true (Player is White): 0 cards generated
      final whiteCards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );
      expect(whiteCards, isEmpty);
    });

    test('9. PatternCardStore loadAll preserves valid card and scheduling progress intact when card is valid', () async {
      const validCard = PatternCard(
        schemaVersion: 2,
        id: 'valid_card_1',
        sourceGame: 'Game #1',
        moveLabel: '44... Kd5',
        fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
        wrongMove: 'Kd5',
        correctMoveUci: 'c5b5',
        opponentReplyUci: 'b3a4',
        lessonTitle: 'Endgame King Activity',
        whatFailed: 'By playing 44... Kd5 (Kd5), this move gave away central king activity.',
        punishment: 'After Kd5, the strongest reply is Ka4 attacking a5.',
        whyItWorks: 'Stockfish shows Ka4 attacks the a5 pawn.',
        consequence: 'The error reduced your advantage in the endgame.',
        betterChoice: 'Instead of Kd5, Stockfish preferred Kb5.',
        lessonText: 'Keep your king active on key control squares.',
        reflectionQuestion: 'Before playing Kd5, did you check which key squares were left undefended?',
        flipped: true,
        repetitions: 3,
        intervalDays: 7,
        dueAtMs: 1700000000000,
      );

      SharedPreferences.setMockInitialValues({
        PatternCardStore.key: jsonEncode([validCard.toJson()]),
      });

      final store = PatternCardStore();
      final loaded = await store.loadAll();

      expect(loaded, hasLength(1));
      final card = loaded.first;
      expect(card.id, equals('valid_card_1'));
      expect(card.repetitions, equals(3));
      expect(card.intervalDays, equals(7));
      expect(card.dueAtMs, equals(1700000000000));
    });
  });
}
