import 'package:flutter_test/flutter_test.dart';

import 'helpers/chess_fixture_validator.dart';

void main() {
  const validator = ChessFixtureValidator();

  group('ChessFixtureValidator - Negative Control Tests (Point 1)', () {
    test('1. Rejects invalid FEN with rank "PP1PPPPPB"', () {
      const invalidFen = 'rnbqkbnr/pppppppp/8/8/2P5/8/PP1PPPPPB/RNBQKBNR b KQkq - 0 1';
      final result = validator.validate(
        fenBefore: invalidFen,
        sanPlayed: 'e5',
        fenAfter: 'rnbqkbnr/pppp1ppp/8/4p3/2P5/8/PP1PPPPPB/RNBQKBNR w KQkq - 0 2',
      );

      expect(result.isValid, isFalse);
      expect(result.error, contains('Rank 7 of FEN must contain 8 squares, but got 9: "PP1PPPPPB"'));
    });

    test('2. Rejects Qxd5 as illegal SAN move when white pawn on d2 blocks queen on d1', () {
      // Pawn on d2 blocks Queen on d1 from reaching d5!
      const blockedFen = 'r1bqkbnr/ppp1pppp/2n5/3p4/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 3';
      final result = validator.validate(
        fenBefore: blockedFen,
        sanPlayed: 'Qxd5',
        fenAfter: 'r1bqkbnr/ppp1pppp/2n5/3Q4/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 0 3',
      );

      expect(result.isValid, isFalse);
      expect(result.error, contains('SAN move "Qxd5" is illegal or invalid in starting FEN'));
    });

    test('3. Rejects fixture with incorrect halfmove clock after a capture', () {
      // FEN after capture exd5 MUST have halfmove clock = 0! If fixture specifies 1, reject!
      const fenBefore = 'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2';
      const wrongFenAfter = 'rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 1 2'; // halfmove clock 1 is wrong!

      final result = validator.validate(
        fenBefore: fenBefore,
        sanPlayed: 'exd5',
        fenAfter: wrongFenAfter,
      );

      expect(result.isValid, isFalse);
      expect(result.error, contains('does NOT match expected fenAfter'));
    });
  });
}
