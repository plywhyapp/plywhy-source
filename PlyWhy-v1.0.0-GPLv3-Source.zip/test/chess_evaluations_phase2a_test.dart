import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../tools/engine_server.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('Phase 2A - PatternCardStore Preventative Fix (Point 1)', () {
    test('throws StateError when main key is empty/null AND backup keys exist but all are corrupted', () async {
      final prefs = await SharedPreferences.getInstance();

      // Main key is empty
      await prefs.setString(PatternCardStore.key, '');

      // Backup key exists but contains corrupted JSON
      await prefs.setString('${PatternCardStore.backupKeyPrefix}1700000000000', '{corrupted_backup_json');

      final store = PatternCardStore();

      // Must throw StateError describing empty main key with corrupted backups
      expect(
        () async => await store.loadAll(includeArchived: true),
        throwsA(isA<StateError>()),
      );
    });
  });

  group('Phase 2A - Negative Mate Distance Formatting Sanitization (Point 2)', () {
    test('sanitizes negative mate distances into strictly positive mateInMoves and clean display formatting', () {
      final sEvalNegMate = StructuredEvaluation.mate(moves: -13, winner: 'black');

      expect(sEvalNegMate.kind, equals(EvalKind.mate));
      expect(sEvalNegMate.mateInMoves, equals(13)); // Strictly positive!
      expect(sEvalNegMate.winnerColor, equals('black'));

      // From Black perspective (forWhite: false)
      expect(sEvalNegMate.formatDisplay(forWhite: false), equals('+M13'));
      // From White perspective (forWhite: true)
      expect(sEvalNegMate.formatDisplay(forWhite: true), equals('-M13'));

      // Verification: NEVER contains minus inside M string (e.g. +M-13)
      expect(sEvalNegMate.formatDisplay(forWhite: false), isNot(contains('-13')));
      expect(sEvalNegMate.formatDisplay(forWhite: true), isNot(contains('M-')));
    });
  });

  group('Phase 2A - Direct Execution of classifyMoveQuality Real Classifier', () {
    const fenWhite = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    const fenBlack = '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44';

    test('prolonged mate (M2 -> M20) is classified as inaccuracy with lossCp = 0 (no fictive cp)', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(2),  // Active player has M2
        afterEval: const EngineEvalScore.mate(-20), // Opponent has M20 after move -> active player has M20
        bestMoveUci: 'c1d1',
      );

      expect(res.quality, equals('inaccuracy'));
      expect(res.lossCp, equals(0)); // Strictly 0! No fictive centipawns
    });

    test('accelerated mate (M4 -> M2) is classified as best with lossCp = 0', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(4),  // Active player had M4
        afterEval: const EngineEvalScore.mate(-2),  // Active player now has M2
        bestMoveUci: 'a1b1',
      );

      expect(res.quality, equals('best'));
      expect(res.lossCp, equals(0));
    });

    test('lost forced winning mate into opponent mate is classified as blunder', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(2),  // Active player had winning M2
        afterEval: const EngineEvalScore.mate(3),   // Opponent now has M3
        bestMoveUci: 'c1d1',
      );

      expect(res.quality, equals('blunder'));
      expect(res.lossCp, equals(0));
    });

    test('losing winning mate into centipawns is classified as blunder', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(2),
        afterEval: const EngineEvalScore.cp(-100), // Active player lost forced mate into +1.0 cp for opponent
        bestMoveUci: 'c1d1',
      );

      expect(res.quality, equals('blunder'));
      expect(res.lossCp, equals(0));
    });

    test('escaped opponent mate into centipawns is classified as best', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(-2), // Active player was getting mated
        afterEval: const EngineEvalScore.cp(0),      // Active player escaped mate into equal position
        bestMoveUci: 'a1b1',
      );

      expect(res.quality, equals('best'));
      expect(res.lossCp, equals(0));
    });

    test('good defense prolongs opponent mate (opponent M2 -> M5) is classified as good', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.mate(-2), // Opponent had M2
        afterEval: const EngineEvalScore.mate(5),   // Opponent now has M5
        bestMoveUci: 'c1d1',
      );

      expect(res.quality, equals('good'));
      expect(res.lossCp, equals(0));
    });

    test('unknown evaluation returns quality unknown and lossCp = 0', () {
      final res = classifyMoveQuality(
        fenBefore: fenWhite,
        uciPlayed: 'a1b1',
        playedSan: 'Kb1',
        beforeEval: const EngineEvalScore.unknown(),
        afterEval: const EngineEvalScore.cp(100),
        bestMoveUci: 'c1d1',
      );

      expect(res.quality, equals('unknown'));
      expect(res.lossCp, equals(0));
    });

    test('Black perspective centipawn evaluation normalization', () {
      final res = classifyMoveQuality(
        fenBefore: fenBlack, // Black turn
        uciPlayed: 'c5d5',
        playedSan: 'Kd5',
        beforeEval: const EngineEvalScore.cp(150),
        afterEval: const EngineEvalScore.cp(-50), // Black is +50
        bestMoveUci: 'c5b5',
      );

      expect(res.lossCp, equals(100)); // 150 - 50 = 100 cp loss
      expect(res.quality, equals('inaccuracy'));
    });
  });

  group('Phase 2A - Full End-to-End Integration Flow', () {
    final game = PgnParser().parse('''
[White "richard63"]
[Black "ajb009"]
[Result "0-1"]

1. e4 e5 2. Nf3 Nc6 *
''').single;
    final analysis = const PersonalGameAnalyzer().analyze(game);

    test('Case 1: Tactical blunder with material loss creates a Pattern Card', () {
      final resultJson = {
        'moves': [
          {
            'plyIndex': 0,
            'san': 'e4',
            'bestMoveUci': 'd2d4',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': 20,
            'evalAfterKind': 'cp',
            'evalAfterCp': -330,
            'lossCp': 350,
            'quality': 'blunder',
            'opponentBestReplyUci': 'd7d5',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );

      expect(cards, hasLength(1));
      expect(cards.first.wrongMove, equals('e4'));
    });

    test('Case 2: Positional inaccuracy with centipawn loss creates a Pattern Card', () {
      final resultJson = {
        'moves': [
          {
            'plyIndex': 0,
            'san': 'e4',
            'bestMoveUci': 'd2d4',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': 20,
            'evalAfterKind': 'cp',
            'evalAfterCp': -60,
            'lossCp': 80,
            'quality': 'inaccuracy',
            'opponentBestReplyUci': 'd7d5',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );

      expect(cards, hasLength(1));
    });

    test('Case 3: Correct move without loss creates NO Pattern Card', () {
      final resultJson = {
        'moves': [
          {
            'plyIndex': 0,
            'san': 'e4',
            'bestMoveUci': 'e2e4',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': 20,
            'evalAfterKind': 'cp',
            'evalAfterCp': 20,
            'lossCp': 0,
            'quality': 'best',
            'opponentBestReplyUci': 'e7e5',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );

      expect(cards, isEmpty);
    });

    test('Case 4: Error with mate evaluation (lossCp = 0) DOES create a Pattern Card', () {
      final resultJson = {
        'moves': [
          {
            'plyIndex': 0,
            'san': 'h3',
            'bestMoveUci': 'd2d4',
            'evalBeforeKind': 'mate',
            'evalBeforeValue': 2,
            'evalBeforeWinner': 'white',
            'evalBeforeCp': null,
            'evalAfterKind': 'mate',
            'evalAfterValue': 20,
            'evalAfterWinner': 'white',
            'evalAfterCp': null,
            'lossCp': 0, // Loss is NOT in centipawns!
            'quality': 'inaccuracy',
            'opponentBestReplyUci': 'e7e5',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );

      // Must NOT disappear from training queue!
      expect(cards, hasLength(1));
    });

    test('Case 5: Unknown evaluation creates NO Pattern Card', () {
      final resultJson = {
        'moves': [
          {
            'plyIndex': 0,
            'san': 'e4',
            'bestMoveUci': 'e2e4',
            'evalBeforeKind': 'unknown',
            'evalBeforeCp': null,
            'evalAfterKind': 'unknown',
            'evalAfterCp': null,
            'lossCp': 0,
            'quality': 'unknown',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: true,
      );

      expect(cards, isEmpty);
    });

    test('Case 6: Authentic Stockfish context regression for 44... Kb5 in richard63 vs ajb009', () {
      // Authentic game move at plyIndex 87 (move 44... Black to move)
      const move87 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kb5',
        fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
        fenAfter: '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45',
        annotation: '',
      );

      final analysis87 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {
            'White': 'richard63',
            'Black': 'ajb009',
            'Date': '2026.10.13',
            'Event': 'Lichess game',
          },
          sanMoves: ['Kb5'],
          result: '0-1',
        ),
        moves: [move87],
      );

      // Authentic Stockfish response JSON for 44... Kb5
      final resultJson = {
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kb5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -2140,
            'evalAfterKind': 'mate',
            'evalAfterValue': -13,
            'evalAfterWinner': 'black',
            'evalAfterCp': null,
            'lossCp': 0,
            'quality': 'best',
            'opponentBestReplyUci': 'b3a2',
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);

      // Verify that when playerIsWhite is false (matching Black move at ply 87),
      // PatternCardBuilder correctly produces 0 cards because 44... Kb5 is the BEST move (quality best)!
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis87,
        result: engineResult,
        playerIsWhite: false, // Black player perspective
      );

      expect(cards, isEmpty); // Zero Pattern Cards generated!
    });

    test('Case 7: Authentic Stockfish context for 44... Kd5 blunder (17.68 pawns loss) receives criticism and creates a Pattern Card', () {
      // Authentic Black move at plyIndex 87 where Black blunders Kd5 instead of Kb5
      const moveKd5 = PersonalGameMove(
        plyIndex: 87,
        moveNumber: 44,
        isWhiteMove: false,
        san: 'Kd5',
        fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
        fenAfter: '8/8/8/p2k1p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45',
        annotation: '',
      );

      final analysisKd5 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {
            'White': 'richard63',
            'Black': 'ajb009',
            'Date': '2026.10.13',
            'Event': 'Lichess game',
          },
          sanMoves: ['Kd5'],
          result: '0-1',
        ),
        moves: [moveKd5],
      );

      // Authentic Stockfish response JSON for 44... Kd5 blunder
      final resultJson = {
        'moves': [
          {
            'plyIndex': 87,
            'san': 'Kd5',
            'bestMoveUci': 'c5b5',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -4865,
            'evalAfterKind': 'cp',
            'evalAfterCp': -3097,
            'lossCp': 1768, // Real Stockfish loss: 17.68 pawns!
            'quality': 'blunder',
            'opponentBestReplyUci': 'b3a4',
            'opponentPunishmentLineUci': ['b3a4', 'd5c5'],
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final moveResult = engineResult.moves.first;

      // 1. Verify Explanation receives CRITICISM (NOT praise!)
      final explanation = buildEngineMoveExplanation(moveResult, moveKd5);
      expect(explanation.whatFailed, isNot(contains('top recommended move')));
      expect(explanation.betterChoice, isNot(contains('Stockfish confirmed')));
      expect(explanation.betterChoice, contains('Instead of Kd5, Stockfish preferred'));

      // 2. Verify PatternCardBuilder generates 1 Pattern Card for Kd5 blunder!
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysisKd5,
        result: engineResult,
        playerIsWhite: false,
      );

      expect(cards, hasLength(1));
      expect(cards.first.wrongMove, equals('Kd5'));
      expect(cards.first.correctMoveUci, equals('c5b5'));
    });

    test('Case 8: Authentic transition from centipawns to opponent forced mate (3... Nf6?? allowing Qxf7#) is classified as blunder and creates Pattern Card', () {
      // Authentic Black move in Scholar's Mate position where 3... Nf6?? allows 4. Qxf7#
      const moveNf6 = PersonalGameMove(
        plyIndex: 5,
        moveNumber: 3,
        isWhiteMove: false,
        san: 'Nf6',
        fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3',
        fenAfter: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
        annotation: '??',
      );

      final analysisNf6 = PersonalGameAnalysis(
        game: const ParsedPgnGame(
          headers: {
            'White': 'Player1',
            'Black': 'Player2',
            'Date': '2026.10.14',
            'Event': 'Casual Game',
          },
          sanMoves: ['e4', 'e5', 'Qh5', 'Nc6', 'Bc4', 'Nf6'],
          result: '1-0',
        ),
        moves: [moveNf6],
      );

      // Stockfish response JSON: Black had equal/slightly better cp (-40), but Nf6 allows White forced mate in 1 (+M1)
      final resultJson = {
        'moves': [
          {
            'plyIndex': 5,
            'san': 'Nf6',
            'bestMoveUci': 'g7g6',
            'evalBeforeKind': 'cp',
            'evalBeforeCp': -40,
            'evalAfterKind': 'mate',
            'evalAfterValue': 1,
            'evalAfterWinner': 'white',
            'evalAfterCp': null,
            'lossCp': 0, // Loss is in mate, not cp
            'quality': 'blunder',
            'opponentBestReplyUci': 'h5f7',
            'opponentPunishmentLineUci': ['h5f7'],
          }
        ]
      };

      final engineResult = EngineGameResult.fromJson(resultJson);
      final moveResult = engineResult.moves.first;

      // 1. Verify Explanation receives CRITICISM (NOT praise!)
      final explanation = buildEngineMoveExplanation(moveResult, moveNf6);
      expect(explanation.whatFailed, isNot(contains('top recommended move')));
      expect(explanation.betterChoice, isNot(contains('Stockfish confirmed')));
      expect(explanation.betterChoice, contains('Instead of Nf6, Stockfish preferred'));

      // 2. Verify PatternCardBuilder generates 1 Pattern Card for Nf6 blunder!
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysisNf6,
        result: engineResult,
        playerIsWhite: false,
      );

      expect(cards, hasLength(1));
      expect(cards.first.wrongMove, equals('Nf6'));
      expect(cards.first.correctMoveUci, equals('g7g6'));
    });
  });
}
