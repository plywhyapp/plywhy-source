import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/local_stockfish_transport.dart';
import 'package:stockfish/stockfish.dart';

class _FakeStockfish implements Stockfish {
  final _stateNotifier = ValueNotifier<StockfishState>(StockfishState.starting);
  final _stdoutController = StreamController<String>.broadcast();
  final List<String> stdinHistory = [];
  bool autoRespond = false;

  _FakeStockfish({StockfishState initialState = StockfishState.starting}) {
    _stateNotifier.value = initialState;
  }

  void emitStdout(String line) {
    _stdoutController.add(line);
  }

  void setState(StockfishState newState) {
    _stateNotifier.value = newState;
  }

  @override
  Completer<Stockfish>? get completer => null;

  @override
  ValueListenable<StockfishState> get state => _stateNotifier;

  @override
  Stream<String> get stdout => _stdoutController.stream;

  @override
  set stdin(String line) {
    if (state.value != StockfishState.ready) {
      throw StateError('Stockfish is not ready ($state)');
    }
    stdinHistory.add(line);
    if (autoRespond) {
      if (line == 'uci') {
        Timer(const Duration(milliseconds: 10), () {
          emitStdout('uciok\n');
        });
      } else if (line == 'isready') {
        Timer(const Duration(milliseconds: 10), () {
          emitStdout('readyok\n');
        });
      } else if (line.startsWith('go')) {
        Timer(const Duration(milliseconds: 20), () {
          emitStdout('info depth 1 score cp 20 pv e2e4\n');
          emitStdout('bestmove e2e4\n');
        });
      }
    }
  }

  @override
  void dispose() {
    _stateNotifier.dispose();
    _stdoutController.close();
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('UCI Acknowledgment Protocol Tests', () {
    test('1. Missing uciok throws explicit EngineApiException despite StockfishState.ready', () async {
      final fakeEngine = _FakeStockfish(initialState: StockfishState.ready);
      final transport = LocalStockfishTransport.withEngine(
        fakeEngine,
        initTimeout: const Duration(milliseconds: 100),
        forceNative: true,
      );

      // Emit non-uciok line after listener attaches
      Timer(const Duration(milliseconds: 10), () {
        fakeEngine.emitStdout('id name Stockfish\n');
      });

      expect(
        () async => await transport.postJson('/v1/analyze-game', {
          'schemaVersion': 1,
          'moves': [
            {
              'plyIndex': 0,
              'san': 'e4',
              'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
              'fenAfter': 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
            }
          ]
        }),
        throwsA(
          isA<EngineApiException>().having(
            (e) => e.message,
            'message',
            contains('timed out waiting for uciok'),
          ),
        ),
      );
    });

    test('2. Missing readyok throws explicit EngineApiException despite StockfishState.ready', () async {
      final fakeEngine = _FakeStockfish(initialState: StockfishState.ready);
      final transport = LocalStockfishTransport.withEngine(
        fakeEngine,
        initTimeout: const Duration(milliseconds: 100),
        forceNative: true,
      );

      // Emit uciok but NO readyok
      Timer(const Duration(milliseconds: 10), () {
        fakeEngine.emitStdout('uciok\n');
      });

      expect(
        () async => await transport.postJson('/v1/analyze-game', {
          'schemaVersion': 1,
          'moves': [
            {
              'plyIndex': 0,
              'san': 'e4',
              'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
              'fenAfter': 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
            }
          ]
        }),
        throwsA(
          isA<EngineApiException>().having(
            (e) => e.message,
            'message',
            contains('timed out waiting for readyok'),
          ),
        ),
      );
    });

    test('3. StockfishState.ready cannot bypass missing readyok acknowledgment in search', () async {
      final fakeEngine = _FakeStockfish(initialState: StockfishState.ready);
      final transport = LocalStockfishTransport.withEngine(
        fakeEngine,
        initTimeout: const Duration(milliseconds: 500),
        forceNative: true,
      );

      // Respond uciok and readyok for init, but do NOT respond readyok for search isready
      Timer(const Duration(milliseconds: 20), () {
        fakeEngine.emitStdout('uciok\n');
        fakeEngine.emitStdout('readyok\n');
      });

      expect(
        () async => await transport.postJson('/v1/analyze-game', {
          'schemaVersion': 1,
          'moves': [
            {
              'plyIndex': 0,
              'san': 'e4',
              'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
              'fenAfter': 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
            }
          ]
        }),
        throwsA(
          isA<EngineApiException>().having(
            (e) => e.message,
            'message',
            contains('isready timed out waiting for readyok'),
          ),
        ),
      );
    });

    test('4. Successful acknowledgment sequence (uci -> uciok -> isready -> readyok)', () async {
      final fakeEngine = _FakeStockfish(initialState: StockfishState.ready);
      fakeEngine.autoRespond = true;

      final transport = LocalStockfishTransport.withEngine(
        fakeEngine,
        initTimeout: const Duration(milliseconds: 500),
        forceNative: true,
      );

      final result = await transport.postJson('/v1/analyze-game', {
        'schemaVersion': 1,
        'moves': [
          {
            'plyIndex': 0,
            'san': 'e4',
            'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
            'fenAfter': 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
          }
        ]
      });

      expect(result['moves'], isNotEmpty);
      expect(fakeEngine.stdinHistory, contains('uci'));
      expect(fakeEngine.stdinHistory, contains('isready'));
    });
  });
}
