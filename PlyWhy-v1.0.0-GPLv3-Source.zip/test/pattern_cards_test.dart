import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:chess_sense/screens/pattern_cards_screen.dart';
import 'package:chess_sense/screens/pattern_transfer_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

PersonalGameAnalysis _game() {
  final game = PgnParser().parse('''
[White "Ada"]
[Black "Grace"]
[Date "2026.10.09"]
[Result "*"]

1. e4 e5 *
''').single;
  return const PersonalGameAnalyzer().analyze(game);
}

List<PatternCard> _cards() => const PatternCardBuilder().fromGame(
  analysis: _game(),
  result: const EngineGameResult(moves: [
    EngineMoveResult(
      plyIndex: 0,
      san: 'e4',
      bestMoveUci: 'd2d4',
      bestMoveSan: 'd4',
      evalBeforeCp: 0,
      evalAfterCp: -180,
      lossCp: 180,
      quality: EngineMoveQuality.mistake,
      opponentBestReplyUci: 'd7d5',
    ),
    EngineMoveResult(
      plyIndex: 1,
      san: 'e5',
      bestMoveUci: 'c7c5',
      bestMoveSan: 'c5',
      evalBeforeCp: 0,
      evalAfterCp: -180,
      lossCp: 180,
      quality: EngineMoveQuality.mistake,
      opponentBestReplyUci: 'g1f3',
    ),
  ]),
  playerIsWhite: true,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('does not generate an unsolvable card from an illegal engine recommendation', () {
    final cards = const PatternCardBuilder().fromGame(
      analysis: _game(),
      result: const EngineGameResult(moves: [
        EngineMoveResult(
          plyIndex: 0,
          san: 'e4',
          bestMoveUci: 'a1a8',
          bestMoveSan: null,
          evalBeforeCp: 0,
          evalAfterCp: -300,
          lossCp: 300,
          quality: EngineMoveQuality.mistake,
          opponentBestReplyUci: 'e7e5',
        ),
      ]),
      playerIsWhite: true,
    );
    expect(cards, isEmpty);
  });

  testWidgets('corrupt card storage shows an error without claiming an empty collection', (tester) async {
    SharedPreferences.setMockInitialValues({PatternCardStore.key: 'broken JSON'});
    await tester.pumpWidget(const MaterialApp(home: PatternCardsScreen()));
    await tester.pumpAndSettle();
    expect(find.textContaining('Could not load Pattern Cards:'), findsOneWidget);
    expect(find.text('No Pattern Cards yet'), findsNothing);
    expect(find.text('All due cards reviewed'), findsNothing);
  });

  test('generates only own mistakes, with real board and opponent reply', () {
    final cards = _cards();
    expect(cards, hasLength(1));
    expect(cards.single.moveLabel, '1. e4');
    expect(cards.single.fenBefore, contains('rnbqkbnr'));
    expect(cards.single.opponentReplyUci, 'd7d5');
    expect(cards.single.sourceGame, contains('Ada vs Grace'));
  });

  test('merging the same game preserves existing spaced-review progress', () async {
    final store = PatternCardStore();
    final original = _cards().single;
    await store.upsertAll([original]);
    final reviewed = original.graded(PatternGrade.good, DateTime(2026, 10, 9));
    await store.saveGrade(reviewed);
    final merged = await store.upsertAll(_cards());
    expect(merged, hasLength(1));
    expect(merged.single.repetitions, 1);
    expect(merged.single.intervalDays, 3);
    expect(merged.single.dueAtMs, reviewed.dueAtMs);
  });

  test('again/hard/good produce distinct review intervals', () {
    final now = DateTime(2026, 10, 9, 9);
    final card = _cards().single;
    expect(card.graded(PatternGrade.again, now).dueAtMs,
      now.add(const Duration(minutes: 10)).millisecondsSinceEpoch);
    expect(card.graded(PatternGrade.hard, now).intervalDays, 1);
    expect(card.graded(PatternGrade.good, now).intervalDays, 3);
  });

  testWidgets('card starts hidden, reveals explanation and records a grade', (tester) async {
    await tester.pumpWidget(MaterialApp(home: PatternCardsScreen(newCards: _cards())));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('pattern-card-board')), findsOneWidget);
    expect(find.text('1. Concrete mistake'), findsNothing);
    final reveal = find.byKey(const ValueKey('pattern-reveal'));
    // The chessboard can be taller than the default 800x600 test viewport.
    // ListView creates children lazily; scrollUntilVisible builds the button
    // before attempting to interact with it.
    await tester.scrollUntilVisible(
      reveal,
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    expect(reveal, findsOneWidget);
    await tester.tap(reveal);
    await tester.pumpAndSettle();
    expect(find.text('1. Concrete mistake'), findsOneWidget);
    expect(find.text('3. Strongest reply'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('Good'),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    
    final goodBtn = find.text('Good');
    expect(goodBtn, findsOneWidget);
    await tester.tap(goodBtn);
    await tester.runAsync(() async {
      await Future.delayed(const Duration(milliseconds: 500));
    });
    await tester.pumpAndSettle();

    if (find.byType(PatternTransferScreen).evaluate().isNotEmpty) {
      await tester.pageBack();
      await tester.pumpAndSettle();
    }

    expect(find.text('All due cards reviewed'), findsOneWidget);
  });
}
