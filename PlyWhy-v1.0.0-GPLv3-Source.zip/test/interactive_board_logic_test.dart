import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/fen_utils.dart';

void main() {
  test('applies a normal UCI move to a parsed board', () {
    const fen = '6k1/8/5n2/7Q/8/8/8/6K1 b - - 0 1';
    final board = parseFenBoard(fen);
    final moved = applyUciMoveToBoard(board, 'f6h5');

    expect(moved['f6'], isNull);
    expect(moved['h5'], '♞');
  });

  test('setup moves can create the post-candidate board for Opponent Vision', () {
    const fen = '6k1/8/8/3p4/5n2/8/8/3Q2K1 w - - 0 1';
    final moved = boardAfterUciMoves(fen, const ['d1d5']);

    expect(moved['d1'], isNull);
    expect(moved['d5'], '♕');
    expect(moved['f4'], '♞');
  });

  test('rejects malformed UCI moves and empty source squares', () {
    final board = parseFenBoard('7k/8/8/8/8/8/8/K7 w - - 0 1');
    expect(() => applyUciMoveToBoard(board, 'z9z1'), throwsFormatException);
    expect(() => applyUciMoveToBoard(board, 'a2a3'), throwsFormatException);
  });
}
