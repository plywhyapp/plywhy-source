import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('human explanation turns UCI into readable move language', () {
    final game = PgnParser().parse('''
[White "Ada"]
[Black "Grace"]
[Result "*"]

1. e4 e5 *
''').single;
    final analysis = const PersonalGameAnalyzer().analyze(game);
    final context = analysis.moves.first;

    const move = EngineMoveResult(
      plyIndex: 0,
      san: 'e4',
      bestMoveUci: 'd2d4',
      bestMoveSan: null,
      evalBeforeCp: 20,
      evalAfterCp: -145,
      lossCp: 165,
      quality: EngineMoveQuality.mistake,
      opponentBestReplyUci: 'd7d5',
      evalAfterReplyCp: -180,
    );

    final explanation = buildEngineMoveExplanation(move, context);

    expect(explanation.betterChoice, contains('move the pawn from d2 to d4'));
    expect(explanation.opponentPunishment, contains('move the pawn from d7 to d5'));
    expect(explanation.whyItWorks, isNotEmpty);
    expect(explanation.consequence, contains('opponent is about 1.8'));
    expect(explanation.lessonTitle, isNotEmpty);
  });

  test('centipawn evaluations never make unsupported forced checkmate claims', () {
    const gameKd5 = ParsedPgnGame(
      headers: {'FEN': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44'},
      sanMoves: ['Kd5'],
      result: '0-1',
    );
    final analysis = const PersonalGameAnalyzer().analyze(gameKd5);
    final context = analysis.moves.first;

    final moveCentipawns = EngineMoveResult.fromJson({
      'plyIndex': 0,
      'san': 'Kd5',
      'bestMoveUci': 'c5b5',
      'evalBeforeKind': 'cp',
      'evalBeforeCp': -1345,
      'evalAfterKind': 'cp',
      'evalAfterCp': -1345,
      'lossCp': 0,
      'quality': 'best',
      'opponentBestReplyUci': 'b3a4',
      'opponentPunishmentLineUci': ['b3a4', 'd5c5', 'a4a5', 'b4b3'],
      'bestLineUci': ['c5b5', 'b3b2', 'a5a4', 'b2c1'],
    });

    final explanation = buildEngineMoveExplanation(moveCentipawns, context);

    // Centipawn evaluation MUST NOT claim forced checkmate!
    expect(explanation.consequence, isNot(contains('forced checkmate')));
    expect(explanation.whyItWorks, isNot(contains('forced checkmate')));
    expect(explanation.betterChoice, isNot(contains('forced checkmate')));
  });

  // Contextual coaching regression: ChessSense must explain the punishment,
  // not merely report an engine move.
  test('mate explanation ends the game and keeps its consequence out of the better line', () {
  final game = PgnParser().parse('''
[White "Ada"]
[Black "Grace"]
[Result "*"]

1. f3 e5 2. g4 *
''').single;
  final analysis = const PersonalGameAnalyzer().analyze(game);
  final context = analysis.moves[2];

  final move = EngineMoveResult(
    plyIndex: 2,
    san: 'g4',
    bestMoveUci: 'e2e4',
    bestMoveSan: null,
    evalBeforeCp: 10,
    evalAfterCp: null,
    structuredEvalBefore: StructuredEvaluation.centipawns(10),
    structuredEvalAfter: StructuredEvaluation.mate(moves: 1, winner: 'black'),
    lossCp: 0,
    quality: EngineMoveQuality.blunder,
    opponentBestReplyUci: 'd8h4',
    opponentPunishmentLineUci: ['d8h4'],
    bestLineUci: ['e2e4', 'b8c6', 'g1f3'],
  );

  final explanation = buildEngineMoveExplanation(move, context);

  expect(explanation.whatFailed, contains('checkmate immediately'));
  expect(explanation.opponentPunishment, contains('move the queen from d8 to h4'));
  expect(explanation.whyItWorks.toLowerCase(), contains('check'));
  expect(explanation.whyItWorks, contains('no legal response'));
  expect(explanation.consequence, contains('no next move'));
  expect(explanation.lessonText, contains('immediate mating reply'));
  expect(explanation.betterChoice, contains('pawn from e2 to e4'));
  expect(explanation.betterChoice, isNot(contains('allows a forced checkmate')));
  expect(explanation.betterChoice, contains('One engine continuation'));
  });
}
