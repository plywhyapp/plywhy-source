import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';

class _TestHttpOverrides extends HttpOverrides {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = _TestHttpOverrides();

  Process? serverProcess;

  setUpAll(() async {
    try {
      final client = HttpClient();
      final req = await client.getUrl(Uri.parse('http://127.0.0.1:8787')).timeout(const Duration(seconds: 1));
      final res = await req.close();
      if (res.statusCode > 0) return;
    } catch (_) {}

    try {
      serverProcess = await Process.start(
        'C:\\src\\flutter\\bin\\cache\\dart-sdk\\bin\\dart.exe',
        ['tools/engine_server.dart'],
      );
      await Future.delayed(const Duration(seconds: 2));
    } catch (_) {}
  });

  tearDownAll(() {
    serverProcess?.kill();
  });

  test('Phase 5: On-device LocalStockfishTransport evaluates game moves natively', () async {
    final client = EngineApiClient.local();

    final moveContext = const PersonalGameMove(
      plyIndex: 0,
      moveNumber: 1,
      isWhiteMove: true,
      san: 'Rxb7',
      annotation: null,
      fenBefore: '2r2rk1/pbq1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 w - - 4 24',
      fenAfter: '2r2rk1/pbR1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/5RK1 b - - 0 24',
    );

    final result = await client.analyzeGame(
      PersonalGameAnalysis(
        game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '*'),
        moves: [moveContext],
      ),
    );

    expect(result.moves.length, equals(1));
    final evalResult = result.moves.first;

    expect(evalResult.plyIndex, equals(0));
    expect(evalResult.san, equals('Rxb7'));
    expect(evalResult.bestMoveUci, isNotEmpty);
    expect(evalResult.lossCp, isNotNull);
    expect(evalResult.quality, isNotNull);

    client.dispose();
  });
}
