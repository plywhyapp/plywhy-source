import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:chess/chess.dart' as chess_lib;
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';

import 'chess_fixture_validator.dart';

class RealEngineEval {
  final int? scoreCp;       // White-relative centipawns
  final int? mateInMoves;   // Positive = White wins, negative = Black wins
  final int? achievedDepth; // Actual depth reached by Stockfish
  final String bestMoveUci;
  final String bestMoveSan;
  final List<String> pvUci;
  final String? opponentReplyUci;

  const RealEngineEval({
    this.scoreCp,
    this.mateInMoves,
    this.achievedDepth,
    required this.bestMoveUci,
    required this.bestMoveSan,
    required this.pvUci,
    this.opponentReplyUci,
  });
}

class RealStockfishService {
  Process? _process;
  StreamSubscription<String>? _sub;
  Completer<List<String>>? _completer;
  final List<String> _lines = [];

  static File? findExecutable() {
    final root = Directory.current;
    final engineFile = File(
      '${root.path}${Platform.pathSeparator}tools${Platform.pathSeparator}.stockfish${Platform.pathSeparator}stockfish${Platform.pathSeparator}stockfish-windows-x86-64-universal.exe',
    );
    if (engineFile.existsSync()) return engineFile;

    final engineDir = Directory('${root.path}${Platform.pathSeparator}tools${Platform.pathSeparator}.stockfish');
    if (!engineDir.existsSync()) return null;

    final matches = engineDir
        .listSync(recursive: true)
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.exe'))
        .toList();

    return matches.isEmpty ? null : matches.first;
  }

  Future<bool> start() async {
    final exe = findExecutable();
    if (exe == null || !exe.existsSync()) return false;

    try {
      _process = await Process.start(exe.path, []);
      _sub = _process!.stdout
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .listen((line) {
        _lines.add(line);
        if (_completer != null && !_completer!.isCompleted) {
          if (line.startsWith('bestmove') || line == 'uciok' || line == 'readyok') {
            _completer!.complete(List<String>.from(_lines));
          }
        }
      });

      _lines.clear();
      _completer = Completer<List<String>>();
      _process!.stdin.writeln('uci');
      final uciRes = await _completer!.future.timeout(const Duration(seconds: 3), onTimeout: () => []);
      if (!uciRes.contains('uciok')) return false;

      _lines.clear();
      _completer = Completer<List<String>>();
      _process!.stdin.writeln('isready');
      final readyRes = await _completer!.future.timeout(const Duration(seconds: 3), onTimeout: () => []);
      if (!readyRes.contains('readyok')) return false;

      return true;
    } catch (_) {
      return false;
    }
  }

  Future<RealEngineEval> evaluatePosition(String fen, {int depth = 12, int movetimeMs = 150, int retries = 2}) async {
    if (_process == null) throw StateError('Stockfish process is not running');

    for (var attempt = 0; attempt < retries; attempt++) {
      try {
        _lines.clear();
        _completer = Completer<List<String>>();

        _process!.stdin.writeln('position fen $fen');
        _process!.stdin.writeln('go depth $depth movetime $movetimeMs');

        final output = await _completer!.future.timeout(
          Duration(milliseconds: movetimeMs + 3000),
          onTimeout: () => List<String>.from(_lines),
        );

        if (output.any((l) => l.startsWith('bestmove'))) {
          return _parseUciOutput(fen, output);
        }
      } catch (_) {}
    }
    throw TimeoutException('Stockfish evaluation timed out for FEN: $fen');
  }

  RealEngineEval _parseUciOutput(String fen, List<String> output) {
    String bestMoveUci = '';
    int? scoreCp;
    int? mateInMoves;
    int? achievedDepth;
    List<String> pvUci = [];

    final chessBoard = chess_lib.Chess.fromFEN(fen);
    final isWhiteTurn = chessBoard.turn == chess_lib.Color.WHITE;

    for (final line in output) {
      if (line.startsWith('bestmove')) {
        final parts = line.split(' ');
        if (parts.length >= 2) bestMoveUci = parts[1].trim();
      } else if (line.startsWith('info')) {
        final parts = line.split(' ');
        final dIdx = parts.indexOf('depth');
        if (dIdx != -1 && dIdx + 1 < parts.length) {
          final parsedD = int.tryParse(parts[dIdx + 1]);
          if (parsedD != null && parsedD > 0) achievedDepth = parsedD;
        }

        if (line.contains('score')) {
          final scoreIdx = parts.indexOf('score');
          if (scoreIdx != -1 && scoreIdx + 2 < parts.length) {
            final type = parts[scoreIdx + 1];
            final val = int.tryParse(parts[scoreIdx + 2]);
            if (val != null) {
              if (type == 'cp') {
                scoreCp = isWhiteTurn ? val : -val;
              } else if (type == 'mate') {
                mateInMoves = isWhiteTurn ? val : -val;
              }
            }
          }
          final pvIdx = parts.indexOf('pv');
          if (pvIdx != -1 && pvIdx + 1 < parts.length) {
            pvUci = parts.sublist(pvIdx + 1);
          }
        }
      }
    }

    final bestMoveSan = humanizeUciMove(fen, bestMoveUci);

    String? opponentReplyUci;
    if (pvUci.length >= 2) {
      opponentReplyUci = pvUci[1];
    }

    return RealEngineEval(
      scoreCp: scoreCp,
      mateInMoves: mateInMoves,
      achievedDepth: achievedDepth,
      bestMoveUci: bestMoveUci,
      bestMoveSan: bestMoveSan,
      pvUci: pvUci,
      opponentReplyUci: opponentReplyUci,
    );
  }

  void stop() {
    _sub?.cancel();
    try {
      _process?.stdin.writeln('quit');
      _process?.kill();
    } catch (_) {}
    _process = null;
  }
}

class RealPositionValidationResult {
  final int id;
  final String fen;
  final String playedSan;
  final String category;
  final bool isWhite;
  final String engineVersion;
  final String engineSettings;
  final int? achievedDepth;
  final String evalBeforeKind;
  final int? evalBeforeValue;
  final String evalAfterKind;
  final int? evalAfterValue;
  final int lossCp;
  final String quality;
  final String bestMoveUci;
  final String bestMoveSan;
  final List<String> pvUci;
  final String explanationWhatFailed;
  final String explanationBetterChoice;
  final String explanationWhyItWorks;
  final String explanationConsequence;
  final String outcome; // 'PASSED', 'FAILED', 'INCONCLUSIVE'
  final String? failureReason;

  const RealPositionValidationResult({
    required this.id,
    required this.fen,
    required this.playedSan,
    required this.category,
    required this.isWhite,
    required this.engineVersion,
    required this.engineSettings,
    this.achievedDepth,
    required this.evalBeforeKind,
    this.evalBeforeValue,
    required this.evalAfterKind,
    this.evalAfterValue,
    required this.lossCp,
    required this.quality,
    required this.bestMoveUci,
    required this.bestMoveSan,
    required this.pvUci,
    required this.explanationWhatFailed,
    required this.explanationBetterChoice,
    required this.explanationWhyItWorks,
    required this.explanationConsequence,
    required this.outcome,
    this.failureReason,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'fen': fen,
    'playedSan': playedSan,
    'category': category,
    'isWhite': isWhite,
    'engineVersion': engineVersion,
    'engineSettings': engineSettings,
    'achievedDepth': achievedDepth,
    'evalBeforeKind': evalBeforeKind,
    'evalBeforeValue': evalBeforeValue,
    'evalAfterKind': evalAfterKind,
    'evalAfterValue': evalAfterValue,
    'lossCp': lossCp,
    'quality': quality,
    'bestMoveUci': bestMoveUci,
    'bestMoveSan': bestMoveSan,
    'pvUci': pvUci,
    'explanationWhatFailed': explanationWhatFailed,
    'explanationBetterChoice': explanationBetterChoice,
    'explanationWhyItWorks': explanationWhyItWorks,
    'explanationConsequence': explanationConsequence,
    'outcome': outcome,
    'failureReason': failureReason,
  };

  factory RealPositionValidationResult.fromJson(Map<String, dynamic> json) => RealPositionValidationResult(
    id: (json['id'] as num).toInt(),
    fen: json['fen'] as String,
    playedSan: json['playedSan'] as String,
    category: json['category'] as String,
    isWhite: json['isWhite'] as bool,
    engineVersion: json['engineVersion'] as String? ?? 'Stockfish 19',
    engineSettings: json['engineSettings'] as String? ?? 'requested depth 12',
    achievedDepth: (json['achievedDepth'] as num?)?.toInt(),
    evalBeforeKind: json['evalBeforeKind'] as String? ?? 'cp',
    evalBeforeValue: (json['evalBeforeValue'] as num?)?.toInt(),
    evalAfterKind: json['evalAfterKind'] as String? ?? 'cp',
    evalAfterValue: (json['evalAfterValue'] as num?)?.toInt(),
    lossCp: (json['lossCp'] as num).toInt(),
    quality: json['quality'] as String,
    bestMoveUci: json['bestMoveUci'] as String? ?? '',
    bestMoveSan: json['bestMoveSan'] as String? ?? '',
    pvUci: (json['pvUci'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? const [],
    explanationWhatFailed: json['explanationWhatFailed'] as String? ?? '',
    explanationBetterChoice: json['explanationBetterChoice'] as String? ?? '',
    explanationWhyItWorks: json['explanationWhyItWorks'] as String? ?? '',
    explanationConsequence: json['explanationConsequence'] as String? ?? '',
    outcome: json['outcome'] as String,
    failureReason: json['failureReason'] as String?,
  );
}

class RealPositionValidator {
  const RealPositionValidator();

  /// Validates a single position against real Stockfish evaluations and ChessSense explanations.
  RealPositionValidationResult validatePosition({
    required int id,
    required String fenBefore,
    required String playedSan,
    required RealEngineEval evalBefore,
    required RealEngineEval evalAfter,
  }) {
    const fixtureValidator = ChessFixtureValidator();

    // 1. Verify FEN and move legality
    final chessBoard = chess_lib.Chess.fromFEN(fenBefore);
    final isWhite = chessBoard.turn == chess_lib.Color.WHITE;

    final fenFields = fenBefore.trim().split(RegExp(r'\s+'));
    final fullmoveNumber = fenFields.length >= 6 ? (int.tryParse(fenFields[5]) ?? 1) : 1;

    final moveSuccess = chessBoard.move(playedSan);
    if (!moveSuccess) {
      return RealPositionValidationResult(
        id: id,
        fen: fenBefore,
        playedSan: playedSan,
        category: 'Invalid Move',
        isWhite: isWhite,
        engineVersion: 'Stockfish 19',
        engineSettings: 'requested depth 12, achieved depth ${evalBefore.achievedDepth ?? "UNKNOWN"}',
        achievedDepth: evalBefore.achievedDepth,
        evalBeforeKind: 'unknown',
        evalBeforeValue: null,
        evalAfterKind: 'unknown',
        evalAfterValue: null,
        lossCp: 0,
        quality: 'unknown',
        bestMoveUci: '',
        bestMoveSan: '',
        pvUci: const [],
        explanationWhatFailed: '',
        explanationBetterChoice: '',
        explanationWhyItWorks: '',
        explanationConsequence: '',
        outcome: 'FAILED',
        failureReason: 'Played SAN "$playedSan" is illegal in FEN "$fenBefore"',
      );
    }

    final fenAfter = chessBoard.generate_fen();
    final isCheckmate = chessBoard.in_checkmate;

    var oppReply = evalAfter.bestMoveUci;
    if (oppReply == '(none)' || oppReply == '0000') {
      oppReply = '';
    } else if (oppReply.length == 4) {
      final from = oppReply.substring(0, 2);
      final to = oppReply.substring(2, 4);
      final piece = chessBoard.get(from);
      if (piece != null && piece.type == chess_lib.PieceType.PAWN && (to.endsWith('1') || to.endsWith('8'))) {
        oppReply = '${oppReply}q';
      }
    }

    // 2. Validate FEN consistency with ChessFixtureValidator
    final valFixture = fixtureValidator.validate(
      fenBefore: fenBefore,
      sanPlayed: playedSan,
      fenAfter: fenAfter,
      opponentReplyUci: (isCheckmate || oppReply.isEmpty) ? null : oppReply,
    );

    if (!valFixture.isValid) {
      return RealPositionValidationResult(
        id: id,
        fen: fenBefore,
        playedSan: playedSan,
        category: 'Invalid Fixture',
        isWhite: isWhite,
        engineVersion: 'Stockfish 19',
        engineSettings: 'requested depth 12, achieved depth ${evalBefore.achievedDepth ?? "UNKNOWN"}',
        achievedDepth: evalBefore.achievedDepth,
        evalBeforeKind: 'unknown',
        evalBeforeValue: null,
        evalAfterKind: 'unknown',
        evalAfterValue: null,
        lossCp: 0,
        quality: 'unknown',
        bestMoveUci: evalBefore.bestMoveUci,
        bestMoveSan: evalBefore.bestMoveSan,
        pvUci: evalAfter.pvUci,
        explanationWhatFailed: '',
        explanationBetterChoice: '',
        explanationWhyItWorks: '',
        explanationConsequence: '',
        outcome: 'FAILED',
        failureReason: valFixture.error,
      );
    }

    // 3. Genuine evaluation handling preserving Mate vs Centipawn distinction (NO silent conversion to 0 cp!)
    final evalBeforeKind = evalBefore.mateInMoves != null ? 'mate' : (evalBefore.scoreCp != null ? 'cp' : 'unknown');
    final evalBeforeVal = evalBefore.mateInMoves ?? evalBefore.scoreCp;

    final evalAfterKind = evalAfter.mateInMoves != null ? 'mate' : (evalAfter.scoreCp != null ? 'cp' : 'unknown');
    final evalAfterVal = evalAfter.mateInMoves ?? evalAfter.scoreCp;

    if (evalBeforeKind == 'unknown' || evalAfterKind == 'unknown') {
      return RealPositionValidationResult(
        id: id,
        fen: fenBefore,
        playedSan: playedSan,
        category: 'Inconclusive Score',
        isWhite: isWhite,
        engineVersion: 'Stockfish 19',
        engineSettings: 'requested depth 12, achieved depth ${evalBefore.achievedDepth ?? "UNKNOWN"}',
        achievedDepth: evalBefore.achievedDepth,
        evalBeforeKind: evalBeforeKind,
        evalBeforeValue: evalBeforeVal,
        evalAfterKind: evalAfterKind,
        evalAfterValue: evalAfterVal,
        lossCp: 0,
        quality: 'unknown',
        bestMoveUci: evalBefore.bestMoveUci,
        bestMoveSan: evalBefore.bestMoveSan,
        pvUci: evalAfter.pvUci,
        explanationWhatFailed: '',
        explanationBetterChoice: '',
        explanationWhyItWorks: '',
        explanationConsequence: '',
        outcome: 'INCONCLUSIVE',
        failureReason: 'Missing engine score (neither cp nor mate provided)',
      );
    }

    final isSame = isSameMove(fenBefore, evalBefore.bestMoveUci, playedSan, fenAfter: fenAfter);
    final isMateLoss = evalBeforeKind == 'mate' || evalAfterKind == 'mate';

    int lossCp = 0;
    String qualityStr = 'best';

    if (isSame) {
      qualityStr = 'best';
      lossCp = 0;
    } else if (!isMateLoss) {
      final beforeCp = evalBefore.scoreCp!;
      final afterCp = evalAfter.scoreCp!;
      final rawLoss = isWhite ? (beforeCp - afterCp) : (afterCp - beforeCp);
      lossCp = rawLoss.clamp(0, 10000);

      qualityStr = lossCp < 40
          ? 'excellent'
          : lossCp < 100
              ? 'good'
              : lossCp < 200
                  ? 'inaccuracy'
                  : lossCp < 450
                      ? 'mistake'
                      : 'blunder';
    } else {
      // Mate evaluation classification (preserving exact mate semantics without converting to cp!)
      final playerMateBefore = evalBefore.mateInMoves == null
          ? null
          : (isWhite ? evalBefore.mateInMoves : -evalBefore.mateInMoves!);

      final playerMateAfter = evalAfter.mateInMoves == null
          ? null
          : (isWhite ? evalAfter.mateInMoves : -evalAfter.mateInMoves!);

      if (playerMateBefore != null && playerMateBefore > 0) {
        if (playerMateAfter != null && playerMateAfter > 0) {
          if (playerMateAfter <= playerMateBefore + 1) {
            qualityStr = 'good';
            lossCp = 0;
          } else {
            qualityStr = 'inaccuracy';
            lossCp = 50;
          }
        } else {
          qualityStr = 'blunder';
          lossCp = 900;
        }
      } else if (playerMateBefore == null && playerMateAfter != null && playerMateAfter < 0) {
        qualityStr = 'blunder';
        lossCp = 900;
      } else if (playerMateBefore != null && playerMateBefore < 0) {
        if (playerMateAfter == null || playerMateAfter >= 0) {
          qualityStr = 'excellent';
          lossCp = 0;
        } else if (playerMateAfter.abs() < playerMateBefore.abs()) {
          qualityStr = 'blunder';
          lossCp = 500;
        } else {
          qualityStr = 'inaccuracy';
          lossCp = 100;
        }
      } else if (playerMateAfter != null && playerMateAfter > 0) {
        qualityStr = 'excellent';
        lossCp = 0;
      } else {
        qualityStr = 'blunder';
        lossCp = 500;
      }
    }

    final quality = switch (qualityStr) {
      'best' => EngineMoveQuality.best,
      'excellent' => EngineMoveQuality.excellent,
      'good' => EngineMoveQuality.good,
      'inaccuracy' => EngineMoveQuality.inaccuracy,
      'mistake' => EngineMoveQuality.mistake,
      'blunder' => EngineMoveQuality.blunder,
      _ => EngineMoveQuality.unknown,
    };

    // 4. Category determination from actual board state evidence (NOT index!)
    final category = _determineCategoryFromBoardEvidence(
      chessBoard,
      playedSan,
      evalBefore,
      evalAfter,
    );

    // 5. Test ChessSense Explanation Generation using exact FEN fullmove number
    final moveContext = PersonalGameMove(
      plyIndex: id,
      moveNumber: fullmoveNumber,
      isWhiteMove: isWhite,
      san: playedSan,
      fenBefore: fenBefore,
      fenAfter: fenAfter,
      annotation: '',
    );

    final engineMoveResult = EngineMoveResult(
      plyIndex: id,
      san: playedSan,
      bestMoveUci: evalBefore.bestMoveUci,
      bestMoveSan: evalBefore.bestMoveSan,
      evalBeforeCp: evalBefore.scoreCp,
      evalAfterCp: evalAfter.scoreCp,
      lossCp: lossCp,
      quality: quality,
      opponentBestReplyUci: evalAfter.bestMoveUci,
      opponentPunishmentLineUci: evalAfter.pvUci,
      structuredEvalBefore: evalBefore.mateInMoves != null
          ? StructuredEvaluation.mate(moves: evalBefore.mateInMoves!.abs(), winner: evalBefore.mateInMoves! > 0 ? 'white' : 'black')
          : StructuredEvaluation.centipawns(evalBefore.scoreCp ?? 0),
      structuredEvalAfter: evalAfter.mateInMoves != null
          ? StructuredEvaluation.mate(moves: evalAfter.mateInMoves!.abs(), winner: evalAfter.mateInMoves! > 0 ? 'white' : 'black')
          : StructuredEvaluation.centipawns(evalAfter.scoreCp ?? 0),
    );

    final explanation = buildEngineMoveExplanation(engineMoveResult, moveContext);

    // 6. Pedagogical Fact-Grounding Checks
    if (explanation.whatFailed.isEmpty || explanation.betterChoice.isEmpty) {
      return RealPositionValidationResult(
        id: id,
        fen: fenBefore,
        playedSan: playedSan,
        category: category,
        isWhite: isWhite,
        engineVersion: 'Stockfish 19',
        engineSettings: 'depth ${evalBefore.achievedDepth ?? "UNKNOWN"} movetime 150ms',
        achievedDepth: evalBefore.achievedDepth,
        evalBeforeKind: evalBeforeKind,
        evalBeforeValue: evalBeforeVal,
        evalAfterKind: evalAfterKind,
        evalAfterValue: evalAfterVal,
        lossCp: lossCp,
        quality: qualityStr,
        bestMoveUci: evalBefore.bestMoveUci,
        bestMoveSan: evalBefore.bestMoveSan,
        pvUci: evalAfter.pvUci,
        explanationWhatFailed: explanation.whatFailed,
        explanationBetterChoice: explanation.betterChoice,
        explanationWhyItWorks: explanation.whyItWorks,
        explanationConsequence: explanation.consequence,
        outcome: 'FAILED',
        failureReason: 'Explanation returned empty fields',
      );
    }

    // Verify no unproven claims
    if (explanation.whyItWorks.contains('increased opponent mobility') ||
        explanation.consequence.contains('forces a concession')) {
      return RealPositionValidationResult(
        id: id,
        fen: fenBefore,
        playedSan: playedSan,
        category: category,
        isWhite: isWhite,
        engineVersion: 'Stockfish 19',
        engineSettings: 'depth ${evalBefore.achievedDepth ?? "UNKNOWN"} movetime 150ms',
        achievedDepth: evalBefore.achievedDepth,
        evalBeforeKind: evalBeforeKind,
        evalBeforeValue: evalBeforeVal,
        evalAfterKind: evalAfterKind,
        evalAfterValue: evalAfterVal,
        lossCp: lossCp,
        quality: qualityStr,
        bestMoveUci: evalBefore.bestMoveUci,
        bestMoveSan: evalBefore.bestMoveSan,
        pvUci: evalAfter.pvUci,
        explanationWhatFailed: explanation.whatFailed,
        explanationBetterChoice: explanation.betterChoice,
        explanationWhyItWorks: explanation.whyItWorks,
        explanationConsequence: explanation.consequence,
        outcome: 'FAILED',
        failureReason: 'Explanation contained unproven tactical claims',
      );
    }

    // Verify Pattern Card generation
    final analysis = PersonalGameAnalysis(
      game: ParsedPgnGame(
        headers: {
          'White': isWhite ? 'Player' : 'Opponent',
          'Black': isWhite ? 'Opponent' : 'Player',
          'Date': '2026.10.15',
        },
        sanMoves: [playedSan],
        result: '1-0',
      ),
      moves: [moveContext],
    );

    final engineGameResult = EngineGameResult.fromJson({
      'moves': [
        {
          'plyIndex': id,
          'san': playedSan,
          'bestMoveUci': evalBefore.bestMoveUci,
          'evalBeforeKind': evalBeforeKind,
          'evalBeforeCp': evalBefore.scoreCp,
          'evalBeforeMate': evalBefore.mateInMoves,
          'evalAfterKind': evalAfterKind,
          'evalAfterCp': evalAfter.scoreCp,
          'evalAfterMate': evalAfter.mateInMoves,
          'lossCp': lossCp,
          'quality': qualityStr,
          'opponentBestReplyUci': evalAfter.bestMoveUci,
        }
      ]
    });

    final cards = const PatternCardBuilder().fromGame(
      analysis: analysis,
      result: engineGameResult,
      playerIsWhite: isWhite,
    );

    if (isSame || qualityStr == 'best') {
      if (cards.isNotEmpty) {
        return RealPositionValidationResult(
          id: id,
          fen: fenBefore,
          playedSan: playedSan,
          category: category,
          isWhite: isWhite,
          engineVersion: 'Stockfish 19',
          engineSettings: 'depth ${evalBefore.achievedDepth ?? "UNKNOWN"} movetime 150ms',
          achievedDepth: evalBefore.achievedDepth,
          evalBeforeKind: evalBeforeKind,
          evalBeforeValue: evalBeforeVal,
          evalAfterKind: evalAfterKind,
          evalAfterValue: evalAfterVal,
          lossCp: lossCp,
          quality: qualityStr,
          bestMoveUci: evalBefore.bestMoveUci,
          bestMoveSan: evalBefore.bestMoveSan,
          pvUci: evalAfter.pvUci,
          explanationWhatFailed: explanation.whatFailed,
          explanationBetterChoice: explanation.betterChoice,
          explanationWhyItWorks: explanation.whyItWorks,
          explanationConsequence: explanation.consequence,
          outcome: 'FAILED',
          failureReason: 'Best move generated unexpected Pattern Cards',
        );
      }
    }

    return RealPositionValidationResult(
      id: id,
      fen: fenBefore,
      playedSan: playedSan,
      category: category,
      isWhite: isWhite,
      engineVersion: 'Stockfish 19',
      engineSettings: 'depth ${evalBefore.achievedDepth ?? "UNKNOWN"} movetime 150ms',
      achievedDepth: evalBefore.achievedDepth,
      evalBeforeKind: evalBeforeKind,
      evalBeforeValue: evalBeforeVal,
      evalAfterKind: evalAfterKind,
      evalAfterValue: evalAfterVal,
      lossCp: lossCp,
      quality: qualityStr,
      bestMoveUci: evalBefore.bestMoveUci,
      bestMoveSan: evalBefore.bestMoveSan,
      pvUci: evalAfter.pvUci,
      explanationWhatFailed: explanation.whatFailed,
      explanationBetterChoice: explanation.betterChoice,
      explanationWhyItWorks: explanation.whyItWorks,
      explanationConsequence: explanation.consequence,
      outcome: 'PASSED',
    );
  }

  static String _determineCategoryFromBoardEvidence(
    chess_lib.Chess board,
    String san,
    RealEngineEval evalBefore,
    RealEngineEval evalAfter,
  ) {
    if (evalBefore.mateInMoves != null || evalAfter.mateInMoves != null) {
      return 'Mating Sequences';
    }
    if (san.contains('x')) {
      return 'Captures & Recaptures';
    }
    if (san.startsWith('K') || san.startsWith('k')) {
      return 'King Safety & Checks';
    }
    if (san.contains('+') || san.contains('#')) {
      return 'King Safety & Checks';
    }
    if (board.turn == chess_lib.Color.WHITE && (evalBefore.scoreCp ?? 0) > 100) {
      return 'White Perspective Advantage';
    }
    if (board.turn == chess_lib.Color.BLACK && (evalBefore.scoreCp ?? 0) < -100) {
      return 'Black Perspective Advantage';
    }
    return 'Positional Strategy';
  }
}
