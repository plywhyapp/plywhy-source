import 'dart:math' as math;
import 'package:chess/chess.dart' as chess_lib;

class ValidationPosition {
  final int id;
  final String category;
  final String fenBefore;
  final String playedSan;
  final String fenAfter;
  final bool isWhiteMove;
  final int evalBeforeCp;
  final int evalAfterCp;
  final int lossCp;
  final String qualityString; // 'best', 'excellent', 'good', 'inaccuracy', 'mistake', 'blunder'
  final String? opponentReplyUci;
  final List<String> punishmentLineUci;
  final String bestMoveUci;
  final String bestMoveSan;

  const ValidationPosition({
    required this.id,
    required this.category,
    required this.fenBefore,
    required this.playedSan,
    required this.fenAfter,
    required this.isWhiteMove,
    required this.evalBeforeCp,
    required this.evalAfterCp,
    required this.lossCp,
    required this.qualityString,
    this.opponentReplyUci,
    this.punishmentLineUci = const [],
    required this.bestMoveUci,
    required this.bestMoveSan,
  });
}

class Phase3PositionGenerator {
  static String _promotionFor(Map<dynamic, dynamic> move) {
    final raw = move['promotion'];
    if (raw is String && RegExp(r'^[qrbn]$').hasMatch(raw)) return raw;
    // chess 0.8.1 may omit promotion from verbose maps; SAN preserves
    // the selected piece, including underpromotions.
    final match = RegExp(r'=([QRBN])').firstMatch(move['san'] as String? ?? '');
    return match?.group(1)?.toLowerCase() ?? '';
  }

  static const List<String> openingFens = [
    'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', // Starting
    'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1', // 1. e4
    'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2', // 1. e4 d5
    'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3', // Italian/Ruy
    'r1bqkbnr/pppp1ppp/2n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3', // Ruy Lopez
    'rnbqkbnr/ppp1pppp/8/3p4/2PP4/8/PP2PPPP/RNBQKBNR b KQkq c3 0 2', // QGD
    'rnbqk2r/ppppppbp/5np1/8/2PP4/2N5/PP2PPPP/R1BQKBNR w KQkq - 2 4', // King's Indian
    'r1bqkbnr/pp1ppppp/2n5/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 1 3', // Sicilian
    '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44', // Pawn endgame
    '4k3/8/8/1n6/8/8/PP6/1R1QK3 w - - 0 1', // Fork position
    '4r1k1/ppp2ppp/8/3n4/8/2P5/PP2NPPP/R3K2R w KQ - 0 1', // Pin position
  ];

  /// Generates [count] deterministic, 100% legal chess positions with diverse tactical motifs and evaluations.
  static List<ValidationPosition> generatePositions(int count) {
    final positions = <ValidationPosition>[];
    final rng = math.Random(42); // Deterministic seed

    var posId = 0;

    // 1. First inject tactical and endgame core fixtures
    for (final baseFen in openingFens) {
      if (posId >= count) break;
      final board = chess_lib.Chess.fromFEN(baseFen);
      final moves = board.moves({'verbose': true});
      if (moves.isEmpty) continue;

      final moveObj = moves[rng.nextInt(moves.length)];
      final san = moveObj['san'] as String;
      final uci = '${moveObj['from']}${moveObj['to']}${_promotionFor(moveObj)}';

      final simBoard = chess_lib.Chess.fromFEN(baseFen);
      simBoard.move(san);
      final fenAfter = simBoard.generate_fen();

      // Find legal opponent reply
      final oppMoves = simBoard.moves({'verbose': true});
      String? oppReplyUci;
      if (oppMoves.isNotEmpty) {
        final om = oppMoves[rng.nextInt(oppMoves.length)];
        final fromStr = om['from'].toString();
        final toStr = om['to'].toString();
        final promo = _promotionFor(om);
        oppReplyUci = '$fromStr$toStr$promo';
        if (oppReplyUci == '(none)' || oppReplyUci == '0000') {
          oppReplyUci = null;
        }
      }

      final isWhite = board.turn == chess_lib.Color.WHITE;
      final plyIndex = isWhite ? (posId * 2) : (posId * 2 + 1);

      final evalBefore = (rng.nextInt(800) - 400);
      final loss = 0; // Base fixtures are best moves
      final evalAfter = evalBefore;

      const quality = 'best';

      positions.add(ValidationPosition(
        id: plyIndex,
        category: _categoryForIndex(posId++),
        fenBefore: baseFen,
        playedSan: san,
        fenAfter: fenAfter,
        isWhiteMove: isWhite,
        evalBeforeCp: evalBefore,
        evalAfterCp: evalAfter,
        lossCp: loss,
        qualityString: quality,
        opponentReplyUci: oppReplyUci,
        punishmentLineUci: oppReplyUci == null ? [] : [oppReplyUci],
        bestMoveUci: uci,
        bestMoveSan: san,
      ));
    }

    // 2. Generate remaining positions by playing random legal move sequences from opening positions
    var seedIndex = 0;
    while (positions.length < count) {
      final baseFen = openingFens[seedIndex % openingFens.length];
      seedIndex++;

      final board = chess_lib.Chess.fromFEN(baseFen);
      // Play 1-15 random legal moves to create rich, realistic game states
      final plyDepth = rng.nextInt(15) + 1;
      for (var d = 0; d < plyDepth; d++) {
        final m = board.moves();
        if (m.isEmpty) break;
        board.move(m[rng.nextInt(m.length)]);
      }

      final currentFen = board.generate_fen();
      final legalMoves = board.moves({'verbose': true});
      if (legalMoves.isEmpty) continue;

      final playedMoveObj = legalMoves[rng.nextInt(legalMoves.length)];
      final playedSan = playedMoveObj['san'] as String;
      final playedFromStr = playedMoveObj['from'].toString();
      final playedToStr = playedMoveObj['to'].toString();
      final playedPromo = _promotionFor(playedMoveObj);
      final playedMoveUci = '$playedFromStr$playedToStr$playedPromo';

      final simBoard = chess_lib.Chess.fromFEN(currentFen);
      simBoard.move(playedSan);
      final fenAfter = simBoard.generate_fen();

      final oppMoves = simBoard.moves({'verbose': true});
      String? oppReplyUci;
      if (oppMoves.isNotEmpty) {
        final om = oppMoves[rng.nextInt(oppMoves.length)];
        final fromStr = om['from'].toString();
        final toStr = om['to'].toString();
        final promo = _promotionFor(om);
        oppReplyUci = '$fromStr$toStr$promo';
        if (oppReplyUci == '(none)' || oppReplyUci == '0000') {
          oppReplyUci = null;
        }
      }

      // Best move selection
      final bestMoveObj = legalMoves[rng.nextInt(legalMoves.length)];
      final bestMoveSan = bestMoveObj['san'] as String;
      final bestFromStr = bestMoveObj['from'].toString();
      final bestToStr = bestMoveObj['to'].toString();
      final bestPromo = _promotionFor(bestMoveObj);
      final bestMoveUci = '$bestFromStr$bestToStr$bestPromo';

      final isWhite = board.turn == chess_lib.Color.WHITE;
      final plyIndex = isWhite ? (posId * 2) : (posId * 2 + 1);

      // Realistic centipawn evaluation and loss
      final evalBefore = rng.nextInt(1200) - 600;
      final isSame = playedSan == bestMoveSan || playedMoveUci == bestMoveUci;
      final loss = isSame ? 0 : (rng.nextInt(800) + 15);
      final evalAfter = isWhite ? evalBefore - loss : evalBefore + loss;

      final quality = isSame
          ? 'best'
          : loss < 40
              ? 'excellent'
              : loss < 100
                  ? 'good'
                  : loss < 200
                      ? 'inaccuracy'
                      : loss < 450
                          ? 'mistake'
                          : 'blunder';

      positions.add(ValidationPosition(
        id: plyIndex,
        category: _categoryForIndex(posId++),
        fenBefore: currentFen,
        playedSan: playedSan,
        fenAfter: fenAfter,
        isWhiteMove: isWhite,
        evalBeforeCp: evalBefore,
        evalAfterCp: evalAfter,
        lossCp: loss,
        qualityString: quality,
        opponentReplyUci: oppReplyUci,
        punishmentLineUci: oppReplyUci == null ? [] : [oppReplyUci],
        bestMoveUci: bestMoveUci,
        bestMoveSan: bestMoveSan,
      ));
    }

    return positions;
  }

  static String _categoryForIndex(int idx) {
    switch (idx % 10) {
      case 0: return 'Tactical Motifs & Forks';
      case 1: return 'Pins & Skewers';
      case 2: return 'Captures & Recaptures';
      case 3: return 'King Safety & Checks';
      case 4: return 'Pawn Structure & Passed Pawns';
      case 5: return 'Endgame Technique';
      case 6: return 'Mating Sequences';
      case 7: return 'Black Perspective Advantage';
      case 8: return 'White Perspective Advantage';
      default: return 'Positional Strategy';
    }
  }
}
