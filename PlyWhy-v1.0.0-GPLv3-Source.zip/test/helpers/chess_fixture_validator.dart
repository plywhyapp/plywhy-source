import 'package:chess/chess.dart' as chess_lib;

class FixtureValidationResult {
  final bool isValid;
  final String? error;

  const FixtureValidationResult.valid()
      : isValid = true,
        error = null;
  const FixtureValidationResult.invalid(this.error) : isValid = false;

  @override
  String toString() => isValid ? 'Valid Fixture' : 'Invalid Fixture: $error';
}

class ChessFixtureValidator {
  const ChessFixtureValidator();

  /// Automatically verifies strict FEN syntax, legal move execution, and exact FEN resulting state matching.
  FixtureValidationResult validate({
    required String fenBefore,
    required String sanPlayed,
    required String fenAfter,
    String? opponentReplyUci,
    List<String> pvUci = const [],
  }) {
    // 1. Strict FEN syntax & rank check
    final ranks = fenBefore.split(' ')[0].split('/');
    if (ranks.length != 8) {
      return FixtureValidationResult.invalid(
        'fenBefore must have exactly 8 ranks, but got ${ranks.length}: "$fenBefore"',
      );
    }

    for (var i = 0; i < ranks.length; i++) {
      var squareCount = 0;
      for (final char in ranks[i].runes) {
        final str = String.fromCharCode(char);
        final digit = int.tryParse(str);
        if (digit != null) {
          squareCount += digit;
        } else if ('pnbrqkpPNBRQKP'.contains(str)) {
          squareCount += 1;
        } else {
          return FixtureValidationResult.invalid(
            'Invalid piece character "$str" in rank ${i + 1} of FEN: "$fenBefore"',
          );
        }
      }
      if (squareCount != 8) {
        return FixtureValidationResult.invalid(
          'Rank ${i + 1} of FEN must contain 8 squares, but got $squareCount: "${ranks[i]}" in FEN "$fenBefore"',
        );
      }
    }

    // 2. Validate legal starting position via chess.dart
    final checkFen = chess_lib.Chess.validate_fen(fenBefore);
    if (checkFen['valid'] != true) {
      return FixtureValidationResult.invalid(
        'fenBefore is an illegal chess position: ${checkFen['error'] ?? 'invalid FEN'}',
      );
    }

    chess_lib.Chess boardBefore;
    try {
      boardBefore = chess_lib.Chess.fromFEN(fenBefore);
    } catch (e) {
      return FixtureValidationResult.invalid('Failed to parse fenBefore: $e');
    }

    // 3. Validate played SAN move in fenBefore
    final moveSuccess = boardBefore.move(sanPlayed);
    if (!moveSuccess) {
      return FixtureValidationResult.invalid(
        'SAN move "$sanPlayed" is illegal or invalid in starting FEN "$fenBefore"',
      );
    }

    // 4. Validate that executing SAN move produces fenAfter EXACTLY
    final generatedFenAfter = boardBefore.generate_fen();
    if (generatedFenAfter != fenAfter) {
      return FixtureValidationResult.invalid(
        'Applying SAN move "$sanPlayed" to fenBefore produced FEN "$generatedFenAfter", which does NOT match expected fenAfter "$fenAfter"',
      );
    }

    // 5. Validate opponent's UCI reply if provided
    if (opponentReplyUci != null && opponentReplyUci.isNotEmpty) {
      final boardAfter = chess_lib.Chess.fromFEN(fenAfter);
      if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(opponentReplyUci)) {
        return FixtureValidationResult.invalid(
          'opponentReplyUci "$opponentReplyUci" is malformed: "$opponentReplyUci"',
        );
      }
      final replyMap = <String, String>{
        'from': opponentReplyUci.substring(0, 2),
        'to': opponentReplyUci.substring(2, 4),
      };
      if (opponentReplyUci.length == 5) replyMap['promotion'] = opponentReplyUci[4];
      if (!boardAfter.move(replyMap)) {
        return FixtureValidationResult.invalid(
          'opponentReplyUci "$opponentReplyUci" is illegal in fenAfter "$fenAfter"',
        );
      }
    }

    // 6. Validate PV UCI moves in sequence
    if (pvUci.isNotEmpty) {
      final pvBoard = chess_lib.Chess.fromFEN(fenAfter);
      for (final uci in pvUci) {
        if (!RegExp(r'^[a-h][1-8][a-h][1-8][qrbn]?$').hasMatch(uci)) {
          return FixtureValidationResult.invalid('PV UCI move "$uci" is malformed');
        }
        final pvMap = <String, String>{
          'from': uci.substring(0, 2),
          'to': uci.substring(2, 4),
        };
        if (uci.length == 5) pvMap['promotion'] = uci[4];
        if (!pvBoard.move(pvMap)) {
          return FixtureValidationResult.invalid(
            'PV UCI move "$uci" is illegal in sequence in FEN "${pvBoard.generate_fen()}"',
          );
        }
      }
    }

    return const FixtureValidationResult.valid();
  }
}
