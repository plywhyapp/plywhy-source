import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_explanation.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:chess_sense/widgets/pattern_practice_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('regression: best move recommendation never contradicts played move', () {
    final game = PgnParser().parse('''
[White "richard63"]
[Black "ajb009"]
[Result "0-1"]

1. e4 e5 2. Nf3 Nc6 *
''').single;
    final analysis = const PersonalGameAnalyzer().analyze(game);
    final context = analysis.moves.first;

    const move = EngineMoveResult(
      plyIndex: 0,
      san: 'e4',
      bestMoveUci: 'e2e4',
      bestMoveSan: 'e4',
      evalBeforeCp: 20,
      evalAfterCp: 20,
      lossCp: 0,
      quality: EngineMoveQuality.best,
      opponentBestReplyUci: 'e7e5',
      evalAfterReplyCp: 20,
    );

    final explanation = buildEngineMoveExplanation(move, context);

    expect(explanation.betterChoice, contains('Stockfish confirmed e4 as the best move'));
    expect(explanation.whatFailed, contains('top recommended move'));
    expect(explanation.whatFailed, isNot(contains('abandoned')));
  });

  test('regression: real position 44... Kb5 produces praise when Best and no correction Pattern Card', () {
    const context = PersonalGameMove(
      plyIndex: 87,
      moveNumber: 44,
      isWhiteMove: false,
      san: 'Kb5',
      annotation: null,
      fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
      fenAfter: '8/8/8/pk3p1p/1p1p1PpP/1K1P2P1/8/8 w - - 2 45',
    );

    const bestMove = EngineMoveResult(
      plyIndex: 87,
      san: 'Kb5',
      bestMoveUci: 'c5b5',
      bestMoveSan: 'Kb5',
      evalBeforeCp: 99880,
      evalAfterCp: 99890,
      lossCp: 0,
      quality: EngineMoveQuality.best,
      opponentBestReplyUci: 'b3a2',
      evalAfterReplyCp: 99890,
    );

    final explanation = buildEngineMoveExplanation(bestMove, context);

    expect(explanation.whatFailed, contains('top recommended move'));
    expect(explanation.whatFailed, isNot(contains('abandoned key defensive squares')));
    expect(explanation.betterChoice, contains('Stockfish confirmed Kb5 as the best move'));

    // Verify PatternCardBuilder does NOT create a card for a Best move
    final game = PgnParser().parse('''
[White "richard63"]
[Black "ajb009"]
[Result "0-1"]

1. e4 e5 *
''').single;
    final analysis = const PersonalGameAnalyzer().analyze(game);
    const result = EngineGameResult(moves: [bestMove]);

    final cards = const PatternCardBuilder().fromGame(
      analysis: analysis,
      result: result,
      playerIsWhite: false,
    );

    expect(cards, isEmpty);
  });

  testWidgets('regression UI: PatternPracticeCard widget shows positive praise when revealed for Best move', (tester) async {
    const card = PatternCard(
      id: 'test-card-1',
      sourceGame: 'richard63 vs ajb009',
      moveLabel: '44... Kb5',
      fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
      wrongMove: 'Kb5',
      correctMoveUci: 'c5b5',
      opponentReplyUci: 'b3a2',
      lessonTitle: 'Optimal Play & Control',
      whatFailed: 'By playing 44... Kb5 (Kb5), you chose Stockfish\'s top recommended move in this position.',
      punishment: 'After Kb5, the opponent\'s best response is move the king from b3 to a2.',
      whyItWorks: 'Playing Kb5 maintains your optimal setup, keeping key squares controlled.',
      consequence: 'Stockfish verifies that this move maintains your advantage with zero evaluation loss.',
      betterChoice: 'Stockfish confirmed Kb5 as the best move in this position.',
      lessonText: 'Active, well-calculated moves preserve control.',
      reflectionQuestion: 'Notice how Kb5 preserved control. What key squares did this move secure?',
      flipped: true,
    );

    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: PatternPracticeCard(card: card, revealed: true),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('top recommended move'), findsOneWidget);
    expect(find.textContaining('Stockfish confirmed Kb5 as the best move'), findsOneWidget);
    expect(find.textContaining('abandoned key defensive squares'), findsNothing);
  });

  test('regression: mate-in-2 vs mate-in-20 differentiation', () {
    const mateIn2Score = 99980; // 100000 - 20
    const mateIn20Score = 99800; // 100000 - 200

    expect(mateIn2Score, greaterThan(mateIn20Score));

    const moveDelayingMate = EngineMoveResult(
      plyIndex: 10,
      san: 'Qe2',
      bestMoveUci: 'd1d8',
      bestMoveSan: 'Qd8#',
      evalBeforeCp: mateIn2Score,
      evalAfterCp: -mateIn20Score,
      lossCp: mateIn2Score - mateIn20Score, // 180 cp loss
      quality: EngineMoveQuality.inaccuracy,
      opponentBestReplyUci: 'g8h7',
    );

    expect(moveDelayingMate.lossCp, equals(180));
    expect(moveDelayingMate.quality, equals(EngineMoveQuality.inaccuracy));
  });
}
