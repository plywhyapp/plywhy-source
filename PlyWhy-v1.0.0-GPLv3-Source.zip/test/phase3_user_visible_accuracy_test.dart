@Tags(['stress'])
library;

import 'package:chess/chess.dart' as chess_lib;
import 'package:flutter_test/flutter_test.dart';

import 'helpers/chess_fixture_validator.dart';
import 'helpers/real_stockfish_validator.dart';

class AccuracyTestPosition {
  final int id;
  final String title;
  final String fenBefore;
  final String playedSan;
  final bool isWhiteMove;

  const AccuracyTestPosition({
    required this.id,
    required this.title,
    required this.fenBefore,
    required this.playedSan,
    required this.isWhiteMove,
  });
}

const List<AccuracyTestPosition> accuracy30Positions = [
  // 1. CAPTURES & TRADES
  AccuracyTestPosition(id: 1, title: 'Queen Trade (Qxd1+ / Kxd1)', fenBefore: 'rnbqkbnr/ppp2ppp/8/4P3/2p1P3/8/PP3PPP/RNBQKBNR b KQkq - 0 4', playedSan: 'Qxd1+', isWhiteMove: false),
  AccuracyTestPosition(id: 2, title: 'Center Pawn Trade (exd5 / Qxd5)', fenBefore: 'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2', playedSan: 'exd5', isWhiteMove: true),
  AccuracyTestPosition(id: 3, title: 'Piece Capture in Opening (Nf6)', fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3', playedSan: 'Nf6', isWhiteMove: false),

  // 2. UNCOMPENSATED CAPTURES / HANGING PIECES
  AccuracyTestPosition(id: 4, title: 'Hanging Pawn Loss (Na5 / Nxe5)', fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3', playedSan: 'Na5', isWhiteMove: false),
  AccuracyTestPosition(id: 5, title: 'Blunder Hanging Queen (g4 / Qh4#)', fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/5P2/8/PPPPP1PP/RNBQKBNR w KQkq - 0 2', playedSan: 'g4', isWhiteMove: true),

  // 3. PINS & PINNED PIECES
  AccuracyTestPosition(id: 6, title: 'Pinned Knight Attempted Recapture', fenBefore: '4r1k1/ppp2ppp/8/3n4/8/2P5/PP2NPPP/R3K2R w KQ - 0 1', playedSan: 'a3', isWhiteMove: true),
  AccuracyTestPosition(id: 7, title: 'Absolute Pin Along File', fenBefore: 'r3k2r/ppp2ppp/8/8/8/8/PPP1NPPP/R3K2R w KQkq - 0 1', playedSan: 'a3', isWhiteMove: true),

  // 4. FORKS & DOUBLE ATTACKS
  AccuracyTestPosition(id: 8, title: 'Defensible Knight Fork (1. a3 / 1... Nc3)', fenBefore: '4k3/8/8/1n6/8/8/PP6/1R1QK3 w - - 0 1', playedSan: 'a3', isWhiteMove: true),
  AccuracyTestPosition(id: 9, title: 'Queen Attack Threat (Qh5 / g6)', fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/8/PPPP1PPP/RNBQK1NR w KQkq - 3 3', playedSan: 'Qh5', isWhiteMove: true),

  // 5. KING SAFETY & CHECKS
  AccuracyTestPosition(id: 10, title: 'Forcing Check (Qh4#)', fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2', playedSan: 'Qh4#', isWhiteMove: false),
  AccuracyTestPosition(id: 11, title: 'King Step Away From Central Squares', fenBefore: '8/8/8/3k4/8/8/8/4K3 b - - 0 1', playedSan: 'Kd6', isWhiteMove: false),

  // 6. SACRIFICES & COMBINATIONS
  AccuracyTestPosition(id: 12, title: 'Bishop Sacrifice on h7 (Bxh7+)', fenBefore: 'r1bq1rk1/ppp2ppp/2n5/3pP3/3P4/2PB1N2/P4PPP/R1BQ1RK1 w - - 0 10', playedSan: 'Bxh7+', isWhiteMove: true),

  // 7. GOOD MOVES & TOP RECOMMENDATIONS
  AccuracyTestPosition(id: 13, title: 'Top Recommendation Opening Move (1. e4)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'e4', isWhiteMove: true),
  AccuracyTestPosition(id: 14, title: 'Top Recommendation Opening Move (1. d4)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'd4', isWhiteMove: true),
  AccuracyTestPosition(id: 15, title: 'Authentic Winning Endgame Move (44... Kb5)', fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44', playedSan: 'Kb5', isWhiteMove: false),

  // 8. BAD MOVES & BLUNDERS
  AccuracyTestPosition(id: 16, title: 'Authentic Losing Endgame Blunder (44... Kd5)', fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44', playedSan: 'Kd5', isWhiteMove: false),
  AccuracyTestPosition(id: 17, title: 'Passive Opening Inaccuracy (1. h3)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'h3', isWhiteMove: true),

  // 9. CHECKMATES
  AccuracyTestPosition(id: 18, title: 'Fool\'s Checkmate (Qh4#)', fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2', playedSan: 'Qh4#', isWhiteMove: false),
  AccuracyTestPosition(id: 19, title: 'Scholar\'s Checkmate (Qxf7#)', fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 2 3', playedSan: 'Qxf7#', isWhiteMove: true),

  // 10. MISSED MATES & BLOWN MATES
  AccuracyTestPosition(id: 20, title: 'Blown Mate in 1 (1. a3 instead of Qxf7#)', fenBefore: 'r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 2 3', playedSan: 'a3', isWhiteMove: true),
  AccuracyTestPosition(id: 21, title: 'Blown Mate in 2 (1. h3 instead of Qh4#)', fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2', playedSan: 'h6', isWhiteMove: false),

  // 11. ENDGAME TECHNIQUE
  AccuracyTestPosition(id: 22, title: 'King Opposition Advancement (Ke3)', fenBefore: '8/8/4k3/8/4K3/8/8/8 w - - 0 1', playedSan: 'Ke3', isWhiteMove: true),
  AccuracyTestPosition(id: 23, title: 'Rook Endgame Cutoff (Rb8)', fenBefore: '8/8/8/8/k7/r7/1R6/2K5 w - - 0 1', playedSan: 'Rb8', isWhiteMove: true),

  // 12. WHITE PERSPECTIVE ADVANTAGE
  AccuracyTestPosition(id: 24, title: 'White Big Advantage Move (+3.5 pawns)', fenBefore: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1', playedSan: 'Nf3', isWhiteMove: true),
  AccuracyTestPosition(id: 25, title: 'White Moderate Advantage (1. d4 d5 2. c4)', fenBefore: 'rnbqkbnr/ppp1pppp/8/3p4/8/3P4/PPP1PPPP/RNBQKBNR w KQkq - 0 2', playedSan: 'e4', isWhiteMove: true),

  // 13. BLACK PERSPECTIVE ADVANTAGE
  AccuracyTestPosition(id: 26, title: 'Black Advantage (-3.5 pawns)', fenBefore: 'rnbqkbnr/ppppppp1/7p/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2', playedSan: 'd4', isWhiteMove: true),
  AccuracyTestPosition(id: 27, title: 'Black Counter-Attack Advantage (f6e4)', fenBefore: 'r1bq1rk1/pppp1ppp/5n2/4p3/3QP3/2N2N2/PPP2PPP/R1B1KB1R b KQ - 0 4', playedSan: 'Nxe4', isWhiteMove: false),

  // 14. POSITIONAL STRATEGY
  AccuracyTestPosition(id: 28, title: 'Flank Expansion (1. c4)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'c4', isWhiteMove: true),
  AccuracyTestPosition(id: 29, title: 'Knight Centralization (Nf3)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'Nf3', isWhiteMove: true),
  AccuracyTestPosition(id: 30, title: 'Fianchetto Bishop (g3)', fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', playedSan: 'g3', isWhiteMove: true),
];

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const fixtureValidator = ChessFixtureValidator();

  group('Phase 3 - 30-Position User-Visible Accuracy Verification (Stockfish Depth 12+)', () {
    late RealStockfishService sfService;

    setUpAll(() async {
      sfService = RealStockfishService();
      final started = await sfService.start();
      expect(started, isTrue, reason: 'Stockfish 19 local engine must start cleanly');
    });

    tearDownAll(() {
      sfService.stop();
    });

    for (final pos in accuracy30Positions) {
      test('Position #${pos.id}: ${pos.title}', () async {
        // Find FEN after move via chess.dart
        final simBoard = chess_lib.Chess.fromFEN(pos.fenBefore);
        simBoard.move(pos.playedSan);
        final fenAfter = simBoard.generate_fen();

        // 1. Verify FEN and move legality
        final val = fixtureValidator.validate(
          fenBefore: pos.fenBefore,
          sanPlayed: pos.playedSan,
          fenAfter: fenAfter,
        );
        expect(val.isValid, isTrue, reason: 'Fixture #${pos.id} FEN/Move must be valid: ${val.error}');

        // 2. Perform Genuine Independent Stockfish Reference Search at Depth 12+ (150 ms movetime)
        final evalBefore = await sfService.evaluatePosition(pos.fenBefore, depth: 12, movetimeMs: 150);
        final evalAfter = await sfService.evaluatePosition(fenAfter, depth: 12, movetimeMs: 150);

        // 3. Exercise Production Analysis & Explanation Path
        final validator = const RealPositionValidator();
        final res = validator.validatePosition(
          id: pos.id,
          fenBefore: pos.fenBefore,
          playedSan: pos.playedSan,
          evalBefore: evalBefore,
          evalAfter: evalAfter,
        );

        // 4. Assert Complete Accuracy Outcome
        expect(res.outcome, equals('PASSED'), reason: 'Position #${pos.id} failed verification: ${res.failureReason}');
        expect(res.explanationWhatFailed, isNotEmpty);
        expect(res.explanationBetterChoice, isNotEmpty);

        // Verify no unproven claims
        expect(res.explanationWhyItWorks, isNot(contains('increased opponent mobility')));
        expect(res.explanationConsequence, isNot(contains('forces a concession')));
      });
    }
  });
}
