import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/pgn_parser.dart';

void main() {
  group('PgnParser', () {
    test('parses headers, moves, and result', () {
      const pgn = '''
[Event "Training Game"]
[White "Adolfo"]
[Black "Opponent"]
[Result "1-0"]

1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0
''';

      final games = PgnParser().parse(pgn);

      expect(games, hasLength(1));
      expect(games.single.white, 'Adolfo');
      expect(games.single.black, 'Opponent');
      expect(games.single.result, '1-0');
      expect(games.single.sanMoves, ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6']);
      expect(games.single.fullMoveCount, 3);
    });

    test('removes comments, annotations, and variations from SAN', () {
      const pgn = '''
[Event "Annotated"]

1. e4! {main line} e5 2. Nf3 (2. Bc4 Nf6) Nc6 \$1 3. Bb5?! a6 *
''';

      final game = PgnParser().parse(pgn).single;

      expect(game.sanMoves, ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6']);
      expect(game.result, '*');
    });

    test('preserves symbolic annotations by ply', () {
      const pgn = '1. e4! e5? 2. Nf3?? Nc6?! 3. Bb5!? a6!! *';

      final game = PgnParser().parse(pgn).single;

      expect(game.annotations[0], '!');
      expect(game.annotations[1], '?');
      expect(game.annotations[2], '??');
      expect(game.annotations[3], '?!');
      expect(game.annotations[4], '!?');
      expect(game.annotations[5], '!!');
    });

    test('maps standard NAG annotations to the previous move', () {
      const pgn = '1. e4 \$1 e5 \$2 2. Nf3 \$4 Nc6 \$6 *';

      final game = PgnParser().parse(pgn).single;

      expect(game.annotations[0], '!');
      expect(game.annotations[1], '?');
      expect(game.annotations[2], '??');
      expect(game.annotations[3], '?!');
    });

    test('supports multiple games in one PGN paste', () {
      const pgn = '''
[Event "Game 1"]
[White "A"]
[Black "B"]

1. d4 d5 2. c4 e6 1/2-1/2

[Event "Game 2"]
[White "C"]
[Black "D"]

1. e4 c5 2. Nf3 d6 0-1
''';

      final games = PgnParser().parse(pgn);

      expect(games, hasLength(2));
      expect(games[0].result, '1/2-1/2');
      expect(games[1].result, '0-1');
      expect(games[1].sanMoves, ['e4', 'c5', 'Nf3', 'd6']);
    });

    test('handles move numbers attached directly to SAN', () {
      const pgn = '1.e4 1...c5 2.Nf3 2...d6 *';

      final game = PgnParser().parse(pgn).single;

      expect(game.sanMoves, ['e4', 'c5', 'Nf3', 'd6']);
    });

    test('returns no games for empty input', () {
      expect(PgnParser().parse('   '), isEmpty);
    });
  });
}
