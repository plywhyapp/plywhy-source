import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:chess_sense/widgets/pattern_practice_card.dart';

class _TestHttpOverrides extends HttpOverrides {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = _TestHttpOverrides();

  group('Phase 3 - End-to-End Production Path & UI Verification (Real HTTP Engine)', () {
    Process? serverProcess;

    setUpAll(() async {
      try {
        final client = HttpClient();
        final req = await client.getUrl(Uri.parse('http://127.0.0.1:8787')).timeout(const Duration(seconds: 1));
        final res = await req.close();
        if (res.statusCode > 0) {
          return; // Server is already running on port 8787
        }
      } catch (_) {}

      const dartExe = 'C:\\src\\flutter\\bin\\cache\\dart-sdk\\bin\\dart.exe';
      serverProcess = await Process.start(
        dartExe,
        ['tools/engine_server.dart'],
      );

      final readyCompleter = Completer<void>();
      serverProcess!.stdout.transform(utf8.decoder).transform(const LineSplitter()).listen((line) {
        if (line.contains('Listening on')) {
          if (!readyCompleter.isCompleted) readyCompleter.complete();
        }
      });

      await readyCompleter.future.timeout(const Duration(seconds: 15));
    });

    tearDownAll(() {
      serverProcess?.kill();
    });

    test('1. Production PersonalGameAnalyzer extracts exact FEN fullmove number (1. e4, 7... Nxe4, 44... Kd5)', () {
      // 1. e4
      const gameE4 = ParsedPgnGame(
        headers: {'FEN': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'},
        sanMoves: ['e4'],
        result: '*',
      );
      final analysisE4 = const PersonalGameAnalyzer().analyze(gameE4);
      expect(analysisE4.moves.first.moveLabel, equals('1. e4'));

      // 7... Nxe4
      const gameNxe4 = ParsedPgnGame(
        headers: {'FEN': 'rnbqkb2/pp1ppp2/2p2n1r/6pp/4P1PP/2N5/PPPPBP2/R1BQK1NR b KQq - 1 7'},
        sanMoves: ['Nxe4'],
        result: '*',
      );
      final analysisNxe4 = const PersonalGameAnalyzer().analyze(gameNxe4);
      expect(analysisNxe4.moves.first.moveLabel, equals('7... Nxe4'));

      // 44... Kd5
      const gameKd5 = ParsedPgnGame(
        headers: {'FEN': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44'},
        sanMoves: ['Kd5'],
        result: '0-1',
      );
      final analysisKd5 = const PersonalGameAnalyzer().analyze(gameKd5);
      expect(analysisKd5.moves.first.moveLabel, equals('44... Kd5'));
    });

    test('2. Real HTTP Production Engine Call for Position 16 (44... Kd5)', () async {
      const pgnGame = ParsedPgnGame(
        headers: {'FEN': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44', 'White': 'PlayerA', 'Black': 'PlayerB', 'Date': '2026.10.16'},
        sanMoves: ['Kd5'],
        result: '0-1',
      );

      final analysis = const PersonalGameAnalyzer().analyze(pgnGame);
      final moveContext = analysis.moves.first;
      expect(moveContext.moveLabel, equals('44... Kd5'));

      final api = EngineApiClient.forBaseUrl('http://127.0.0.1:8787');
      final engineResult = await api.analyzeGame(analysis);

      expect(engineResult.moves, hasLength(1));
      final moveRes = engineResult.moves.first;
      expect(moveRes.san, equals('Kd5'));
      expect(moveRes.bestMoveUci, equals('c5b5'));
      expect(moveRes.opponentBestReplyUci, equals('b3a4'));
      expect(moveRes.opponentPunishmentLineUci, isNotEmpty);
    });

    test('3. End-to-End Real HTTP Engine Analysis, PatternCardBuilder, and Store Persistence', () async {
      SharedPreferences.setMockInitialValues({});

      // 1. Analyze game via production analyzer
      const pgnGame = ParsedPgnGame(
        headers: {'FEN': 'rnbqkb2/pp1ppp2/2p2n1r/6pp/4P1PP/2N5/PPPPBP2/R1BQK1NR b KQq - 1 7', 'White': 'PlayerA', 'Black': 'PlayerB', 'Date': '2026.10.16'},
        sanMoves: ['Nxe4'],
        result: '0-1',
      );

      final analysis = const PersonalGameAnalyzer().analyze(pgnGame);
      expect(analysis.moves.first.moveLabel, equals('7... Nxe4'));

      // 2. Real HTTP Production Engine Call
      final api = EngineApiClient.forBaseUrl('http://127.0.0.1:8787');
      final engineResult = await api.analyzeGame(analysis);

      // 3. Generate Pattern Card via production builder
      final cards = const PatternCardBuilder().fromGame(
        analysis: analysis,
        result: engineResult,
        playerIsWhite: false,
      );

      expect(cards, hasLength(1));
      final card = cards.first;
      expect(card.moveLabel, equals('7... Nxe4'));

      // 4. Persist to production PatternCardStore and reload from fresh store instance
      final store = PatternCardStore();
      await store.upsertAll(cards);

      final freshStore = PatternCardStore();
      final loadedCards = await freshStore.loadAll();
      expect(loadedCards, hasLength(1));
      final reloadedCard = loadedCards.first;
      expect(reloadedCard.moveLabel, equals('7... Nxe4'));
    });

    testWidgets('4. Production UI PatternPracticeCard Widget Rendering on Realistic Android Display (800x1600 & 411x823)', (WidgetTester tester) async {
      final card = PatternCard(
        schemaVersion: 2,
        id: 'test_card_1',
        sourceGame: 'PlayerA vs PlayerB · 2026.10.16',
        moveLabel: '7... Nxe4',
        fenBefore: 'rnbqkb2/pp1ppp2/2p2n1r/6pp/4P1PP/2N5/PPPPBP2/R1BQK1NR b KQq - 1 7',
        wrongMove: 'Nxe4',
        correctMoveUci: 'h5g4',
        opponentReplyUci: 'c3e4',
        lessonTitle: 'Piece Exchange Tactics',
        whatFailed: 'By playing 7... Nxe4 (Nxe4), your move allowed a piece exchange starting with the capture of your knight on e4.',
        punishment: 'After Nxe4, the strongest reply is c3e4.',
        whyItWorks: 'Stockfish shows c3e4 captures the knight.',
        consequence: 'The error reduced your evaluation in the opening.',
        betterChoice: 'Instead of Nxe4, Stockfish preferred hxg4.',
        lessonText: 'Calculate tactical piece trades before executing.',
        reflectionQuestion: 'Before committing this move, did you check which pieces were left undefended?',
        flipped: true,
        repetitions: 1,
        intervalDays: 1,
        dueAtMs: DateTime.now().millisecondsSinceEpoch,
      );

      // 1. Test 800x1600 px
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: PatternPracticeCard(
                card: card,
                revealed: true,
              ),
            ),
          ),
        ),
      );

      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text('7... Nxe4'), findsOneWidget);

      // 2. Test 411x823 px (realistic Android phone screen)
      tester.view.physicalSize = const Size(411, 823);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: PatternPracticeCard(
                card: card,
                revealed: true,
              ),
            ),
          ),
        ),
      );

      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text('7... Nxe4'), findsOneWidget);
    });
  });
}
