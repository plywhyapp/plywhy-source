import 'package:flutter_test/flutter_test.dart';

import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/personal_review_training.dart';
import 'package:chess_sense/pgn_parser.dart';

void main() {
  final parser = PgnParser();
  const analyzer = PersonalGameAnalyzer();
  const builder = PersonalReviewBuilder();
  const scheduler = PersonalReviewScheduler();

  PersonalGameAnalysis analysisFrom(String pgn) {
    final game = parser.parse(pgn).single;
    return analyzer.analyze(game);
  }

  test('builder creates one item for each annotated review move', () {
    final analysis = analysisFrom('''
[White "Ada"]
[Black "Grace"]
[Result "*"]

1. e4 e5 2. Nf3?! Nc6 3. Bb5?? *
''');

    final items = builder.build([analysis]);

    expect(items, hasLength(2));
    expect(items.first.severity, PgnMistakeSeverity.blunder);
    expect(items.last.severity, PgnMistakeSeverity.dubious);
  });

  test('builder ID is stable for the same game position', () {
    const pgn = '''
[White "Ada"]
[Black "Grace"]
[Date "2026.10.07"]
[Result "*"]

1. e4 e5 2. Nf3? *
''';
    final first = builder.build([analysisFrom(pgn)]).single.id;
    final second = builder.build([analysisFrom(pgn)]).single.id;

    expect(first, second);
    expect(first, hasLength(16));
  });

  test('hard schedules the position for tomorrow', () {
    final now = DateTime.utc(2026, 10, 7, 12);
    final next = scheduler.next(
      previous: null,
      grade: PersonalReviewGrade.hard,
      now: now,
    );

    expect(next.intervalDays, 1);
    expect(next.repetitions, 0);
    expect(next.dueAt, DateTime.utc(2026, 10, 8, 12));
  });

  test('good expands intervals with successful repetitions', () {
    final now = DateTime.utc(2026, 10, 7);
    final first = scheduler.next(
      previous: null,
      grade: PersonalReviewGrade.good,
      now: now,
    );
    final second = scheduler.next(
      previous: first,
      grade: PersonalReviewGrade.good,
      now: first.dueAt,
    );

    expect(first.intervalDays, 1);
    expect(second.intervalDays, 3);
    expect(second.repetitions, 2);
  });

  test('easy starts with a longer interval than good', () {
    final now = DateTime.utc(2026, 10, 7);
    final good = scheduler.next(
      previous: null,
      grade: PersonalReviewGrade.good,
      now: now,
    );
    final easy = scheduler.next(
      previous: null,
      grade: PersonalReviewGrade.easy,
      now: now,
    );

    expect(good.intervalDays, 1);
    expect(easy.intervalDays, 3);
  });

  test('progress map round-trips without losing scheduling data', () {
    final original = PersonalReviewProgress(
      repetitions: 4,
      intervalDays: 14,
      dueAt: DateTime.utc(2026, 11, 1, 9, 30),
    );
    final restored = PersonalReviewProgress.fromMap(original.toMap());

    expect(restored.repetitions, original.repetitions);
    expect(restored.intervalDays, original.intervalDays);
    expect(restored.dueAt, original.dueAt);
    expect(restored.isDue(DateTime.utc(2026, 11, 1, 9, 30)), isTrue);
  });
}
