import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:chess_sense/models.dart';
import 'package:chess_sense/progress_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('progress store saves and reloads profile, history and recent IDs', () async {
    SharedPreferences.setMockInitialValues({});
    final store = ProgressStore();

    final progress = AppProgress(
      assessmentCompleted: true,
      skillScores: {
        Skill.threatAwareness: 75,
        Skill.opponentResponse: 50,
        Skill.loosePieceDetection: 100,
        Skill.moveSafety: 75,
        Skill.boardChangeAwareness: 50,
      },
      sessionsCompleted: 4,
      streak: 3,
      lastTrainingAccuracy: 80,
      lastTrainingDate: '2026-10-05',
      history: [
        SessionRecord(
          id: 'training-1',
          kind: SessionKind.training,
          timestampIso: '2026-10-05T16:00:00.000',
          correct: 8,
          total: 10,
          ratingBefore: 1500,
          ratingAfter: 1550,
          skillScoresAfter: {
            Skill.threatAwareness: 75,
            Skill.opponentResponse: 55,
            Skill.loosePieceDetection: 100,
            Skill.moveSafety: 75,
            Skill.boardChangeAwareness: 50,
          },
        ),
      ],
      recentExerciseIds: const ['TA05', 'OR05'],
      xp: 640,
      mistakeCounts: {
        Skill.threatAwareness: 1,
        Skill.opponentResponse: 3,
        Skill.loosePieceDetection: 0,
        Skill.moveSafety: 4,
        Skill.boardChangeAwareness: 2,
      },
      highConfidenceAttempts: 5,
      highConfidenceMistakes: 2,
      survivalBest: 7,
      blunderPatternCounts: const {
        'Knight destination blindness': 3,
        'Open-line blindness': 2,
      },
    );

    await store.save(progress);
    final loaded = await store.load();

    expect(loaded.assessmentCompleted, isTrue);
    expect(loaded.sessionsCompleted, 4);
    expect(loaded.streak, 3);
    expect(loaded.lastTrainingAccuracy, 80);
    expect(loaded.skillScores[Skill.loosePieceDetection], 100);
    expect(loaded.history.single.ratingAfter, 1550);
    expect(loaded.recentExerciseIds, ['TA05', 'OR05']);
    expect(loaded.xp, 640);
    expect(loaded.mistakeCounts[Skill.moveSafety], 4);
    expect(loaded.highConfidenceAttempts, 5);
    expect(loaded.highConfidenceMistakes, 2);
    expect(loaded.survivalBest, 7);
    expect(loaded.blunderPatternCounts['Knight destination blindness'], 3);
  });
}
