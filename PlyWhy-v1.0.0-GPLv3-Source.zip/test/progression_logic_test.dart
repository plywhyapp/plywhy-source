import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/models.dart';
import 'package:chess_sense/progression_logic.dart';

void main() {
  test('xp converts to levels predictably', () {
    expect(levelForXp(0), 1);
    expect(levelForXp(249), 1);
    expect(levelForXp(250), 2);
    expect(levelForXp(750), 4);
    expect(xpIntoCurrentLevel(310), 60);
    expect(xpToNextLevel(310), 190);
  });

  test('blunder DNA percentages sum to one when mistakes exist', () {
    final dna = blunderDnaPercentages({
      Skill.threatAwareness: 2,
      Skill.opponentResponse: 3,
      Skill.loosePieceDetection: 1,
      Skill.moveSafety: 4,
      Skill.boardChangeAwareness: 0,
    });

    final total = dna.values.fold<double>(0, (sum, value) => sum + value);
    expect(total, closeTo(1.0, 0.0001));
    expect(topMistakeSkill({Skill.moveSafety: 4, Skill.opponentResponse: 3}), Skill.moveSafety);
  });

  test('overconfidence rate uses only very-sure attempts', () {
    expect(
      overconfidenceMistakeRate(
        highConfidenceAttempts: 5,
        highConfidenceMistakes: 2,
      ),
      40,
    );
    expect(
      overconfidenceMistakeRate(
        highConfidenceAttempts: 0,
        highConfidenceMistakes: 0,
      ),
      0,
    );
  });

  test('weekly helpers ignore assessments', () {
    final now = DateTime.now();
    final history = [
      SessionRecord(
        id: 'a',
        kind: SessionKind.assessment,
        timestampIso: now.toIso8601String(),
        correct: 15,
        total: 20,
        ratingBefore: 1200,
        ratingAfter: 1300,
        skillScoresAfter: {for (final skill in Skill.values) skill: 50},
      ),
      SessionRecord(
        id: 'b',
        kind: SessionKind.blunderShield,
        timestampIso: now.toIso8601String(),
        correct: 4,
        total: 5,
        ratingBefore: 1300,
        ratingAfter: 1320,
        skillScoresAfter: {for (final skill in Skill.values) skill: 55},
      ),
    ];

    final sessions = trainingSessionsSince(
      history,
      now.subtract(const Duration(days: 1)),
    );
    expect(sessions.length, 1);
    expect(sessions.single.kind, SessionKind.blunderShield);
  });
}
