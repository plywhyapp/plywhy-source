import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/engine_config.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:chess_sense/screens/engine_game_analysis_screen.dart';
import 'package:chess_sense/widgets/interactive_chessboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeTransport implements EngineTransport {
  final Map<String, dynamic> response;

  _FakeTransport(this.response);

  @override
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body,
  ) async => response;
}

PersonalGameAnalysis _analysis() {
  final game = PgnParser().parse('''
[White "Ada"]
[Black "Grace"]
[Result "*"]

1. e4 e5 *
''').single;
  return const PersonalGameAnalyzer().analyze(game);
}

EngineApiClient _coachingClient() {
  return EngineApiClient(
    transport: _FakeTransport({
      'moves': [
        {
          'plyIndex': 0,
          'san': 'e4',
          'bestMoveUci': 'd2d4',
          'bestMoveSan': 'd4',
          'evalBeforeCp': 15,
          'evalAfterCp': -150,
          'lossCp': 165,
          'quality': 'mistake',
          'opponentBestReplyUci': 'd7d5',
          'evalAfterReplyCp': -180,
          'opponentPunishmentLineUci': ['d7d5', 'g1f3', 'b8c6'],
          'bestLineUci': ['d2d4', 'd7d5', 'g1f3'],
        },
        {
          'plyIndex': 1,
          'san': 'e5',
          'bestMoveUci': 'c7c5',
          'bestMoveSan': 'c5',
          'evalBeforeCp': 10,
          'evalAfterCp': -200,
          'lossCp': 210,
          'quality': 'mistake',
          'opponentBestReplyUci': 'g1f3',
        },
      ],
    }),
  );
}

void main() {
  testWidgets('summary prioritizes a mate blunder without fictitious cp loss', (tester) async {
    final analysis = const PersonalGameAnalyzer()
        .analyze(PgnParser().parse('1. f3 e5 2. g4 Qh4# 0-1').single);
    final client = EngineApiClient(transport: _FakeTransport({
      'moves': [
        {'plyIndex': 0, 'san': 'f3', 'bestMoveUci': 'e2e4',
          'evalBeforeCp': 30, 'evalAfterCp': -70, 'lossCp': 100, 'quality': 'inaccuracy'},
        {'plyIndex': 2, 'san': 'g4', 'bestMoveUci': 'e2e4',
          'evalBeforeCp': -70, 'evalAfterCp': null, 'lossCp': 0, 'quality': 'blunder'},
      ],
    }));
    await tester.pumpWidget(MaterialApp(home: EngineGameAnalysisScreen(
      analysis: analysis, client: client,
    )));
    await tester.pumpAndSettle();
    expect(find.text('Most important moment: g4'), findsOneWidget);
  });

  testWidgets('engine screen renders configured service with local engine URL', (tester) async {
    expect(EngineConfig.isConfigured, isTrue);
    expect(EngineConfig.baseUrl, 'http://10.0.2.2:8787');
  });

  testWidgets('engine screen renders human-readable coaching with synchronized board', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: EngineGameAnalysisScreen(
          analysis: _analysis(),
          client: _coachingClient(),
          playerUsername: 'Ada',
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Your review summary'), findsOneWidget);
    expect(find.textContaining('1 mistakes'), findsOneWidget);
    expect(find.text('Review moment 1 of 1'), findsOneWidget);
    expect(find.byKey(const ValueKey('pedagogical-review-board')), findsOneWidget);
    expect(find.text('1. e4 · Mistake'), findsOneWidget);
    expect(find.text('1. Concrete mistake'), findsOneWidget);
    expect(find.text('3. Strongest reply'), findsOneWidget);
    expect(find.text('2. Position change & opponent gain'), findsOneWidget);
    expect(find.text('4. Verifiable consequence'), findsOneWidget);
    expect(find.text('5. Better choice comparison'), findsOneWidget);
    expect(find.textContaining('6. Chess principle'), findsOneWidget);
    expect(find.textContaining('7. Reflection question'), findsOneWidget);
    expect(find.textContaining('move the pawn from d2 to d4'), findsOneWidget);
    expect(find.textContaining('move the pawn from d7 to d5'), findsWidgets);
    expect(find.textContaining('Concrete line:'), findsOneWidget);
    expect(find.textContaining('opponent is about 1.8'), findsOneWidget);

    // Grace's mistake is intentionally hidden when reviewing Ada's game.
    expect(find.text('1... e5 · Mistake'), findsNothing);
  });

  testWidgets('board view follows better move and opponent reply', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: EngineGameAnalysisScreen(
          analysis: _analysis(),
          client: _coachingClient(),
          playerUsername: 'Ada',
        ),
      ),
    );
    await tester.pumpAndSettle();

    final betterMoveChip = find.widgetWithText(ChoiceChip, 'Better move');
    await tester.ensureVisible(betterMoveChip);
    await tester.pumpAndSettle();
    await tester.tap(betterMoveChip);
    await tester.pumpAndSettle();

    var board = tester.widget<InteractiveChessBoard>(
      find.byKey(const ValueKey('pedagogical-review-board')),
    );
    expect(board.board['d4'], '♙');
    expect(board.board['d2'], isNull);
    expect(board.selectedFrom, 'd2');
    expect(board.selectedTo, 'd4');
    expect(find.textContaining('Stronger choice:'), findsOneWidget);

    final opponentReplyChip = find.widgetWithText(ChoiceChip, 'Opponent reply');
    await tester.ensureVisible(opponentReplyChip);
    await tester.pumpAndSettle();
    await tester.tap(opponentReplyChip);
    await tester.pumpAndSettle();

    board = tester.widget<InteractiveChessBoard>(
      find.byKey(const ValueKey('pedagogical-review-board')),
    );
    expect(board.board['d5'], '♟');
    expect(board.board['d7'], isNull);
    expect(board.selectedFrom, 'd7');
    expect(board.selectedTo, 'd5');
    expect(find.textContaining('Opponent reply to anticipate:'), findsOneWidget);
  });
}
