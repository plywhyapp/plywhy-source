import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/fen_utils.dart';
import 'package:chess_sense/mode_content.dart';
import 'package:chess_sense/models.dart';

void main() {
  test('BlunderShield has ten unique rules-valid scenarios', () {
    expect(blunderShieldScenarios.length, 10);
    expect(
      blunderShieldScenarios.map((e) => e.id).toSet().length,
      blunderShieldScenarios.length,
    );

    for (final scenario in blunderShieldScenarios) {
      expect(isFenStructurallyValid(scenario.fen), isTrue, reason: scenario.id);
      expect(scenario.candidates.length, 4, reason: scenario.id);
      expect(
        scenario.candidates.map((e) => e.uci),
        contains(scenario.correctMoveUci),
        reason: scenario.id,
      );
      expect(scenario.skill, Skill.moveSafety, reason: scenario.id);
    }
  });

  test('Opponent Vision contains ten engine-validated scenarios', () {
    expect(opponentVisionScenarios.length, 10);
    expect(
      opponentVisionScenarios.map((e) => e.id).toSet().length,
      opponentVisionScenarios.length,
    );

    for (final scenario in opponentVisionScenarios) {
      expect(isFenStructurallyValid(scenario.fen), isTrue, reason: scenario.id);
      expect(
        scenario.validationStatus,
        ValidationStatus.engineValidated,
        reason: scenario.id,
      );
      expect(scenario.correctMoveUci, matches(RegExp(r'^[a-h][1-8][a-h][1-8]$')));
      expect(
        () => boardAfterUciMoves(scenario.fen, scenario.setupMovesUci),
        returnsNormally,
        reason: scenario.id,
      );
    }
  });

  test('survival bank is balanced between safe and blunder prompts', () {
    expect(blunderSurvivalScenarios.length, 12);
    expect(blunderSurvivalScenarios.where((e) => e.isSafe).length, 6);
    expect(blunderSurvivalScenarios.where((e) => !e.isSafe).length, 6);
    for (final scenario in blunderSurvivalScenarios) {
      expect(isFenStructurallyValid(scenario.fen), isTrue, reason: scenario.id);
    }
  });

  test('Opponent Vision mirrors the ten Stockfish-audited best replies', () {
    final expected = <String, String>{
      'OV01': 'f6h5',
      'OV02': 'f4d5',
      'OV03': 'g8f7',
      'OV04': 'f6h7',
      'OV05': 'g8h7',
      'OV06': 'c8g4',
      'OV07': 'd8d5',
      'OV08': 'a8a7',
      'OV09': 'f8f7',
      'OV10': 'c8g4',
    };

    for (final scenario in opponentVisionScenarios) {
      expect(scenario.correctMoveUci, expected[scenario.id], reason: scenario.id);
    }
  });

}
