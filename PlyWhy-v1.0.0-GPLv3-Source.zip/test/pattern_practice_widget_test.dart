import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/widgets/interactive_chessboard.dart';
import 'package:chess_sense/widgets/pattern_practice_card.dart';

// The source ZIP omits piece assets. Supply a test-only SVG bundle; production
// assets and their appearance are deliberately outside this logic test.
class TestPieceBundle extends CachingAssetBundle {
  @override
  Future<ByteData> load(String key) async {
    if (key.endsWith('.svg')) {
      return ByteData.sublistView(
        Uint8List.fromList(
          utf8.encode(
            '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40">'
            '<circle cx="20" cy="20" r="15" fill="black"/></svg>',
          ),
        ),
      );
    }
    if (key == 'AssetManifest.bin') {
      return const StandardMessageCodec().encodeMessage(<String, Object?>{})!;
    }
    throw FlutterError('Unexpected test asset: $key');
  }
}

const card = PatternCard(
  id: 'test',
  sourceGame: 'Test game',
  moveLabel: '1. d4',
  fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  wrongMove: 'd4',
  correctMoveUci: 'e2e4',
  opponentReplyUci: 'd7d5',
  lessonTitle: 'Look for a reply',
  whatFailed: 'Original game explanation',
  punishment: 'Original reply',
  whyItWorks: 'Original reason',
  consequence: 'Original consequence',
  betterChoice: 'Play e4',
  lessonText: 'Check your opponent’s plan',
  flipped: false,
);

Widget host({bool revealed = false, String key = 'card'}) => MaterialApp(
  home: DefaultAssetBundle(
    bundle: TestPieceBundle(),
    child: Scaffold(
      body: SingleChildScrollView(
        child: PatternPracticeCard(
          key: ValueKey(key),
          card: card,
          revealed: revealed,
        ),
      ),
    ),
  ),
);

Future<void> move(WidgetTester tester, String from, String to) async {
  var board = tester.widget<InteractiveChessBoard>(
    find.byType(InteractiveChessBoard),
  );
  board.onSquareTap!(from);
  await tester.pump();
  board = tester.widget<InteractiveChessBoard>(
    find.byType(InteractiveChessBoard),
  );
  expect(board.destinationSquares, contains(to));
  board.onSquareTap!(to);
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('play, reveal and retry retain correct board state', (
    tester,
  ) async {
    await tester.pumpWidget(host());
    await tester.pumpAndSettle();
    expect(find.text('Original game explanation'), findsNothing);
    await move(tester, 'e2', 'e4');
    var board = tester.widget<InteractiveChessBoard>(
      find.byType(InteractiveChessBoard),
    );
    expect(board.board['e4'], '♙');
    expect(board.board['e2'], isNull);
    expect(
      find.textContaining('You found the saved engine recommendation'),
      findsOneWidget,
    );
    // A reply from d4 must not leak into the e4 attempt, even if legal there.
    expect(find.byKey(const ValueKey('pattern-show-reply')), findsNothing);
    await tester.pumpWidget(host(revealed: true));
    await tester.pumpAndSettle();
    expect(find.text('Original game explanation'), findsOneWidget);
    board = tester.widget<InteractiveChessBoard>(
      find.byType(InteractiveChessBoard),
    );
    expect(board.board['e4'], '♙');
    final retry = find.byKey(const ValueKey('pattern-try-again'));
    await tester.ensureVisible(retry);
    await tester.tap(retry);
    await tester.pumpAndSettle();
    board = tester.widget<InteractiveChessBoard>(
      find.byType(InteractiveChessBoard),
    );
    expect(board.board['e2'], '♙');
    expect(board.onSquareTap, isNotNull);
    expect(tester.takeException(), isNull);
  });

  testWidgets('original mistake permits saved reply and next card resets', (
    tester,
  ) async {
    await tester.pumpWidget(host());
    await tester.pumpAndSettle();
    await move(tester, 'd2', 'd4');
    final reply = find.byKey(const ValueKey('pattern-show-reply'));
    expect(reply, findsOneWidget);
    await tester.ensureVisible(reply);
    await tester.tap(reply);
    await tester.pumpAndSettle();
    var board = tester.widget<InteractiveChessBoard>(
      find.byType(InteractiveChessBoard),
    );
    expect(board.board['d5'], '♟');
    expect(board.board['d4'], '♙');
    await tester.pumpWidget(host(key: 'next-card'));
    await tester.pumpAndSettle();
    board = tester.widget<InteractiveChessBoard>(
      find.byType(InteractiveChessBoard),
    );
    expect(board.board['d2'], '♙');
    expect(board.board['d7'], '♟');
    expect(board.onSquareTap, isNotNull);
    expect(tester.takeException(), isNull);
  });
}
