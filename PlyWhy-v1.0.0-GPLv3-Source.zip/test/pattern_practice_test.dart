import 'package:flutter_test/flutter_test.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_practice.dart';

const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

PatternPractice position(
  String fen, {
  String best = 'e2e4',
  String wrong = 'd4',
}) => PatternPractice(fenBefore: fen, savedMoveUci: best, originalSan: wrong);

class FakeTransport implements EngineTransport {
  Map<String, dynamic>? request;
  String? path;
  final Map<String, dynamic> response;
  FakeTransport(this.response);
  @override
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body,
  ) async {
    this.path = path;
    request = body;
    return response;
  }
}

void main() {
  test(
    'only legal destinations, and saved match differs from an alternative',
    () {
      final practice = position(startFen);
      expect(practice.destinations('e2'), {'e3', 'e4'});
      expect(practice.destinations('e7'), isEmpty);
      expect(() => practice.play('e2e5'), throwsFormatException);
      expect(practice.play('e2e4').matchesSavedMove, isTrue);
      final other = practice.play('g1f3');
      expect(other.matchesSavedMove, isFalse);
      expect(other.repeatsOriginalMove, isFalse);
      expect(practice.play('d2d4').repeatsOriginalMove, isTrue);
    },
  );

  test('pinned piece cannot expose its king', () {
    final practice = position('k3r3/8/8/8/8/8/4R3/4K3 w - - 0 1');
    expect(practice.destinations('e2'), isNot(contains('d2')));
    expect(() => practice.play('e2d2'), throwsFormatException);
  });

  test('castling moves both king and rook', () {
    final result = position('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')
        .play('e1g1');
    expect(result.fenAfter.split(' ').first, endsWith('R4RK1'));
    expect(result.san, 'O-O');
  });

  test('en passant removes captured pawn', () {
    final result = position('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1').play('e5d6');
    expect(result.fenAfter.split(' ').first, '4k3/8/3P4/8/8/8/8/4K3');
  });

  test('all four promotions are explicit and legal', () {
    final practice = position('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');
    for (final piece in ['q', 'r', 'b', 'n']) {
      expect(
        practice.play('a7a8$piece').fenAfter,
        startsWith(piece.toUpperCase()),
      );
    }
    expect(() => practice.play('a7a8'), throwsFormatException);
  });

  test('mate and stalemate are distinguished without an engine', () {
    final practice = position('7k/8/5KQ1/8/8/8/8/8 w - - 0 1');
    expect(practice.play('g6g7').facts.single, contains('checkmate'));
    expect(practice.play('g6f7').facts.single, contains('stalemate'));
  });

  test('replies start from the actual attempt and reject illegal moves', () {
    final attempt = position(startFen).play('e2e4');
    expect(PatternPractice.afterReply(attempt, 'e7e5'), isNotNull);
    expect(PatternPractice.afterReply(attempt, 'e2e4'), isNull);
    expect(PatternPractice.afterReply(attempt, 'nonsense'), isNull);
  });

  test(
    'black to move request preserves actual side, FEN and move number',
    () async {
      const fen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 22';
      final practice = position(fen, best: 'e7e5');
      final transport = FakeTransport({
        'moves': [
          {
            'plyIndex': 1,
            'san': 'e5',
            'bestMoveUci': 'e7e5',
            'quality': 'best',
          },
        ],
      });
      final result = await practice.analyze(
        practice.play('e7e5'),
        EngineApiClient(transport: transport),
      );
      expect(result.quality, EngineMoveQuality.best);
      expect(transport.path, '/v1/analyze-game');
      final move = (transport.request!['moves'] as List).single as Map;
      expect(move['isWhiteMove'], isFalse);
      expect(move['fenBefore'], fen);
      expect(move['moveNumber'], 22);
    },
  );

  test('stale or mismatched engine response is rejected', () async {
    final practice = position(startFen);
    final transport = FakeTransport({
      'moves': [
        {'plyIndex': 0, 'san': 'd4', 'bestMoveUci': 'e2e4', 'quality': 'best'},
      ],
    });
    await expectLater(
      practice.analyze(
        practice.play('e2e4'),
        EngineApiClient(transport: transport),
      ),
      throwsA(isA<EngineApiException>()),
    );
  });

  test('invalid engine recommendation is rejected', () async {
    final practice = position(startFen);
    final transport = FakeTransport({
      'moves': [
        {'plyIndex': 0, 'san': 'e4', 'bestMoveUci': 'e2e5', 'quality': 'best'},
      ],
    });
    await expectLater(
      practice.analyze(
        practice.play('e2e4'),
        EngineApiClient(transport: transport),
      ),
      throwsA(isA<EngineApiException>()),
    );
  });

  test('invalid saved board is rejected before play', () {
    expect(() => position('invalid'), throwsFormatException);
  });
}
