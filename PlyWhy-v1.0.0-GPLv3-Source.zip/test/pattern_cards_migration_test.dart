import 'dart:convert';

import 'package:chess_sense/pattern_cards.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('PatternCardStore Migration & Integrity Tests', () {
    test('migrates v1 JSON to v2 and soft-archives reclassified best moves via ChessMoveValidator', () async {
      final prefs = await SharedPreferences.getInstance();

      final legacyV1Json = jsonEncode([
        {
          'id': 'legacy-card-blunder-1',
          'sourceGame': 'Ada vs Grace',
          'moveLabel': '1. e4',
          'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          'wrongMove': 'e4',
          'correctMoveUci': 'd2d4',
          'opponentReplyUci': 'd7d5',
          'lessonTitle': 'Central Control',
          'whatFailed': 'Missed d4',
          'punishment': 'd5',
          'whyItWorks': 'Controls center',
          'consequence': 'Equal',
          'betterChoice': 'd4',
          'lessonText': 'Control center',
          'flipped': false,
          'repetitions': 3,
          'intervalDays': 6,
          'dueAtMs': 1700000000000,
        },
        {
          'id': 'legacy-card-obsolete-kb5',
          'sourceGame': 'richard63 vs ajb009',
          'moveLabel': '44... Kb5',
          'fenBefore': '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
          'wrongMove': 'Kb5',
          'correctMoveUci': 'c5b5', // Same move physically!
          'opponentReplyUci': 'b3a2',
          'lessonTitle': 'King Activity',
          'whatFailed': 'Retreated king',
          'punishment': 'Ka2',
          'whyItWorks': 'King moved away',
          'consequence': 'Equal',
          'betterChoice': 'c5b5',
          'lessonText': 'Keep king active',
          'flipped': true,
          'repetitions': 5,
          'intervalDays': 12,
          'dueAtMs': 1750000000000,
        },
      ]);

      await prefs.setString(PatternCardStore.key, legacyV1Json);

      final store = PatternCardStore();

      // Active training queue must only contain valid blunder cards (excludes soft-archived)
      final activeCards = await store.loadActive();
      expect(activeCards, hasLength(1));
      expect(activeCards.first.id, equals('legacy-card-blunder-1'));

      // Storage must retain ALL cards including soft-archived Kb5 card
      final allCards = await store.loadAll(includeArchived: true);
      expect(allCards, hasLength(2));

      final obsoleteKb5Card = allCards.firstWhere((c) => c.id == 'legacy-card-obsolete-kb5');
      expect(obsoleteKb5Card.schemaVersion, equals(2));
      expect(obsoleteKb5Card.isArchived, isTrue);
      expect(obsoleteKb5Card.archiveReason, equals('reclassified_as_best_v2'));

      // CRITICAL: Spaced repetition history must be 100% PRESERVED
      expect(obsoleteKb5Card.repetitions, equals(5));
      expect(obsoleteKb5Card.intervalDays, equals(12));
      expect(obsoleteKb5Card.dueAtMs, equals(1750000000000));
    });

    test('demonstration of data recovery: unarchiving a soft-archived card restores it to active training', () async {
      final store = PatternCardStore();

      const cardToArchive = PatternCard(
        schemaVersion: 2,
        id: 'archived-card-recovery-test',
        sourceGame: 'Test Game',
        moveLabel: '10. Nf3',
        fenBefore: 'r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4',
        wrongMove: 'h3',
        correctMoveUci: 'd2d4',
        opponentReplyUci: 'e5d4',
        lessonTitle: 'Development',
        whatFailed: 'Passive pawn move',
        punishment: 'd4',
        whyItWorks: 'Gives away tempo',
        consequence: 'Loss of initiative',
        betterChoice: 'd4',
        lessonText: 'Develop pieces',
        flipped: false,
        repetitions: 8,
        intervalDays: 24,
        dueAtMs: 1800000000000,
        isArchived: true,
        archiveReason: 'test_soft_archive',
      );

      await store.upsertAll([cardToArchive]);

      // Verify it is excluded from active queue
      var active = await store.loadActive();
      expect(active.where((c) => c.id == 'archived-card-recovery-test'), isEmpty);

      // Perform recovery procedure: restoreArchivedCard
      await store.restoreArchivedCard('archived-card-recovery-test');

      // Verify card is now active and retains its exact study history (8 reps, 24 days)
      active = await store.loadActive();
      expect(active.where((c) => c.id == 'archived-card-recovery-test'), hasLength(1));

      final restored = active.firstWhere((c) => c.id == 'archived-card-recovery-test');
      expect(restored.isArchived, isFalse);
      expect(restored.archiveReason, isNull);
      expect(restored.repetitions, equals(8));
      expect(restored.intervalDays, equals(24));
      expect(restored.dueAtMs, equals(1800000000000));
    });

    test('atomic write creates backup key and temporary key before updating main storage', () async {
      final store = PatternCardStore();
      final prefs = await SharedPreferences.getInstance();

      const card = PatternCard(
        id: 'atomic-test-card-1',
        sourceGame: 'Test Game',
        moveLabel: '1. d4',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        wrongMove: 'h3',
        correctMoveUci: 'd2d4',
        opponentReplyUci: 'd7d5',
        lessonTitle: 'Center',
        whatFailed: 'Flank move',
        punishment: 'd5',
        whyItWorks: 'Center pawn',
        consequence: 'Less center control',
        betterChoice: 'd4',
        lessonText: 'Control center',
        flipped: false,
      );

      // First save creates main key
      await store.upsertAll([card]);

      // Second save creates timestamped backup of previous main key
      await store.upsertAll([card]);

      // Check main key contains valid v2 JSON
      final mainPayload = prefs.getString(PatternCardStore.key);
      expect(mainPayload, isNotNull);
      expect(mainPayload, contains('atomic-test-card-1'));
      expect(mainPayload, contains('"schemaVersion":2'));

      // Check backup key was created on overwrite
      final backupKeys = prefs.getKeys().where((k) => k.contains(PatternCardStore.backupKeyPrefix));
      expect(backupKeys, isNotEmpty);
    });

    test('migrates active v1 cards to schemaVersion = 2 and prevents duplicate migrations/backups on second load', () async {
      final prefs = await SharedPreferences.getInstance();

      final legacyV1Json = jsonEncode([
        {
          'id': 'legacy-active-card-1',
          'sourceGame': 'Ada vs Grace',
          'moveLabel': '1. e4',
          'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          'wrongMove': 'e4',
          'correctMoveUci': 'd2d4',
          'opponentReplyUci': 'd7d5',
          'lessonTitle': 'Center',
          'whatFailed': 'Pawn e4',
          'punishment': 'd5',
          'whyItWorks': 'Center control',
          'consequence': 'Equal',
          'betterChoice': 'd4',
          'lessonText': 'Control center',
          'flipped': false,
          'repetitions': 2,
          'intervalDays': 3,
          'dueAtMs': 1700000000000,
        },
      ]);

      await prefs.setString(PatternCardStore.key, legacyV1Json);
      final store = PatternCardStore();

      // First load migrates v1 -> v2
      final cardsFirstLoad = await store.loadAll(includeArchived: true);
      expect(cardsFirstLoad, hasLength(1));
      expect(cardsFirstLoad.first.schemaVersion, equals(2));
      expect(cardsFirstLoad.first.repetitions, equals(2));

      final backupCountAfterFirstLoad = prefs.getKeys().where((k) => k.startsWith(PatternCardStore.backupKeyPrefix)).length;
      expect(backupCountAfterFirstLoad, equals(1));

      // Second load must NOT trigger migration nor create additional backup keys
      final cardsSecondLoad = await store.loadAll(includeArchived: true);
      expect(cardsSecondLoad, hasLength(1));
      expect(cardsSecondLoad.first.schemaVersion, equals(2));

      final backupCountAfterSecondLoad = prefs.getKeys().where((k) => k.startsWith(PatternCardStore.backupKeyPrefix)).length;
      expect(backupCountAfterSecondLoad, equals(backupCountAfterFirstLoad)); // Zero new backups generated!
    });

    test('recovers safely from valid backup key when main storage JSON is corrupted or empty', () async {
      final prefs = await SharedPreferences.getInstance();

      final validBackupJson = jsonEncode([
        {
          'schemaVersion': 2,
          'id': 'backup-card-recovered-1',
          'sourceGame': 'Backup Game',
          'moveLabel': '5. Nf3',
          'fenBefore': 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          'wrongMove': 'h3',
          'correctMoveUci': 'g1f3',
          'opponentReplyUci': 'd7d5',
          'lessonTitle': 'Development',
          'whatFailed': 'Flank pawn',
          'punishment': 'd5',
          'whyItWorks': 'Piece development',
          'consequence': 'Equal',
          'betterChoice': 'Nf3',
          'lessonText': 'Develop pieces',
          'flipped': false,
          'repetitions': 7,
          'intervalDays': 14,
          'dueAtMs': 1780000000000,
          'isArchived': false,
        },
      ]);

      // Case A: Main key is corrupted!
      await prefs.setString(PatternCardStore.key, '{corrupted_invalid_json_string');
      await prefs.setString('${PatternCardStore.backupKeyPrefix}1700000000000', validBackupJson);

      final store = PatternCardStore();

      final recoveredFromCorrupted = await store.loadAll(includeArchived: true);
      expect(recoveredFromCorrupted, hasLength(1));
      expect(recoveredFromCorrupted.first.id, equals('backup-card-recovered-1'));
      expect(recoveredFromCorrupted.first.repetitions, equals(7));

      // Case B: Main key is empty, but valid backup key exists!
      await prefs.setString(PatternCardStore.key, '');
      final recoveredFromEmpty = await store.loadAll(includeArchived: true);
      expect(recoveredFromEmpty, hasLength(1));
      expect(recoveredFromEmpty.first.id, equals('backup-card-recovered-1'));
    });

    test('returns empty list when main key is empty AND no backup keys exist', () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(PatternCardStore.key);

      final store = PatternCardStore();
      final cards = await store.loadAll(includeArchived: true);
      expect(cards, isEmpty);
    });

    test('throws StateError on corrupted storage when no valid backup key is available', () async {
      final prefs = await SharedPreferences.getInstance();

      // Main key is corrupted and no backup exists
      await prefs.setString(PatternCardStore.key, '{corrupted_invalid_json_string');

      final store = PatternCardStore();

      // Must throw StateError rather than returning [] (which would wipe data on write)
      expect(
        () async => await store.loadAll(includeArchived: true),
        throwsA(isA<StateError>()),
      );
    });

    test('restoreArchivedCard refuses to re-activate cards that teach a Stockfish top recommended move as an error', () async {
      await SharedPreferences.getInstance();

      const obsoleteBestMoveCard = PatternCard(
        schemaVersion: 2,
        id: 'obsolete-best-move-card',
        sourceGame: 'richard63 vs ajb009',
        moveLabel: '44... Kb5',
        fenBefore: '8/8/8/p1k2p1p/1p1p1PpP/1K1P2P1/8/8 b - - 1 44',
        wrongMove: 'Kb5',
        correctMoveUci: 'c5b5', // Exact match via ChessMoveValidator!
        opponentReplyUci: 'b3a2',
        lessonTitle: 'King Activity',
        whatFailed: 'Kb5',
        punishment: 'Ka2',
        whyItWorks: 'Active king',
        consequence: 'Zero loss',
        betterChoice: 'c5b5',
        lessonText: 'King activity',
        flipped: true,
        isArchived: true,
        archiveReason: 'reclassified_as_best_v2',
      );

      final store = PatternCardStore();
      await store.upsertAll([obsoleteBestMoveCard]);

      // restoreArchivedCard must refuse to re-activate Kb5
      expect(
        () async => await store.restoreArchivedCard('obsolete-best-move-card'),
        throwsA(isA<StateError>()),
      );
    });

    test('upsertAll preserves isArchived, archiveReason, and archivedAtIso of existing cards', () async {
      final store = PatternCardStore();

      const existingArchivedCard = PatternCard(
        schemaVersion: 2,
        id: 'archived-card-upsert-test',
        sourceGame: 'Test Game',
        moveLabel: '12. Be3',
        fenBefore: 'r1bqk2r/pppp1ppp/2n2n2/4p3/2B1P3/2P2N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
        wrongMove: 'h3',
        correctMoveUci: 'c1e3',
        opponentReplyUci: 'f6e4',
        lessonTitle: 'Development',
        whatFailed: 'Passive pawn move',
        punishment: 'Nxe4',
        whyItWorks: 'Piece play',
        consequence: 'Equal',
        betterChoice: 'Be3',
        lessonText: 'Develop bishop',
        flipped: false,
        isArchived: true,
        archiveReason: 'reclassified_as_best_v2',
        archivedAtIso: '2026-10-14T10:00:00.000Z',
      );

      await store.upsertAll([existingArchivedCard]);

      // Re-analysis tries to upsert the same card ID without archive flags
      const incomingCardFromReanalysis = PatternCard(
        schemaVersion: 2,
        id: 'archived-card-upsert-test',
        sourceGame: 'Test Game Updated',
        moveLabel: '12. Be3',
        fenBefore: 'r1bqk2r/pppp1ppp/2n2n2/4p3/2B1P3/2P2N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
        wrongMove: 'h3',
        correctMoveUci: 'c1e3',
        opponentReplyUci: 'f6e4',
        lessonTitle: 'Development Updated',
        whatFailed: 'Updated explanation',
        punishment: 'Nxe4',
        whyItWorks: 'Piece play',
        consequence: 'Equal',
        betterChoice: 'Be3',
        lessonText: 'Develop bishop',
        flipped: false,
        isArchived: false, // Re-analysis payload does NOT have archive flag set
      );

      await store.upsertAll([incomingCardFromReanalysis]);

      // Check that the stored card retains isArchived = true and archiveReason!
      final all = await store.loadAll(includeArchived: true);
      final stored = all.firstWhere((c) => c.id == 'archived-card-upsert-test');

      expect(stored.isArchived, isTrue);
      expect(stored.archiveReason, equals('reclassified_as_best_v2'));
      expect(stored.archivedAtIso, equals('2026-10-14T10:00:00.000Z'));
    });
  });
}
