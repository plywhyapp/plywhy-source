package com.adolfoapps.chess_sense

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
