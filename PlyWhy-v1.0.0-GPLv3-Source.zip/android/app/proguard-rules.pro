# Flutter Integration Test plugin rules for production release builds
-dontwarn dev.flutter.plugins.integration_test.**
-dontwarn com.google.common.util.concurrent.**
-keep class dev.flutter.plugins.integration_test.** { *; }
