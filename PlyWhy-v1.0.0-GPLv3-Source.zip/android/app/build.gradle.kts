import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = listOf(
    rootProject.file("key.properties"),
    rootProject.file("android/key.properties"),
    file("key.properties"),
    file("../key.properties"),
    file("../../key.properties"),
    file("../../android/key.properties")
).firstOrNull { it.exists() && it.length() > 0 }

if (keystorePropertiesFile != null) {
    try {
        keystorePropertiesFile.inputStream().use { keystoreProperties.load(it) }
    } catch (_: Exception) {}

    keystorePropertiesFile.readLines().forEach { line ->
        val trimmed = line.trim()
        if (trimmed.isNotEmpty() && !trimmed.startsWith("#") && trimmed.contains("=")) {
            val parts = trimmed.split("=", limit = 2)
            if (parts.size == 2) {
                val rawKey = parts[0].trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
                val rawVal = parts[1].trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
                keystoreProperties.setProperty(rawKey, rawVal)
                keystoreProperties.setProperty(rawKey.lowercase(), rawVal)
            }
        }
    }
}

android {
    namespace = "com.adolfoapps.chess_sense"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("release") {
            if (keystorePropertiesFile != null) {
                fun getProp(vararg names: String): String? {
                    for (n in names) {
                        val v = keystoreProperties.getProperty(n) ?: keystoreProperties.getProperty(n.lowercase())
                        if (!v.isNullOrBlank()) return v
                    }
                    return null
                }

                val storeFilePath = getProp("storeFile", "store_file", "keystore", "keystoreFile")
                val storePasswordVal = getProp("storePassword", "store_password", "keystorePassword")
                val keyAliasVal = getProp("keyAlias", "key_alias", "alias")
                val keyPasswordVal = getProp("keyPassword", "key_password")

                if (storeFilePath.isNullOrBlank() || storePasswordVal.isNullOrBlank() || keyAliasVal.isNullOrBlank() || keyPasswordVal.isNullOrBlank()) {
                    throw GradleException("Release signing failed: key.properties is missing required properties (storeFile, storePassword, keyAlias, keyPassword).")
                }

                val storeFileObj = file(storeFilePath)
                if (!storeFileObj.exists()) {
                    throw GradleException("Release signing failed: Keystore file not found at path '\${storeFileObj.absolutePath}'.")
                }

                storeFile = storeFileObj
                storePassword = storePasswordVal
                keyAlias = keyAliasVal
                keyPassword = keyPasswordVal
            }
        }
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.adolfoapps.chess_sense"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            val isReleaseTask = gradle.startParameter.taskNames.any { it.contains("Release", ignoreCase = true) || it.contains("bundle", ignoreCase = true) }
            if (isReleaseTask && keystorePropertiesFile == null) {
                throw GradleException("Release build failed: Missing key.properties file. Secure release builds require android/key.properties and an upload keystore. Debug key fallback is strictly prohibited.")
            }
            if (keystorePropertiesFile != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    flavorDimensions += "mode"
    productFlavors {
        create("production") {
            dimension = "mode"
            applicationId = "com.adolfoapps.chess_sense"
        }
        create("isolate") {
            dimension = "mode"
            applicationId = "com.adolfoapps.chess_sense.isolate"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

dependencies {
    compileOnly(project(":integration_test"))
}
