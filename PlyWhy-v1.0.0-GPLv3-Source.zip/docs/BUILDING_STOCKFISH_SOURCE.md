# Stockfish 18 Source Distribution & Independent Reproducible Build Guide

## Overview

PlyWhy? embeds Stockfish 18 (`libstockfish.so`) as an on-device native C++ engine via Dart FFI. The engine source code and build scripts are included in accordance with the GNU General Public License v3 (GPLv3).

## Source Location & Organization

The corresponding C++ source files, CMake build scripts, and NNUE network download directives are located in the repository at:
- `plugins/stockfish/ios/Stockfish/src/`: Full Stockfish 18 C++ source code.
- `plugins/stockfish/android/CMakeLists.txt`: Android NDK CMake build script.
- `plugins/stockfish/lib/src/ffi.dart`: Dart FFI binding interface.

## Excluded Confidential Items

Private application signing keys (`*.jks`, `key.properties`), developer-specific machine paths (`android/local.properties`), local test backups (`chesssense_backups/`), and user local data are excluded from source distribution packages.

## Step 1: Generating Personal Upload Signing Credentials

Because production release builds enforce secure signing in `android/app/build.gradle.kts`, recipients compiling a release build must generate their own personal upload key:

1. Open a terminal or PowerShell prompt.
2. Run JDK `keytool` to generate a personal keystore:
   ```bash
   keytool -genkeypair -v -keystore my-upload-key.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
3. Create a file named `android/key.properties` in your local project directory containing:
   ```properties
   storePassword=YOUR_KEYSTORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=upload
   storeFile=C:/path/to/your/my-upload-key.jks
   ```

## Step 2: NNUE Neural Network Assets & Verification

During compilation, CMake (`plugins/stockfish/android/CMakeLists.txt`) retrieves the official Stockfish NNUE evaluation networks required by Stockfish 18:
- **Primary Network:** `https://tests.stockfishchess.org/api/nn/nn-c288c895ea92.nnue`
- **Secondary Network:** `https://tests.stockfishchess.org/api/nn/nn-37f18f62d772.nnue`

## Step 3: Reproducible Android Build Commands

### Prerequisites

- Android NDK (r25c / 28.2.13676358 or higher)
- CMake 3.22.1 or higher
- Flutter SDK 3.29.0 or higher
- Java Development Kit (JDK 17)

### Build Commands

1. Open a terminal in the root project directory.
2. Ensure your Android SDK and Flutter SDK paths are configured in `android/local.properties`:
   ```properties
   sdk.dir=C:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk
   flutter.sdk=C:\\src\\flutter
   ```
3. Execute the Flutter release build command:
   ```bash
   flutter build appbundle --flavor production --release
   ```
4. Gradle will invoke CMake (`plugins/stockfish/android/CMakeLists.txt`), retrieve the NNUE network files, and compile `libstockfish.so` for `arm64-v8a`, `armeabi-v7a`, and `x86_64` with 16KB max page size link flags (`-Wl,-z,max-page-size=16384`).
