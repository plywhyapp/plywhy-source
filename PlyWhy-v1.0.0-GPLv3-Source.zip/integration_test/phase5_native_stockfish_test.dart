import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'package:chess_sense/content_repository.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/personal_game_analysis.dart';
import 'package:chess_sense/pgn_parser.dart';
import 'package:chess_sense/screens/pattern_cards_screen.dart';
import 'package:chess_sense/screens/pattern_transfer_screen.dart';

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  binding.framePolicy = LiveTestWidgetsFlutterBindingFramePolicy.fullyLive;

  group('Phase 5 - Native On-Device Stockfish Integration Test', () {
    testWidgets('Native Stockfish evaluates moves on-device without network', (WidgetTester tester) async {
      // Initialize local on-device native Stockfish inside testWidgets binding
      final apiClient = EngineApiClient.local();
      // 1. DIRECT NATIVE UCI EVALUATION TEST
      final moveContext = const PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'Rxb7',
        annotation: null,
        fenBefore: '2r2rk1/pbq1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 w - - 4 24',
        fenAfter: '2r2rk1/pbR1bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/5RK1 b - - 0 24',
      );

      final analysis = PersonalGameAnalysis(
        game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '*'),
        moves: [moveContext],
      );

      late EngineGameResult result;
      await tester.runAsync(() async {
        result = await apiClient.analyzeGame(analysis);
      });

      expect(result.moves.length, equals(1));

      final evalMove = result.moves.first;
      expect(evalMove.bestMoveUci, equals('b1b7'));
      expect(evalMove.quality, equals(EngineMoveQuality.best));
      expect(evalMove.lossCp, lessThanOrEqualTo(15));
      expect(evalMove.evalBeforeCp, isNotNull);
      expect(evalMove.evalAfterCp, isNotNull);

      // 2. CHECKMATE AND DRAW HANDLING TEST
      final checkmateMove = const PersonalGameMove(
        plyIndex: 0,
        moveNumber: 1,
        isWhiteMove: true,
        san: 'Qxf7#',
        annotation: null,
        fenBefore: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
        fenAfter: 'r1bqkb1r/pppp1Qpp/2n2n2/4p3/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 0 4',
      );

      late EngineGameResult mateResult;
      await tester.runAsync(() async {
        mateResult = await apiClient.analyzeGame(
          PersonalGameAnalysis(
            game: const ParsedPgnGame(headers: {}, sanMoves: [], result: '1-0'),
            moves: [checkmateMove],
          ),
        );
      });

      expect(mateResult.moves.length, equals(1));
      final mateEval = mateResult.moves.first;
      expect(mateEval.structuredEvalAfter.kind, equals(EvalKind.mate));

      // 3. ISOLATED PATTERN CARDS & PATTERN TRANSFER WORKFLOW
      final store = PatternCardStore();

      final card = const PatternCard(
        id: 'isolated_phase5_card_001',
        sourceGame: 'Phase 5 Native Game',
        moveLabel: '23... Qxc7',
        fenBefore: '1qr2rk1/pb2bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 b - - 3 23',
        wrongMove: 'b8c7',
        correctMoveUci: 'b1b7',
        opponentReplyUci: 'c7b7',
        lessonTitle: 'Board Change Awareness',
        whatFailed: 'Exposed queen.',
        punishment: 'Rxb7 wins material.',
        whyItWorks: 'Tactical blunder.',
        consequence: 'Evaluation drop.',
        betterChoice: 'Safer move.',
        lessonText: 'Scan for tactics.',
        flipped: false,
        transferAttempts: 0,
        transferSuccesses: 0,
      );

      await tester.runAsync(() async {
        await store.upsertAll([card]);
      });

      final customPack = ContentPack([
        const ContentPuzzle(
          id: 'test01_phase5',
          fen: '1qr2rk1/pb2bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 b - - 3 23',
          moves: 'b8c7 b1b7 c7b7 e4f6 e7f6 g2b7',
          rating: 1500, ratingDeviation: 50, popularity: 90, plays: 100, themes: ['discoveredAttack']
        ),
        const ContentPuzzle(
          id: 'test02_phase5',
          fen: 'r3kb1r/ppq2ppp/4pn2/2ppn3/1P4bP/2P2N2/P3BPP1/RNBQ1RK1 b kq - 2 10',
          moves: 'f8e7 f3e5 c7e5 e2g4',
          rating: 1500, ratingDeviation: 50, popularity: 90, plays: 100, themes: ['clearance']
        )
      ]);

      await tester.pumpWidget(
        MaterialApp(
          home: PatternCardsScreen(
            apiClient: apiClient,
            pack: customPack,
          ),
        ),
      );

      await tester.pumpAndSettle();

      // REVEAL & GRADE AS GOOD -> NAVIGATION TO PATTERNTRANSFERSCREEN
      final revealBtn = find.text('Reveal explanation');
      expect(revealBtn, findsOneWidget);
      await tester.tap(revealBtn);
      await tester.pumpAndSettle();

      // SCROLL DOWN LISTVIEW TO CENTER GOOD BUTTON IN VIEWPORT
      await tester.drag(find.byType(ListView).first, const Offset(0, -800));
      await tester.pumpAndSettle();

      final goodBtn = find.text('Good');
      expect(goodBtn, findsOneWidget);
      await tester.tap(goodBtn);

      await Future<void>.delayed(const Duration(seconds: 3));
      await tester.pumpAndSettle();

      expect(find.byType(PatternTransferScreen), findsOneWidget);

      // POSITION 1: ILLEGAL MOVE REJECTION
      final b8Square = find.byKey(const ValueKey('square_b8'));
      final a8Square = find.byKey(const ValueKey('square_a8'));
      expect(b8Square, findsOneWidget);
      expect(a8Square, findsOneWidget);

      await tester.tap(b8Square);
      await tester.pump(const Duration(milliseconds: 300));
      await tester.tap(a8Square);
      await tester.pump(const Duration(milliseconds: 300));

      expect(find.textContaining('Excellent move!'), findsNothing);

      // POSITION 1: LEGAL MOVE (b1 to b7) WITH NATIVE STOCKFISH
      final b1Square = find.byKey(const ValueKey('square_b1'));
      final b7Square = find.byKey(const ValueKey('square_b7'));

      await tester.ensureVisible(b1Square);
      await tester.tap(b1Square, warnIfMissed: false);
      await tester.pump(const Duration(milliseconds: 300));

      await tester.ensureVisible(b7Square);
      await tester.tap(b7Square, warnIfMissed: false);
      await tester.pump(const Duration(milliseconds: 300));

      await tester.runAsync(() async {
        await Future.delayed(const Duration(seconds: 8));
      });
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      expect(find.textContaining('Excellent move!'), findsOneWidget);

      final continueBtn1 = find.text('Continue');
      expect(continueBtn1, findsOneWidget);
      await tester.tap(continueBtn1);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // POSITION 2: LEGAL MOVE (f3 to e5) WITH NATIVE STOCKFISH
      expect(find.textContaining('Position 2 of 2'), findsOneWidget);

      final f3Square = find.byKey(const ValueKey('square_f3'));
      final e5Square = find.byKey(const ValueKey('square_e5'));

      await tester.ensureVisible(f3Square);
      await tester.tap(f3Square, warnIfMissed: false);
      await tester.pump(const Duration(milliseconds: 300));

      await tester.ensureVisible(e5Square);
      await tester.tap(e5Square, warnIfMissed: false);
      await tester.pump(const Duration(milliseconds: 300));

      await tester.runAsync(() async {
        await Future.delayed(const Duration(seconds: 8));
      });
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      expect(find.textContaining('Excellent move!'), findsOneWidget);

      final continueBtn2 = find.text('Continue');
      expect(continueBtn2, findsOneWidget);
      await tester.tap(continueBtn2);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // VERIFY AUTOMATIC PERSISTENCE IN ISOLATED STORAGE
      final freshStore = PatternCardStore();
      final loaded = await freshStore.loadAll();
      final reloadedCard = loaded.firstWhere((c) => c.id == 'isolated_phase5_card_001');

      expect(reloadedCard.transferAttempts, equals(2));
      expect(reloadedCard.transferSuccesses, equals(2));

      apiClient.dispose();
    });
  });
}
