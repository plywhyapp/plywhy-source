import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'package:chess_sense/content_repository.dart';
import 'package:chess_sense/engine_api.dart';
import 'package:chess_sense/pattern_cards.dart';
import 'package:chess_sense/screens/pattern_cards_screen.dart';
import 'package:chess_sense/screens/pattern_transfer_screen.dart';
import 'package:chess_sense/widgets/interactive_chessboard.dart';

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  binding.framePolicy = LiveTestWidgetsFlutterBindingFramePolicy.fullyLive;

  group('Phase 4 - Android Real Emulator Acceptance Integration Test', () {
    late EngineApiClient apiClient;

    setUpAll(() async {
      // Native on-device Stockfish engine transport (100% autonomous, no network/server)
      apiClient = EngineApiClient.local();
    });

    tearDownAll(() {
      apiClient.dispose();
    });

    testWidgets('Full Pattern Transfer cycle via real PatternCardsScreen completion and grading workflow', (WidgetTester tester) async {
      // 1. SEED ISOLATED TEST DATA IN TEST APP NAMESPACE
      final store = PatternCardStore();

      final card = const PatternCard(
        id: 'isolated_android_card_001',
        sourceGame: 'Isolated Android Game',
        moveLabel: '23... Qxc7',
        fenBefore: '1qr2rk1/pb2bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 b - - 3 23',
        wrongMove: 'b8c7',
        correctMoveUci: 'b1b7',
        opponentReplyUci: 'c7b7',
        lessonTitle: 'Board Change Awareness', // Matches discoveredAttack, etc.
        whatFailed: 'By playing 23... Qxc7, the queen was exposed.',
        punishment: 'After Qxc7, the strongest reply is Rxb7.',
        whyItWorks: 'Rxb7 wins material.',
        consequence: 'Tactical blunder.',
        betterChoice: 'Play a safer move.',
        lessonText: 'Scan for tactics before moving.',
        flipped: false,
        transferAttempts: 0,
        transferSuccesses: 0,
      );

      await store.upsertAll([card]);

      final customPack = ContentPack([
        const ContentPuzzle(
          id: 'test01_android',
          fen: '1qr2rk1/pb2bppp/8/8/2p1N3/P1Bn2P1/2Q2PBP/1R3RK1 b - - 3 23',
          moves: 'b8c7 b1b7 c7b7 e4f6 e7f6 g2b7',
          rating: 1500, ratingDeviation: 50, popularity: 90, plays: 100, themes: ['discoveredAttack']
        ),
        const ContentPuzzle(
          id: 'test02_android',
          fen: 'r3kb1r/ppq2ppp/4pn2/2ppn3/1P4bP/2P2N2/P3BPP1/RNBQ1RK1 b kq - 2 10',
          moves: 'f8e7 f3e5 c7e5 e2g4',
          rating: 1500, ratingDeviation: 50, popularity: 90, plays: 100, themes: ['clearance']
        )
      ]);

      // 2. MOUNT REAL PATTERNCARDSSCREEN (EXERCISING REAL GRADED & TRANSITION WORKFLOW)
      await tester.pumpWidget(
        MaterialApp(
          home: PatternCardsScreen(
            apiClient: apiClient,
            pack: customPack,
          ),
        ),
      );

      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      await Future<void>.delayed(const Duration(seconds: 2));
      await tester.pumpAndSettle();

      // REVEAL EXPLANATION
      final revealBtn = find.text('Reveal explanation');
      expect(revealBtn, findsOneWidget);
      await tester.tap(revealBtn);
      await tester.pumpAndSettle();

      // SCROLL DOWN LISTVIEW TO CENTER GOOD BUTTON IN VIEWPORT
      await tester.drag(find.byType(ListView), const Offset(0, -800));
      await tester.pumpAndSettle();

      // GRADE AS GOOD -> AUTOMATICALLY TRIGGERS PATTERNTRANSFERSCREEN PUSH
      final goodBtn = find.text('Good');
      expect(goodBtn, findsOneWidget);
      await tester.tap(goodBtn, warnIfMissed: false);

      // Wait for async loadPack & PatternTransferScreen navigation route transition
      await Future<void>.delayed(const Duration(seconds: 3));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // VERIFY PATTERNTRANSFERSCREEN IS DISPLAYED
      expect(find.byType(PatternTransferScreen), findsOneWidget);

      // POSITION 1 VERIFICATION
      expect(find.textContaining('Position 1 of 2'), findsOneWidget);
      expect(find.byType(InteractiveChessBoard), findsOneWidget);

      // ILLEGAL MOVE ATTEMPT: b8 to a8
      final b8Square = find.byKey(const ValueKey('square_b8'));
      final a8Square = find.byKey(const ValueKey('square_a8'));
      expect(b8Square, findsOneWidget);
      expect(a8Square, findsOneWidget);

      await tester.tap(b8Square);
      await tester.pump(const Duration(milliseconds: 300));
      await tester.tap(a8Square);
      await tester.pump(const Duration(milliseconds: 300));

      expect(find.textContaining('Excellent move!'), findsNothing);
      expect(find.textContaining('Incorrect'), findsNothing);

      // LEGAL MOVE ON POSITION 1: b1 to b7 (Rxb7)
      final b1Square = find.byKey(const ValueKey('square_b1'));
      final b7Square = find.byKey(const ValueKey('square_b7'));

      await tester.ensureVisible(b1Square);
      await tester.tap(b1Square, warnIfMissed: false);
      await tester.pumpAndSettle();

      await tester.ensureVisible(b7Square);
      await tester.tap(b7Square, warnIfMissed: false);
      await tester.pumpAndSettle();

      // Wait for real live Stockfish analysis response from local engine
      await Future<void>.delayed(const Duration(seconds: 16));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // Verify Stockfish feedback on screen
      expect(find.textContaining('Excellent move!'), findsOneWidget);

      // Tap Continue to proceed to Position 2
      final continueBtn1 = find.text('Continue');
      expect(continueBtn1, findsOneWidget);
      await tester.tap(continueBtn1);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // POSITION 2 VERIFICATION
      expect(find.textContaining('Position 2 of 2'), findsOneWidget);

      // LEGAL MOVE ON POSITION 2: f3 to e5 (Nxe5)
      final f3Square = find.byKey(const ValueKey('square_f3'));
      final e5Square = find.byKey(const ValueKey('square_e5'));

      await tester.ensureVisible(f3Square);
      await tester.tap(f3Square, warnIfMissed: false);
      await tester.pumpAndSettle();

      await tester.ensureVisible(e5Square);
      await tester.tap(e5Square, warnIfMissed: false);
      await tester.pumpAndSettle();

      await Future<void>.delayed(const Duration(seconds: 16));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // Verify Stockfish feedback on Position 2
      expect(find.textContaining('Excellent move!'), findsOneWidget);

      final continueBtn2 = find.text('Continue');
      expect(continueBtn2, findsOneWidget);
      await tester.tap(continueBtn2);
      await tester.pump();
      await tester.pump(const Duration(seconds: 1));

      // VERIFY AUTOMATIC PERSISTENCE VIA REAL PATTERNCARDSSCREEN GRADED WORKFLOW
      final freshStore = PatternCardStore();
      final loaded = await freshStore.loadAll();
      final reloadedCard = loaded.firstWhere((c) => c.id == 'isolated_android_card_001');

      expect(reloadedCard.transferAttempts, equals(2));
      expect(reloadedCard.transferSuccesses, equals(2));
    });
  });
}
